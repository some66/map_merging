/**
* This file is part of CCM-SLAM.
*
* Copyright (C): Patrik Schmuck <pschmuck at ethz dot ch> (ETH Zurich)
* For more information see <https://github.com/patriksc/CCM-SLAM>
*
* CCM-SLAM is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* CCM-SLAM is based in the monocular version of ORB-SLAM2 by Raúl Mur-Artal.
* CCM-SLAM partially re-uses modules of ORB-SLAM2 in modified or unmodified condition.
* For more information see <https://github.com/raulmur/ORB_SLAM2>.
*
* CCM-SLAM is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CCM-SLAM. If not, see <http://www.gnu.org/licenses/>.
*/


#include <cslam/Tracking.h>

namespace cslam {


//这段代码定义了一个 单目跟踪模块，该函数负责 初始化跟踪器的关键参数和组件，包括相机内参、畸变系数、ORB 特征提取器等。
//mState：表示当前状态，初始状态为 NO_IMAGES_YET。
//mpCC, mpORBVocabulary, mpKeyFrameDB, mpMap：核心组件指针，包括：
//mpCC：用于通信或多机 SLAM 中的客户端控制模块。
//mpORBVocabulary：ORB特征的词汇表，用于回环检测。
//mpKeyFrameDB：关键帧数据库。
//mpMap：地图管理模块。
//mpInitializer：初始化模块的指针，初始为 nullptr。
//mLastRelocFrameId：用于记录上一次重定位的帧 ID。
//mClientId：客户端编号，用于多机SLAM。

Tracking::Tracking(ccptr pCC, vocptr pVoc, viewptr pFrameViewer, mapptr pMap, dbptr pKFDB, const string &strCamPath, size_t ClientId)
    : mState(NO_IMAGES_YET),mpCC(pCC),mpORBVocabulary(pVoc), mpKeyFrameDB(pKFDB), mpInitializer(nullptr),
      mpViewer(pFrameViewer), mpMap(pMap), mLastRelocFrameId(make_pair(0,0)), mClientId(ClientId)
{
    //从配置文件中读取相机内参（焦距和光心位置），然后构造相机矩阵：
    cv::FileStorage fSettings(strCamPath, cv::FileStorage::READ);
    float fx = fSettings["Camera.fx"];
    float fy = fSettings["Camera.fy"];
    float cx = fSettings["Camera.cx"];
    float cy = fSettings["Camera.cy"];

    cv::Mat K = cv::Mat::eye(3,3,CV_32F);
    K.at<float>(0,0) = fx;
    K.at<float>(1,1) = fy;
    K.at<float>(0,2) = cx;
    K.at<float>(1,2) = cy;
    K.copyTo(mK);

// 畸变系数加载,从配置文件中读取畸变系数，用于图像去畸变处理：
//k1, k2：径向畸变系数。
//p1, p2：切向畸变系数。
//k3：第三阶径向畸变系数（可选）。
    cv::Mat DistCoef(4,1,CV_32F);
    DistCoef.at<float>(0) = fSettings["Camera.k1"];
    DistCoef.at<float>(1) = fSettings["Camera.k2"];
    DistCoef.at<float>(2) = fSettings["Camera.p1"];
    DistCoef.at<float>(3) = fSettings["Camera.p2"];
    const float k3 = fSettings["Camera.k3"];
    if(k3!=0)
    {
        DistCoef.resize(5);
        DistCoef.at<float>(4) = k3;
    }
    DistCoef.copyTo(mDistCoef);

    float fps = fSettings["Camera.fps"];
    if(fps==0)
        fps=30;

    int nRGB = fSettings["Camera.RGB"];
    mbRGB = nRGB;

//特征提取器初始化
//初始化两个 ORB 特征提取器：mpORBextractor：用于普通帧特征提取。mpIniORBextractor：用于初始化阶段（双倍特征数量以提高稳定性）。
//参数设置：nFeatures：每帧要提取的特征数量。fScaleFactor：金字塔缩放系数。nLevels：金字塔层数。
//iIniThFAST：FAST特征提取的初始阈值。iMinThFAST：FAST特征提取的最小阈值（对弱特征继续检测）。

    const int nFeatures = params::extractor::miNumFeatures;
    const float fScaleFactor = params::extractor::mfScaleFactor;
    const int nLevels = params::extractor::miNumLevels;
    const int iIniThFAST = params::extractor::miIniThFAST;
    const int iMinThFAST = params::extractor::miNumThFAST;

    mpORBextractor.reset(new ORBextractor(nFeatures,fScaleFactor,nLevels,iIniThFAST,iMinThFAST
                                          ));
    mpIniORBextractor.reset(new ORBextractor(2*nFeatures,fScaleFactor,nLevels,iIniThFAST,iMinThFAST
                                             ));

    //检查关键模块是否存在
    //检查依赖模块是否为空指针，若缺失则抛出异常，防止系统崩溃。
    if(!mpMap || !mpORBVocabulary || !mpKeyFrameDB || !mpCC)
    {
        cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m " << __func__ << ": nullptr given"<< endl;
        if(!mpMap) cout << "mpMap == nullptr" << endl;
        if(!mpORBVocabulary) cout << "mpORBVocabulary == nullptr" << endl;
        if(!mpKeyFrameDB) cout << "mpKeyFrameDB == nullptr" << endl;
        if(!mpCC) cout << "mpCC == nullptr" << endl;
        throw estd::infrastructure_ex();
    }
    if(!mpViewer)
    {
        cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m " << __func__ << ": nullptr given"<< endl;
        if(!mpViewer) cout << "mpViewer == nullptr" << endl;
        throw estd::infrastructure_ex();
    }
}


//图像输入函数, 该函数负责处理输入图像，并执行帧跟踪。
cv::Mat Tracking::GrabImageMonocular(const cv::Mat &im, const double &timestamp)
{
    mImGray = im;

//图像灰度化, 检查图像通道数，如果是彩色图像（3或4通道），转换为灰度图像以减少计算复杂度。
//根据配置文件中定义的 RGB 或 BGR 顺序处理颜色空间转换。
    if(mImGray.channels()==3)
    {
        if(mbRGB)
            cvtColor(mImGray,mImGray,CV_RGB2GRAY);
        else
            cvtColor(mImGray,mImGray,CV_BGR2GRAY);
    }
    else if(mImGray.channels()==4)
    {
        if(mbRGB)
            cvtColor(mImGray,mImGray,CV_RGBA2GRAY);
        else
            cvtColor(mImGray,mImGray,CV_BGRA2GRAY);
    }

    // 初始化或跟踪帧创建, 如果系统未初始化，使用 mpIniORBextractor 生成初始帧（具有更多特征）。
    // 如果已初始化，使用普通特征提取器 mpORBextractor。
    //
    if(mState==NOT_INITIALIZED || mState==NO_IMAGES_YET)
        mCurrentFrame.reset(new Frame(mImGray,timestamp,mpIniORBextractor,mpORBVocabulary,mK,mDistCoef,mClientId));
    else
    {
        mCurrentFrame.reset(new Frame(mImGray,timestamp,mpORBextractor,mpORBVocabulary,mK,mDistCoef,mClientId));
    }
    //执行跟踪, 调用 Track() 函数，执行实际的特征跟踪和位姿估计，包括：初始化阶段：
    // 利用特征匹配和 RANSAC 建立初始位姿。跟踪阶段：根据上一帧估计位姿并更新状态。
    Track();

   //返回当前帧位姿, 返回当前帧的位姿变换矩阵 𝑇𝑐𝑤   (相机到世界坐标系的变换）。
    return mCurrentFrame->mTcw.clone();
}


//这段代码定义了视觉 SLAM 系统中的 主跟踪函数 Tracking::Track()，负责相机位姿估计、地图更新以及关键帧管理。
//该函数负责：初始化阶段： 尝试通过特征点匹配完成初始化。跟踪阶段： 根据运动模型或参考关键帧估计位姿。局部地图更新： 在已有位姿估计的基础上优化匹配和地图点。
//关键帧管理： 判断是否需要插入新的关键帧以维护全局地图一致性。丢失恢复： 如果跟踪失败且地图较小时，重置系统。姿态存储： 保存轨迹信息以便后续分析或可视化。
void Tracking::Track()
{
    //如果尚未处理任何图像，将状态切换到 未初始化（NOT_INITIALIZED），准备执行初始化过程。
    if(mState==NO_IMAGES_YET)
    {
        mState = NOT_INITIALIZED;
    }

    mLastProcessedState=mState;

    // Get Map Mutex -> Map cannot be changed
    //地图互斥锁，加锁以确保地图更新过程中不会出现数据竞争条件（多线程安全）。
    while(!mpMap->LockMapUpdate()){
        usleep(params::timings::miLockSleep);
    }

    //Comm Mutex cannot be acquired here. In case of wrong initialization, there is mutual dependency in the call of reset()
    //  初始阶段处理, 
    if(mState==NOT_INITIALIZED)
    {
        // 调用 MonocularInitialization() 估计初始位姿并构建初始地图。如果初始化失败，则直接返回等待下一帧。
        MonocularInitialization();   //// 执行单目初始化

         //将当前帧渲染到 GUI 上，方便调试和可视化结果。
        if(params::vis::mbActive)
            mpViewer->UpdateAndDrawFrame();
        else
        {
            cout << "\033[1;35m!!! +++ Tracking: Init +++ !!!\033[0m" << endl;
        }

        if(mState!=OK)
        {
            mpMap->UnLockMapUpdate(); 
            return;
        }
    }
    else
    {

        // Get Communicator Mutex -> Comm cannot publish. Assure no publishing whilst changing data
        if(params::sys::mbStrictLock) while(!mpCC->LockTracking()){
            usleep(params::timings::miLockSleep);
        }

        // System is initialized. Track Frame.
        bool bOK;

        // Initial camera pose estimation using motion model or relocalization (if tracking is lost)
        //已初始化阶段, 并且检查上一帧中的地图点是否被局部建图模块替换，以保持一致性。
        if(mState==OK)
        {
            // Local Mapping might have changed some MapPoints tracked in last frame
            CheckReplacedInLastFrame();     // 检查地图点是否被替换

             //位姿估计流程：
             //运动模型跟踪：如果存在运动速度（上一帧的位姿变化），优先使用运动模型预测当前位置，减少计算量。
             //回退机制：若运动模型失败，则使用最近的关键帧辅助跟踪，增强鲁棒性。
            if(mVelocity.empty() || mCurrentFrame->mId.first<mLastRelocFrameId.first+2)
            {
                bOK = TrackReferenceKeyFrame();   // 使用参考关键帧进行跟踪
            }
            else
            {
                bOK = TrackWithMotionModel();   // 使用运动模型预测位姿
                if(!bOK){
                    bOK = TrackReferenceKeyFrame();
                }
            }
        }
        else
        {
            cout << "\033[1;35m!!! +++ Tracking: Lost +++ !!!\033[0m" << endl;
            bOK = false;
        }

        mCurrentFrame->mpReferenceKF = mpReferenceKF;

        // If we have an initial estimation of the camera pose and matching. Track the local map.
        //局部地图跟踪，在位姿初步估计完成后，使用局部地图优化位姿和特征点匹配结果。
        // 更新地图中的关键帧和地图点，以提高当前帧跟踪的稳定性。
        if(bOK) bOK = TrackLocalMap();

        if(bOK)
            mState = OK;
        else
            mState=LOST;

        // Update drawer
        if(params::vis::mbActive) mpViewer->UpdateAndDrawFrame();

        // If tracking were good, check if we insert a keyframe
        if(bOK)
        {
            // Update motion model
            if(!mLastFrame->mTcw.empty())
            {
                cv::Mat LastTwc = cv::Mat::eye(4,4,CV_32F);
                mLastFrame->GetRotationInverse().copyTo(LastTwc.rowRange(0,3).colRange(0,3));
                mLastFrame->GetCameraCenter().copyTo(LastTwc.rowRange(0,3).col(3));
                mVelocity = mCurrentFrame->mTcw*LastTwc;
            }
            else
                mVelocity = cv::Mat();

            // Clean VO matches
            for(int i=0; i<mCurrentFrame->N; i++)
            {
                mpptr pMP = mCurrentFrame->mvpMapPoints[i];
                if(pMP)
                    if(pMP->Observations()<1)
                    {
                        mCurrentFrame->mvbOutlier[i] = false;
                        mCurrentFrame->mvpMapPoints[i]=nullptr;
                    }
            }

            // Check if we need to insert a new keyframe
            // 关键帧管理, 判断是否需要插入新的关键帧：位姿变化较大或跟踪点不足时，需要插入新关键帧。新关键帧可用于后续地图优化和回环检测。
            if(NeedNewKeyFrame())
                      CreateNewKeyFrame();

            // We allow points with high innovation (considererd outliers by the Huber Function)
            // pass to the new keyframe, so that bundle adjustment will finally decide
            // if they are outliers or not. We don't want next frame to estimate its position
            // with those points so we discard them in the frame.
            //特征点过滤：剔除低质量的地图点：若某个地图点的观测次数低于 1 次，则认为它是离群点，不再参与位姿估计。
            for(int i=0; i<mCurrentFrame->N;i++)
            {
                if(mCurrentFrame->mvpMapPoints[i] && mCurrentFrame->mvbOutlier[i])
                    mCurrentFrame->mvpMapPoints[i]=nullptr;
            }
        }

        // Reset if the camera get lost soon after initialization
        //跟踪丢失处理, 检测是否在初始化后立即丢失跟踪：若关键帧数量过少，直接重置系统并重新初始化。
        if(mState==LOST)
        {
            if(mpMap->KeyFramesInMap()<=params::tracking::miInitKFs)
            {
                cout << "Track lost soon after initialisation, reseting..." << endl;
                if(params::sys::mbStrictLock) mpCC->UnLockTracking();
                mpMap->UnLockMapUpdate();
                mpCC->mpCH->Reset();

                return;
            }
        }

        if(!mCurrentFrame->mpReferenceKF)
            mCurrentFrame->mpReferenceKF = mpReferenceKF;

        mLastFrame.reset(new Frame(*mCurrentFrame));

        if(params::sys::mbStrictLock) mpCC->UnLockTracking();
    }

    // Store frame pose information to retrieve the complete camera trajectory afterwards.
    // 轨迹记录, 存储位姿信息：记录每帧的相对位姿 𝑇𝑐𝑟 （当前帧到参考关键帧的变换）。保存时间戳和跟踪状态，用于后续轨迹分析和可视化。
    if(!mCurrentFrame->mTcw.empty())
    {
        cv::Mat Tcr = mCurrentFrame->mTcw*mCurrentFrame->mpReferenceKF->GetPoseInverse();
        mlRelativeFramePoses.push_back(Tcr);
        mlpReferences.push_back(mpReferenceKF);
        mlFrameTimes.push_back(mCurrentFrame->mTimeStamp);
        mlbLost.push_back(mState==LOST);
    }
    else
    {
        // This can happen if tracking is lost
        mlRelativeFramePoses.push_back(mlRelativeFramePoses.back());
        mlpReferences.push_back(mlpReferences.back());
        mlFrameTimes.push_back(mlFrameTimes.back());
        mlbLost.push_back(mState==LOST);
    }

    mpMap->UnLockMapUpdate();
}


//定义了视觉 SLAM 系统中用于 单目初始化 的函数 Tracking::MonocularInitialization()，它负责在系统启动阶段估计相机初始位姿并构建初始地图。
void Tracking::MonocularInitialization()
{
//单目 SLAM 的初始化是一个关键步骤，因为它需要在缺乏深度信息的情况下，通过两帧图像推断相机的运动和三维结构。本函数的主要功能包括：
//设置参考帧作为初始帧。在两帧图像之间进行特征匹配，尝试恢复初始姿态和三维点云。如果恢复成功，则设置相机位姿，并创建初始地图。

//检查是否需要初始化
//如果初始化器（mpInitializer）不存在，说明系统还未开始初始化过程。
    if(!mpInitializer)
    {
        //  Set Reference Frame
        // 特征点数量要求：至少需要 100 个特征点，确保后续匹配和恢复稳定性。
        if(mCurrentFrame->mvKeys.size()>100)
        {
                 mInitialFrame.reset(new Frame(*mCurrentFrame));// 保存初始帧
            mLastFrame.reset(new Frame(*mCurrentFrame)); // 保存上一帧

                 //初始化参考帧
            mvbPrevMatched.resize(mCurrentFrame->mvKeysUn.size());
            for(size_t i=0; i<mCurrentFrame->mvKeysUn.size(); i++)
                   //保存当前帧中关键点的像素坐标到 mvbPrevMatched，供后续特征匹配使用。
                mvbPrevMatched[i]=mCurrentFrame->mvKeysUn[i].pt;

            if(mpInitializer) mpInitializer = nullptr;
            
            //创建初始化器对象 mpInitializer：参数 1.0 是特征检测的标准差（噪声模型）。最大迭代次数设为 200。
            //初始化匹配结果数组 mvIniMatches，表示特征匹配对（-1 表示未匹配）。
            mpInitializer.reset(new Initializer(*mCurrentFrame,1.0,200));
            fill(mvIniMatches.begin(),mvIniMatches.end(),-1);

            return;
        }
    }
    else
    {
        // Try to initialize
        //检查当前帧特征数量, 如果当前帧特征点数量不足 100 个，直接取消初始化过程，等待后续帧重新尝试。
        if((int)mCurrentFrame->mvKeys.size()<=100)
        {
            mpInitializer = nullptr;
            fill(mvIniMatches.begin(),mvIniMatches.end(),-1);
            return;
        }

        // Find correspondences
        //特征匹配,  ORBmatcher： 用于计算关键点描述子的相似度并执行特征匹配。0.9：描述子距离比值测试阈值，值越小越严格。true：允许交叉验证，进一步提高匹配精度。
        //匹配结果存储在 mvIniMatches 中：若匹配成功， mvIniMatches [i] 保存匹配到的索引。匹配失败则保持为 -1。
        ORBmatcher matcher(0.9,true);
         int nmatches = matcher.SearchForInitialization(*mInitialFrame,*mCurrentFrame,mvbPrevMatched,mvIniMatches,100);

        // Check if there are enough correspondences
        //检查匹配数量, 如果匹配数量不足 100 个，则认为初始化不可靠，取消初始化过程并重置变量。
        if(nmatches<100)
        {
            //delete mpInitializer;
            mpInitializer = nullptr;
            return;
        }

        //三角化与位姿恢复,
        cv::Mat Rcw; // Current Camera Rotation,  // 当前相机旋转矩阵
        cv::Mat tcw; // Current Camera Translation , // 当前相机平移向量
        vector<bool> vbTriangulated; // Triangulated Correspondences (mvIniMatches) ,  // 标记成功三角化的匹配点

   //调用初始化器的 Initialize() 函数，尝试通过特征匹配恢复相机位姿：输入： 当前帧、特征匹配对。
   //输出： 旋转矩阵 𝑅𝑐𝑤 、平移向量 𝑡𝑐𝑤 、三维点云 mvIniP3D 和三角化状态 vbTriangulated。
        if(mpInitializer->Initialize(*mCurrentFrame, mvIniMatches, Rcw, tcw, mvIniP3D, vbTriangulated))
        {
            // 筛选成功三角化的匹配点, 剔除未成功三角化的匹配点，确保后续处理仅使用可靠的匹配结果。
            for(size_t i=0, iend=mvIniMatches.size(); i<iend;i++)
            {
                if(mvIniMatches[i]>=0 && !vbTriangulated[i])
                {
                    mvIniMatches[i]=-1;    // 标记未成功三角化的点为无效
                    nmatches--;
                }
            }

            // Set Frame Poses
            // 设置初始位姿, 初始帧位姿设置为世界坐标系原点（单位矩阵）。当前帧位姿基于计算得到的旋转和平移矩阵进行设置。
            mInitialFrame->SetPose(cv::Mat::eye(4,4,CV_32F));  // 初始帧为世界原点
            cv::Mat Tcw = cv::Mat::eye(4,4,CV_32F);      
            Rcw.copyTo(Tcw.rowRange(0,3).colRange(0,3));  // 设置旋转矩阵
            tcw.copyTo(Tcw.rowRange(0,3).col(3));     // 设置平移向量
            mCurrentFrame->SetPose(Tcw);  // 设置当前帧位姿

            //创建初始地图,  调用 CreateInitialMapMonocular() 创建初始地图：将三角化成功的三维点云添加到地图中。设置关键帧和关键点的关联关系。
            CreateInitialMapMonocular();
        }
    }
}

// 定义了视觉 SLAM 系统中的 单目初始化地图构建函数
// 用于在初始化阶段生成初始地图、关键帧和三维地图点，并执行全局优化。
// 该函数负责在单目 SLAM 系统中完成以下任务：创建初始关键帧，并将它们插入地图。
// 根据初始化过程中恢复的三维点创建地图点，并关联到关键帧。执行全局 Bundle Adjustment (BA) 优化，调整相机位姿和三维点坐标。
// 将场景的尺度归一化，确保初始化地图和位姿的尺度一致。设置局部地图和跟踪状态，为后续帧的跟踪提供基础。

void Tracking::CreateInitialMapMonocular()
{
    // Get Communicator Mutex -> Comm cannot publish. Assure no publishing whilst changing data
    // 获取互斥锁, 加锁防止通信模块在地图构建过程中进行数据发布，确保数据一致性。使用 互斥锁机制 确保多线程安全。
    while(!mpCC->LockTracking())
     {
        usleep(params::timings::miLockSleep);
    }

    // Create KeyFrames
    //创建初始关键帧,  pKFini 和 pKFcur: 分别创建两个关键帧，代表初始化帧和当前帧。
    //  将它们关联到地图 (mpMap) 和关键帧数据库 (mpKeyFrameDB)。
    kfptr pKFini{new KeyFrame(*mInitialFrame,mpMap,mpKeyFrameDB,mpComm,eSystemState::CLIENT,-1)};
    kfptr pKFcur{new KeyFrame(*mCurrentFrame,mpMap,mpKeyFrameDB,mpComm,eSystemState::CLIENT,-1)};

    //计算词袋模型 (BoW)：通过 ORB 特征描述子计算词袋模型（BoW）用于后续回环检测和关键帧管理。
    pKFini->ComputeBoW();
    pKFcur->ComputeBoW();

    // Insert KFs in the map
    //将关键帧添加到地图：将关键帧插入地图管理器，建立初始关键帧网络。
    mpMap->AddKeyFrame(pKFini);
    mpMap->AddKeyFrame(pKFcur);

    // Create MapPoints and asscoiate to keyframes
    //遍历初始化过程中恢复的三维点 mvIniP3D，并创建对应的 地图点 (MapPoint)。
    for(size_t i=0; i<mvIniMatches.size();i++)
    {
        if(mvIniMatches[i]<0)
            continue;

        //Create MapPoint.
        cv::Mat worldPos(mvIniP3D[i]);

        mpptr pMP{new MapPoint(worldPos,pKFcur,mpMap,mClientId,mpComm,eSystemState::CLIENT,-1)};

       //将每个地图点与关键帧关联：
        pKFini->AddMapPoint(pMP,i);
        pKFcur->AddMapPoint(pMP,mvIniMatches[i]);

     //观察关系建立：设置观测关系，记录每个地图点在哪些关键帧中被观测到。
        pMP->AddObservation(pKFini,i);
        pMP->AddObservation(pKFcur,mvIniMatches[i]);

      //描述子和法向量计算：计算地图点的描述子，用于后续特征匹配。
    //更新法向量和深度信息，便于局部地图跟踪和优化。
        pMP->ComputeDistinctiveDescriptors();
        pMP->UpdateNormalAndDepth();

        //Fill Current Frame structure
        mCurrentFrame->mvpMapPoints[mvIniMatches[i]] = pMP;
        mCurrentFrame->mvbOutlier[mvIniMatches[i]] = false;

        //Add to Map
        //添加到地图管理器
        mpMap->AddMapPoint(pMP);
    }

    // Update Connections
    //更新关键帧连接, 更新关键帧之间的连接关系（基于共享的地图点），形成关键帧图，用于局部优化和回环检测。
    pKFini->UpdateConnections();
    pKFcur->UpdateConnections();

    // Bundle Adjustment
    cout << "New Map created with " << mpMap->MapPointsInMap() << " points" << endl;

    //全局BA，全局优化,执行全局 Bundle Adjustment (BA)，同时优化相机位姿和三维点的位置，确保一致性和精度。最大迭代次数为 20 次。
    Optimizer::GlobalBundleAdjustemntClient(mpMap,mClientId,20);

    // Set median depth to 1
    //尺度归一化, 计算场景的中位深度，以解决单目初始化中的尺度不确定性问题。
    float medianDepth = pKFini->ComputeSceneMedianDepth(2);
    float invMedianDepth = 1.0f/medianDepth;

   //检查深度是否可靠：如果深度异常或跟踪点数量不足，则重置初始化流程。
    if(medianDepth<0 || pKFcur->TrackedMapPoints(1)<100)
    {
        cout << "Wrong initialization, reseting..." << endl;
        mpCC->UnLockTracking();
        Reset();
        return;
    }

    // Scale initial baseline
    //调整尺度：调整当前帧的位姿和所有地图点的坐标，使场景深度的中位数为 1。
    cv::Mat Tc2w = pKFcur->GetPose();
    Tc2w.col(3).rowRange(0,3) = Tc2w.col(3).rowRange(0,3)*invMedianDepth;
    pKFcur->SetPose(Tc2w,false);

    // Scale points
    vector<mpptr> vpAllMapPoints = pKFini->GetMapPointMatches();

     //缩放地图点
    for(size_t iMP=0; iMP<vpAllMapPoints.size(); iMP++)
    {
        if(vpAllMapPoints[iMP])
        {
            mpptr pMP = vpAllMapPoints[iMP];
            pMP->SetWorldPos(pMP->GetWorldPos()*invMedianDepth,false);
        }
    }

    //更新局部地图, 将初始关键帧插入局部建图模块，用于增量式扩展地图和优化。
    mpLocalMapper->InsertKeyFrame(pKFini);
    mpLocalMapper->InsertKeyFrame(pKFcur);

    mCurrentFrame->SetPose(pKFcur->GetPose());
    mLastKeyFrameId=mCurrentFrame->mId;
    mpLastKeyFrame = pKFcur;

    mvpLocalKeyFrames.push_back(pKFcur);
    mvpLocalKeyFrames.push_back(pKFini);
    mvpLocalMapPoints=mpMap->GetAllMapPoints();
    mpReferenceKF = pKFcur;
    mCurrentFrame->mpReferenceKF = pKFcur;

    mLastFrame.reset(new Frame(*mCurrentFrame));

    mpMap->SetReferenceMapPoints(mvpLocalMapPoints);

    mpMap->mvpKeyFrameOrigins.push_back(pKFini);

    //设置跟踪状态, 设置跟踪状态为 OK，表示系统已成功初始化，并进入正常跟踪阶段。
    mState=OK;

    mpCC->UnLockTracking();
}


//定义了视觉 SLAM 系统中的 地图点替换检查函数 , 用于处理地图点在局部建图过程中被替换的情况，确保关键帧中的观测信息保持一致性。
//该函数主要用于 检查上一帧的地图点是否已被替换，并根据描述子相似性更新地图点引用，以保证跟踪过程中的地图点数据一致性和鲁棒性。
//具体功能包括：遍历上一帧中所有的地图点，检查是否存在替换点。如果存在替换点，则比较描述子距离，选择更匹配的点进行更新。
//保持地图和关键帧的观测信息一致，避免错误匹配导致跟踪失败。

void Tracking::CheckReplacedInLastFrame()
{
    // 遍历上一帧的地图点, 遍历上一帧（mLastFrame）的所有地图点，共 N 个地图点。
    for(int i =0; i<mLastFrame->N; i++)
    {
         // pMP：指向第 i 个地图点的指针。
        mpptr pMP = mLastFrame->mvpMapPoints[i];

        if(pMP)
        {
        //检查是否存在替换点：调用 pMP->GetReplaced()，获取当前地图点是否已被替换为另一个点。
       //替换的原因可能是：局部优化中地图点被合并到其他点。发现了更可靠或更优的点替代当前点。
            mpptr pRep = pMP->GetReplaced();
            if(pRep)
            {
                //查找替换点是否已存在, 在上一帧的地图点列表中查找替换点 pRep 是否已经存在。
                //vit: 如果找到了替换点，其索引存储在 vit 中；否则返回末尾迭代器。
                vector<mpptr>::iterator vit = std::find(mLastFrame->mvpMapPoints.begin(),mLastFrame->mvpMapPoints.end(),pRep);

                 //处理替换点存在的情况
                if(vit != mLastFrame->mvpMapPoints.end())
                {
                    int curId = vit - mLastFrame->mvpMapPoints.begin();   //curId: 替换点在上一帧中的索引。

                    // 计算描述子距离
                    //获取地图点和帧中的描述子：dMP: 替换点的描述子。dF_curId: 当前帧中替换点位置的描述子。dF_i: 当前地图点原始位置的描述子。
                    const cv::Mat dMP = pRep->GetDescriptor();
                    const cv::Mat &dF_curId = mLastFrame->mDescriptors.row(curId);
                    const cv::Mat &dF_i = mLastFrame->mDescriptors.row(i);

                    //使用 ORBmatcher::DescriptorDistance() 计算描述子之间的汉明距离：dist_curId: 替换点与帧中原点描述子的距离。dist_i: 替换点与当前地图点描述子的距离。
                    double dist_curId = ORBmatcher::DescriptorDistance(dMP,dF_curId);
                    double dist_i = ORBmatcher::DescriptorDistance(dMP,dF_i);

                    // 选择更匹配的地图点, 距离比较：若当前地图点更匹配（距离更小），则更新其引用为替换点，并清除原始点。若替换点更优，则保持不变。
                    if(dist_i <= dist_curId)
                    {
                        mLastFrame->mvpMapPoints[curId] = nullptr;
                        mLastFrame->mvpMapPoints[i] = pRep;
                    }
                    else
                    {
                        //keep old id -- do nothing
                    }
                }
                else
                {
                    //如果替换点不在上一帧的地图点列表中，直接将其设为新的地图点。
                    mLastFrame->mvpMapPoints[i] = pRep;
                }
            }
        }
    }
}


//定义了 参考关键帧跟踪函数 Tracking::TrackReferenceKeyFrame()，用于在视觉 SLAM 系统中基于参考关键帧进行当前帧位姿估计和优化。
//该函数主要用于通过参考关键帧帮助当前帧恢复位姿，当跟踪过程中的运动模型失败时，提供备选方案。
//核心功能包括：计算当前帧的 BoW（Bag of Words） 描述子，以便与参考关键帧进行特征匹配。执行特征匹配，并利用匹配结果设置位姿优化的初始条件。
//使用 PnP 位姿优化 求解当前帧相机位姿。剔除离群点（outliers）并统计有效地图点数。根据有效匹配点数量判断跟踪是否成功。

bool Tracking::TrackReferenceKeyFrame()
{
    // Compute Bag of Words vector
    //计算当前帧的 BoW 描述子
    //计算当前帧的 BoW 描述子，用于与参考关键帧的特征进行快速匹配。BoW 描述子基于 ORB 特征提取，通过词袋模型将描述子映射到特征词汇表，用于高效检索和匹配。
    mCurrentFrame->ComputeBoW();

    // We perform first an ORB matching with the reference keyframe
    // If enough matches are found we setup a PnP solver
    //使用 ORB 特征匹配器进行描述子比对，寻找当前帧和参考关键帧之间的特征点对应关系。
    //参数分析：0.7：最近邻比率测试阈值，越小匹配越严格（减少错误匹配）。true：开启交叉验证，确保匹配结果双向一致。
    //返回值：nmatches: 成功匹配的特征点对数量。
    ORBmatcher matcher(0.7,true);
    vector<mpptr> vpMapPointMatches;

    int nmatches = matcher.SearchByBoW(mpReferenceKF,*mCurrentFrame,vpMapPointMatches);

   //判断匹配数量是否足够,  如果特征匹配数量不足，直接返回跟踪失败。miTrackWithRefKfInlierThresSearch: 匹配点阈值，确保匹配点足够支持位姿优化。
    if(nmatches<params::tracking::miTrackWithRefKfInlierThresSearch)
        return false;

   // 位姿初始化,将匹配到的地图点关联到当前帧。使用上一帧的位姿 𝑇𝑐𝑤  作为初始位姿，为优化提供起点。
    mCurrentFrame->mvpMapPoints = vpMapPointMatches;
    mCurrentFrame->SetPose(mLastFrame->mTcw);

   //位姿优化, 调用优化模块对当前帧进行 PnP 位姿优化：根据匹配到的地图点和对应的像素坐标估计相机位姿。
     //使用 非线性优化 (Levenberg-Marquardt) 方法最小化重投影误差，得到最优位姿。
    Optimizer::PoseOptimizationClient(*mCurrentFrame);

    // Discard outliers
    //剔除离群点,  离群点剔除机制：在优化过程中检测到的离群点（误差较大的点）被标记为 outlier。
    // 离群点将从当前帧中移除，不再参与后续优化和跟踪。有效地图点统计：nmatchesMap: 当前帧中观测次数大于 0 的有效地图点数量。
    int nmatchesMap = 0;
    for(int i =0; i<mCurrentFrame->N; i++)
    {
        if(mCurrentFrame->mvpMapPoints[i])
        {
            if(mCurrentFrame->mvbOutlier[i])
            {
                mpptr pMP = mCurrentFrame->mvpMapPoints[i];

                mCurrentFrame->mvpMapPoints[i]=nullptr;
                mCurrentFrame->mvbOutlier[i]=false;
                pMP->mbTrackInView = false;
                pMP->mLastFrameSeen = mCurrentFrame->mId;
                nmatches--;
            }
            else if(mCurrentFrame->mvpMapPoints[i]->Observations()>0)
                nmatchesMap++;
        }
    }

   //  判断跟踪是否成功, 检查经过优化和剔除离群点后的有效匹配数量是否超过阈值。miTrackWithRefKfInlierThresOpt: 优化后的最低有效匹配点阈值（通常为 10）。
    return nmatchesMap>=params::tracking::miTrackWithRefKfInlierThresOpt; //10
}


//定义了视觉 SLAM 系统中的 上一帧位姿更新函数 Tracking::UpdateLastFrame()，用于根据参考关键帧的位姿和相对变换更新上一帧的位姿信息
void Tracking::UpdateLastFrame()
{
    // Update pose according to reference keyframe
    //获取参考关键帧, 获取上一帧 mLastFrame 所关联的 参考关键帧 (Reference KeyFrame)。
    //参考关键帧是上一帧通过特征匹配建立位姿关系的关键帧，通常用于提供位姿初始化或优化参考。
    kfptr pRef = mLastFrame->mpReferenceKF;

    //从变量 mlRelativeFramePoses 中提取上一帧的 相对位姿变换矩阵 𝑇𝑙𝑟。Tlr: 表示当前帧与参考关键帧之间的相对位姿变换，来源于前面步骤的位姿估计和优化。
    cv::Mat Tlr = mlRelativeFramePoses.back();
      
    //更新上一帧的位姿, 计算新的位姿：𝑇𝑙=𝑇𝑙𝑟⋅𝑇𝑟𝑒𝑓
    //其中：𝑇𝑙𝑟 : 当前帧相对于参考关键帧的位姿变换矩阵。𝑇𝑟𝑒𝑓 : 参考关键帧的绝对位姿（世界坐标系中的位姿）。𝑇𝑙 : 更新后的上一帧的绝对位姿。
    // 调用 SetPose() 设置位姿到上一帧。
    mLastFrame->SetPose(Tlr*pRef->GetPose());
}


//定义了视觉 SLAM 系统中的 基于运动模型的跟踪函数 Tracking::TrackWithMotionModel()，它利用上一帧的位姿和速度信息预测当前帧的初始位姿，并进行特征匹配和优化。
//该函数的主要任务是：使用上一帧的位姿和速度预测当前帧的位姿。基于投影模型进行特征匹配，以提高跟踪效率和准确性。利用匹配结果优化当前帧位姿，并剔除误匹配点（离群点）。
//检查有效匹配数量，判断跟踪是否成功。
//适用场景：短期运动连续性： 在相机运动平滑的条件下，预测当前帧位姿，减少计算复杂度。实时跟踪： 避免大范围搜索，通过局部预测提高匹配效率。
bool Tracking::TrackWithMotionModel()
{
    //初始化匹配器, ORBmatcher： 用于基于 ORB 特征进行匹配。参数分析：0.9：描述子距离比率测试阈值（越小越严格）。true：启用交叉验证，提高匹配准确率。
    ORBmatcher matcher(0.9,true);

    // Update last frame pose according to its reference keyframe
    // Create "visual odometry" points if in Localization Mode
    // 更新上一帧位姿, 调用 UpdateLastFrame() 更新上一帧的位姿，使其与参考关键帧保持一致。
    // 确保上一帧的位姿考虑了局部优化的影响，提高预测精度。
    UpdateLastFrame();

   //使用运动模型预测当前帧位姿,  计算当前帧的初始位姿：𝑇𝑐𝑤(𝑐𝑢𝑟𝑟𝑒𝑛𝑡)=𝑉⋅𝑇𝑐𝑤(𝑙𝑎𝑠𝑡) ，为后续特征匹配提供起点。
   //  V: 上一帧的速度变换矩阵（通过两帧位姿计算得到）。 𝑇𝑐𝑤(𝑙𝑎𝑠𝑡)  : 上一帧的位姿矩阵。
    mCurrentFrame->SetPose(mVelocity*mLastFrame->mTcw);

    //清空地图点关联, 将当前帧中关联的地图点清空，为新的特征匹配做准备。
    fill(mCurrentFrame->mvpMapPoints.begin(),mCurrentFrame->mvpMapPoints.end(),nullptr);

    // Project points seen in previous frame
    //投影匹配, 将上一帧中的地图点投影到当前帧，通过局部搜索匹配特征点。
    //投影匹配基于位姿预测和几何约束，比直接暴力搜索更高效。搜索窗口大小设置为 7 个像素。
    int th;
    th=7;
    int nmatches = matcher.SearchByProjection(*mCurrentFrame,*mLastFrame,th);

    // If few matches, uses a wider window search
    //匹配不足时扩大窗口, 如果初始匹配数量不足 20 个，则扩大搜索窗口（14 像素）重新匹配，提高成功率。
    if(nmatches<20)
    {
        fill(mCurrentFrame->mvpMapPoints.begin(),mCurrentFrame->mvpMapPoints.end(),nullptr);
        nmatches = matcher.SearchByProjection(*mCurrentFrame,*mLastFrame,2*th);
    }

    // 匹配数量检查, 若匹配数量仍然不足 20 个，返回跟踪失败。
    if(nmatches<params::tracking::miTrackWithMotionModelInlierThresSearch) //20
        return false;

    // Optimize frame pose with all matches
    //使用 PnP 位姿优化 最小化重投影误差，进一步调整位姿估计结果。优化过程考虑所有匹配点，并剔除误匹配点。
    Optimizer::PoseOptimizationClient(*mCurrentFrame);

    // Discard outliers
    //剔除离群点, 在优化过程中检测到的离群点被移除，防止误匹配干扰。更新地图点状态，减少不可靠点的影响。
    //统计有效匹配点：nmatchesMap: 当前帧中观测次数大于 0 的有效地图点数量。
    int nmatchesMap = 0;
    for(int i =0; i<mCurrentFrame->N; i++)
    {
        if(mCurrentFrame->mvpMapPoints[i])
        {
            if(mCurrentFrame->mvbOutlier[i])
            {
                mpptr pMP = mCurrentFrame->mvpMapPoints[i];

                mCurrentFrame->mvpMapPoints[i]=nullptr;
                mCurrentFrame->mvbOutlier[i]=false;
                pMP->mbTrackInView = false;
                pMP->mLastFrameSeen = mCurrentFrame->mId;
                nmatches--;
            }
            else if(mCurrentFrame->mvpMapPoints[i]->Observations()>0)
                nmatchesMap++;
        }
    }

    //判断跟踪成功与否， 若有效匹配点数量超过阈值（10 个），返回跟踪成功。
     // 否则返回失败，系统可能需要回退到关键帧跟踪或重新初始化。
    return nmatchesMap>=params::tracking::miTrackWithMotionModelInlierThresOpt; //10
}

//定义了视觉 SLAM 系统中的 局部地图跟踪函数 Tracking::TrackLocalMap()，用于优化当前帧的位姿，并将其与局部地图进行匹配和验证。
//该函数的主要任务是：更新局部地图，提取当前帧附近的地图点，以便匹配特征点。
//搜索局部地图中的可见点，与当前帧进行特征匹配。
//优化当前帧的位姿，并统计有效匹配的内点数量。
//根据匹配点数量判断跟踪是否成功，为后续地图更新提供参考。

bool Tracking::TrackLocalMap()
{
    // We have an estimation of the camera pose and some map points tracked in the frame.
    // We retrieve the local map and try to find matches to points in the local map.
   // 更新局部地图, 调用 UpdateLocalMap() 更新局部地图信息，提取当前帧附近关键帧和地图点。
   //局部地图包含：与当前帧直接相关的关键帧及其关联的地图点。邻近关键帧的地图点，用于扩展局部地图范围。
    UpdateLocalMap();

   //搜索局部地图中的匹配点, 将局部地图中的三维点投影到当前帧，根据特征描述子和几何约束进行匹配。
    //投影匹配： 利用位姿信息预测地图点在当前帧中的位置，减少搜索范围，提高匹配效率。更新当前帧的地图点关联信息 mvpMapPoints，用于位姿优化。
    SearchLocalPoints();

    // Optimize Pose
    //优化当前帧位姿, 使用 PnP 优化 最小化重投影误差，调整当前帧的位姿.
    //T 是当前帧的位姿矩阵。𝑥𝑖  是图像中的特征点位置。𝑋𝑖  是三维地图点坐标。π 是相机投影函数。
    Optimizer::PoseOptimizationClient(*mCurrentFrame);

    //统计有效匹配内点, 遍历当前帧的地图点匹配结果：如果某个点未被标记为离群点 (outlier)，则将其计入有效内点数。
 //更新地图点的被观测次数 (IncreaseFound)，用于进一步筛选和优化。mnMatchesInliers: 表示当前帧有效匹配的内点数量。
    mnMatchesInliers = 0;

    // Update MapPoints Statistics
    for(int i=0; i<mCurrentFrame->N; i++)
    {
        if(mCurrentFrame->mvpMapPoints[i])
        {
            if(!mCurrentFrame->mvbOutlier[i])
            {
                mCurrentFrame->mvpMapPoints[i]->IncreaseFound();
                mnMatchesInliers++;
            }

        }
    }

    // Decide if the tracking was succesful
    // More restrictive if there was a relocalization recently
    // 判断跟踪是否成功, 重定位后的严格阈值判断
    //如果当前帧是刚完成重定位后的几帧内，采用更严格的判断条件：有效内点数必须大于 50 个。防止重定位之后立即出现跟踪丢失，提高鲁棒性。
    if(mCurrentFrame->mId.first<mLastRelocFrameId.first+params::tracking::miMaxFrames && mnMatchesInliers<50)
    {
        return false;
    }

//普通阈值判断, 在正常跟踪过程中，判断有效内点数量是否超过阈值（30 个）：true：跟踪成功。false：跟踪失败，需要进一步恢复或重新初始化。
    if(mnMatchesInliers<params::tracking::miTrackLocalMapInlierThres) //30
        return false;
    else
        return true;
}


//定义了视觉 SLAM 系统中的 关键帧插入条件判断函数 Tracking::NeedNewKeyFrame()，用于决定当前帧是否需要被插入为新的关键帧。
//关键帧的插入是视觉 SLAM 系统中维护地图和优化位姿的核心机制。本函数的主要任务是：
//判断局部建图模块是否可以接受新的关键帧。
//根据时间间隔、匹配点数量和当前跟踪状态，评估插入关键帧的必要性。
//确保关键帧插入过程不会影响局部建图和回环检测的运行。
//适用场景：关键帧稀疏化： 避免关键帧数量过多导致地图冗余和计算复杂度增加。地图扩展： 保持跟踪和地图的一致性，在需要新视角或新特征时添加关键帧。
bool Tracking::NeedNewKeyFrame()
{
    // If Local Mapping is freezed by a Loop Closure do not insert keyframes
    // 检查局部建图状态, 如果局部建图模块被停止（如因回环检测触发全局 BA），则暂停关键帧插入，避免冲突。
    if(mpLocalMapper->isStopped() || mpLocalMapper->stopRequested())
        return false;

  //检查重定位后帧数是否足够, 在重定位后的一段时间内（miMaxFrames），需要足够的跟踪稳定性才能插入新关键帧。
  //防止重定位后频繁插入关键帧导致地图冗余和优化开销增加。
    const int nKFs = mpMap->KeyFramesInMap();

    // Do not insert keyframes if not enough frames have passed from last relocalisation
    if(mCurrentFrame->mId.first<mLastRelocFrameId.first+params::tracking::miMaxFrames && nKFs>params::tracking::miMaxFrames)
    {
        return false;
    }

    // Tracked MapPoints in the reference keyframe
    //检查参考关键帧中的匹配点数量, 统计参考关键帧中观测到至少 nMinObs 次的地图点数量（nRefMatches）。
    //动态调整最小观测次数，以适应初始地图较小的情况（关键帧数量不足 2 时降为 2）。
    int nMinObs = 3;
    if(nKFs<=2)
        nMinObs=2;
    int nRefMatches = mpReferenceKF->TrackedMapPoints(nMinObs);

    // Local Mapping accept keyframes?
    //检查局部建图模块是否空闲, 如果局部建图模块正在忙于处理其他关键帧或进行优化，则暂停关键帧插入。
    //当局部建图空闲时，可以接受新的关键帧。
    bool bLocalMappingIdle = mpLocalMapper->AcceptKeyFrames();


//关键帧插入条件
//条件 1a: 最大帧间隔, 如果自上一个关键帧以来经过的帧数超过最大间隔（miMaxFrames），满足插入条件。
    // Condition 1a: More than "MaxFrames" have passed from last keyframe insertion
    const bool c1a = mCurrentFrame->mId.first>=mLastKeyFrameId.first+params::tracking::miMaxFrames;

    //条件 1b: 最小帧间隔且局部建图空闲, 若超过最小帧间隔（miMinFrames）且局部建图空闲，也满足插入条件。
    // Condition 1b: More than "MinFrames" have passed and Local Mapping is idle
    const bool c1b = (mCurrentFrame->mId.first>=mLastKeyFrameId.first+params::tracking::miMinFrames && bLocalMappingIdle);

    //条件 2: 匹配点数量不足, 如果当前帧的有效匹配点数量小于参考关键帧匹配点的阈值比例（mfThRefRatio），
    //且仍然高于最低匹配阈值（miMatchesInliersThres），则满足插入条件。
    // Condition 2: Few tracked points compared to reference keyframe. Lots of visual odometry compared to map matches.
    const bool c2 = ((mnMatchesInliers<nRefMatches*params::tracking::mfThRefRatio /*|| ratioMap<thMapRatio*/) && mnMatchesInliers>params::tracking::miMatchesInliersThres);


// 最终判断和关键帧插入, 只有在满足时间间隔条件（c1a 或 c1b）和匹配条件（c2）的情况下，才能插入新的关键帧。
// 如果局部建图模块忙，则发送中断 BA 信号，优先插入关键帧。
    if((c1a||c1b)&&c2)
    {
        // If the mapping accepts keyframes, insert keyframe.
        // Otherwise send a signal to interrupt BA
        if(bLocalMappingIdle)
        {
            return true;
        }
        else
        {
            mpLocalMapper->InterruptBA();  //中断BA
            return false;
        }
    }
    else
        return false;
}

//定义了视觉 SLAM 系统中的 关键帧创建函数 Tracking::CreateNewKeyFrame()，用于将当前帧插入为新的关键帧，并将其添加到地图和局部建图模块中。
//关键帧创建是 SLAM 系统中的关键步骤，主要任务包括：检查局部建图模块状态，确保可以安全插入关键帧。
//创建关键帧对象，并与当前帧的特征点和地图点关联。标记跨客户端共享的地图点，用于多机 SLAM。
//更新参考关键帧信息，并将新关键帧插入到局部建图模块中。更新跟踪模块中的关键帧状态，为后续跟踪提供支持。
void Tracking::CreateNewKeyFrame()
{
    // 检查局部建图模块状态, 调用 SetNotStop(true) 阻止局部建图模块停止，确保可以插入新的关键帧。
// 如果无法设置局部建图模块为活动状态，直接返回，防止关键帧插入与其他操作冲突（如全局 BA 或回环检测）。
    if(!mpLocalMapper->SetNotStop(true))
        return;

  //创建关键帧对象, pKF: 创建一个新的关键帧对象，基于当前帧的特征点和地图点。
  // 关键帧关联的模块包括：地图 (mpMap): 插入关键帧到地图中维护位姿和特征点信息。
  // 关键帧数据库 (mpKeyFrameDB): 用于回环检测和重定位。通信模块 (mpComm): 支持多客户端多机 SLAM。
    kfptr pKF{new KeyFrame(*mCurrentFrame,mpMap,mpKeyFrameDB,mpComm,eSystemState::CLIENT,-1)};

//标记跨客户端地图点, 获取新关键帧与地图点的匹配关系 (vpM)。遍历地图点，执行以下检查：跳过空指针或标记为“坏点”的地图点。
//如果地图点由其他客户端创建（跨客户端共享），调用 SetMultiUse() 标记其为多客户端共享地图点。
    std::vector<mpptr> vpM = pKF->GetMapPointMatches();
    for(vector<mpptr>::const_iterator vit = vpM.begin();vit!=vpM.end();++vit)
    {
        mpptr pMPi = *vit;

        if(!pMPi)
            continue;

        if(pMPi->isBad())
            continue;

        if(pMPi->mId.second != mClientId)
        {
            pMPi->SetMultiUse();
        }
    }

 // 更新参考关键帧信息, 将新创建的关键帧设为当前帧的参考关键帧，便于后续跟踪和优化。
    mpReferenceKF = pKF;
    mCurrentFrame->mpReferenceKF = pKF;

//插入关键帧到局部建图模块,将新关键帧添加到局部建图模块，以便进行地图扩展和局部 BA 优化。
    mpLocalMapper->InsertKeyFrame(pKF);

// 释放局部建图模块锁, 重置局部建图模块的状态，允许其继续运行和处理其他关键帧或优化任务。
    mpLocalMapper->SetNotStop(false);

// 更新关键帧状态，更新跟踪模块中的最新关键帧 ID 和指针，为后续帧提供跟踪和约束支持。
    mLastKeyFrameId = mCurrentFrame->mId;
    mpLastKeyFrame = pKF;
}


//定义了视觉 SLAM 系统中的 局部地图点搜索函数 Tracking::SearchLocalPoints()，用于将局部地图中的三维点投影到当前帧图像中，并尝试匹配特征点。
//该函数的主要任务是：清除当前帧已关联的无效地图点，并更新地图点的可见性统计信息。
//将局部地图点投影到当前帧中，检查其可视性（视锥体内）。使用投影匹配方法将可视地图点与当前帧特征点进行匹配。
//为后续位姿优化提供更多地图点约束，提高跟踪精度和鲁棒性。
//适用场景：
//局部地图约束增强： 增加匹配点数量，提高位姿估计精度。跟踪丢失恢复： 在跟踪质量较差时通过局部地图快速恢复匹配关系。
//动态环境适应： 适合短时间内移动物体较少的环境，依赖局部一致性约束。

void Tracking::SearchLocalPoints()
{
    // Do not search map points already matched
    // 清除当前帧中无效的地图点
    //遍历当前帧已经关联的地图点 (mvpMapPoints)：如果地图点被标记为“坏点”（质量较差或被移除），将其从当前帧的关联点列表中删除。
//对有效地图点，更新其可见性统计数据（IncreaseVisible()）。将地图点的“上次被看到的帧 ID”更新为当前帧 ID。
//将地图点的“可见状态”标记为 false（等待投影判断）
    for(vector<mpptr>::iterator vit=mCurrentFrame->mvpMapPoints.begin(), vend=mCurrentFrame->mvpMapPoints.end(); vit!=vend; vit++)
    {
        mpptr pMP = *vit;
        if(pMP)
        {
            if(pMP->isBad())
            {
                *vit = nullptr;
            }
            else
            {
                pMP->IncreaseVisible();
                pMP->mLastFrameSeen = mCurrentFrame->mId;
                pMP->mbTrackInView = false;
            }
        }
    }

 //遍历局部地图点并统计候选点, 遍历局部地图中的所有地图点 (mvpLocalMapPoints)：
//如果某个地图点已在当前帧中被处理，跳过并计入 seen。如果地图点为“坏点”，跳过并计入 bad。
    int nToMatch=0;
    int seen = 0;
    int bad = 0;
    int notinfrustrum = 0;

    // Project points in frame and check its visibility
    for(vector<mpptr>::iterator vit=mvpLocalMapPoints.begin(), vend=mvpLocalMapPoints.end(); vit!=vend; vit++)
    {
        mpptr pMP = *vit;
        if(pMP->mLastFrameSeen == mCurrentFrame->mId)
        {
            ++seen;
            continue;
        }
        if(pMP->isBad())
        {
            ++bad;
            continue;
        }
        // Project (this fills MapPoint variables for matching)
        // 检查地图点可视性, 使用 isInFrustum() 检查地图点是否位于当前帧的视锥体内，并考虑相机方向和视角。
       //投影过程中检查深度、视角和图像边界等条件。匹配阈值设置为 0.5，允许部分边界点进入匹配范围。
      //如果地图点在视锥体内，增加其可见性统计值，并计入待匹配点数 nToMatch。否则记录为不在视锥体中的点 notinfrustrum。
        if(mCurrentFrame->isInFrustum(pMP,0.5))
        {
            pMP->IncreaseVisible();
            nToMatch++;
        }
        else ++notinfrustrum;
    }

// 执行投影匹配,  如果存在待匹配的地图点（nToMatch > 0）：
//创建 ORB 特征匹配器，阈值设为 0.8（较宽松的匹配条件）。
//如果当前帧是最近刚完成重定位的帧，则放宽搜索窗口 th=5，允许更大的误差范围。
    if(nToMatch>0)
    {
        ORBmatcher matcher(0.8);
        int th = 1;
        // If the camera has been relocalised recently, perform a coarser search
        if(mCurrentFrame->mId.first<mLastRelocFrameId.first+2)
        {
            th=5;
        }

   // 投影匹配执行, 调用 SearchByProjection() 执行基于投影的特征点匹配：
   //将地图点投影到当前帧图像中，并在搜索窗口内寻找最佳匹配特征点。更新当前帧中的地图点关联信息 (mvpMapPoints)。
        matcher.SearchByProjection(*mCurrentFrame,mvpLocalMapPoints,th);
    }
}


//定义了视觉 SLAM 系统中的 局部地图更新函数 Tracking::UpdateLocalMap()，用于维护当前帧附近的局部地图点集合，以支持跟踪和优化过程。
//该函数主要任务包括：设置局部地图点，用于可视化和跟踪过程中的参考信息。
//更新局部关键帧和地图点信息，以便在局部范围内进行约束和匹配。
//将地图点关联到当前帧，为后续特征匹配和位姿优化提供基础。
void Tracking::UpdateLocalMap()
{
    // This is for visualization
    //更新局部地图点用于可视化, 调用 SetReferenceMapPoints() 将当前局部地图点集合设置为可视化参考点。
    // 可视化用途： 在 GUI 或图形界面中显示局部地图点，便于用户查看和调试地图构建过程。
    mpMap->SetReferenceMapPoints(mvpLocalMapPoints);

    // Update
    //  局部地图更新, 更新局部关键帧： 确定当前帧附近的关键帧集合，作为局部地图的框架。
  //更新局部地图点： 提取局部关键帧中的三维点，作为当前帧的匹配候选点。
//    UpdateLocalKeyFrames();
//    UpdateLocalPoints();

   // 获取所有地图点,   获取地图中所有的三维点，并将其作为当前帧的局部地图点集合。
    mvpLocalMapPoints = mpMap->GetAllMapPoints();
}


//定义了视觉 SLAM 系统中的 局部地图点更新函数 Tracking::UpdateLocalPoints()
void Tracking::UpdateLocalPoints()
{
    mvpLocalMapPoints.clear();

    for(vector<kfptr>::const_iterator itKF=mvpLocalKeyFrames.begin(), itEndKF=mvpLocalKeyFrames.end(); itKF!=itEndKF; itKF++)
    {
        kfptr pKF = *itKF;
        const vector<mpptr> vpMPs = pKF->GetMapPointMatches();

        int empty = 0;

        for(vector<mpptr>::const_iterator itMP=vpMPs.begin(), itEndMP=vpMPs.end(); itMP!=itEndMP; itMP++)
        {
            mpptr pMP = *itMP;
            if(!pMP)
            {
                ++empty;
                continue;
            }
            if(pMP->mTrackReferenceForFrame==mCurrentFrame->mId)
                continue;
            if(!pMP->isBad())
            {
                mvpLocalMapPoints.push_back(pMP);
                pMP->mTrackReferenceForFrame=mCurrentFrame->mId;
            }
        }
    }
}


void Tracking::UpdateLocalKeyFrames()
{
    // Each map point vote for the keyframes in which it has been observed
    map<kfptr,int> keyframeCounter;
    for(int i=0; i<mCurrentFrame->N; i++)
    {
        if(mCurrentFrame->mvpMapPoints[i])
        {
            mpptr pMP = mCurrentFrame->mvpMapPoints[i];
            if(!pMP->isBad())
            {
                const map<kfptr,size_t> observations = pMP->GetObservations();
                for(map<kfptr,size_t>::const_iterator it=observations.begin(), itend=observations.end(); it!=itend; it++)
                    keyframeCounter[it->first]++;
            }
            else
            {
                mCurrentFrame->mvpMapPoints[i]=nullptr;
            }
        }
    }

    if(keyframeCounter.empty())
        return;

    int max=0;
    kfptr pKFmax= nullptr;

    mvpLocalKeyFrames.clear();
    mvpLocalKeyFrames.reserve(3*keyframeCounter.size());

    // All keyframes that observe a map point are included in the local map. Also check which keyframe shares most points
    for(map<kfptr,int>::const_iterator it=keyframeCounter.begin(), itEnd=keyframeCounter.end(); it!=itEnd; it++)
    {
        kfptr pKF = it->first;

        if(pKF->isBad())
            continue;

        if(it->second>max)
        {
            max=it->second;
            pKFmax=pKF;
        }

        mvpLocalKeyFrames.push_back(it->first);
        pKF->mTrackReferenceForFrame = mCurrentFrame->mId;
    }


    // Include also some not-already-included keyframes that are neighbors to already-included keyframes
    for(vector<kfptr>::const_iterator itKF=mvpLocalKeyFrames.begin(), itEndKF=mvpLocalKeyFrames.end(); itKF!=itEndKF; itKF++)
    {
        // Limit the number of keyframes
        if(mvpLocalKeyFrames.size()>80)
            break;

        kfptr pKF = *itKF;

        const vector<kfptr> vNeighs = pKF->GetBestCovisibilityKeyFrames(10);

        for(vector<kfptr>::const_iterator itNeighKF=vNeighs.begin(), itEndNeighKF=vNeighs.end(); itNeighKF!=itEndNeighKF; itNeighKF++)
        {
            kfptr pNeighKF = *itNeighKF;
            if(!pNeighKF->isBad())
            {
                if(pNeighKF->mTrackReferenceForFrame!=mCurrentFrame->mId)
                {
                    mvpLocalKeyFrames.push_back(pNeighKF);
                    pNeighKF->mTrackReferenceForFrame=mCurrentFrame->mId;
                    break;
                }
            }
        }

        const set<kfptr> spChilds = pKF->GetChilds();
        for(set<kfptr>::const_iterator sit=spChilds.begin(), send=spChilds.end(); sit!=send; sit++)
        {
            kfptr pChildKF = *sit;
            if(!pChildKF->isBad())
            {
                if(pChildKF->mTrackReferenceForFrame!=mCurrentFrame->mId)
                {
                    mvpLocalKeyFrames.push_back(pChildKF);
                    pChildKF->mTrackReferenceForFrame=mCurrentFrame->mId;
                    break;
                }
            }
        }

        kfptr pParent = pKF->GetParent();
        if(pParent)
        {
            if(pParent->mTrackReferenceForFrame!=mCurrentFrame->mId)
            {
                mvpLocalKeyFrames.push_back(pParent);
                pParent->mTrackReferenceForFrame=mCurrentFrame->mId;
                break;
            }
        }
    }

    if(pKFmax)
    {
        mpReferenceKF = pKFmax;
        mCurrentFrame->mpReferenceKF = mpReferenceKF;
    }
}


//定义了视觉 SLAM 系统中的 重置函数 Tracking::Reset()，用于在系统出现异常或严重跟踪失败时，清空相关模块和数据结构，恢复到初始状态
//该函数的主要任务是：重置所有相关模块，包括查看器、局部建图、关键帧数据库和地图管理器。
//清空所有关键数据结构和缓存信息，如帧位姿、时间戳和跟踪状态。
//清除关键帧、地图点和帧的唯一 ID，确保重启后索引从零开始。
//恢复系统状态为未接收图像的初始状态，准备重新初始化。
//适用场景：
//跟踪失败恢复： 当系统无法继续跟踪时，重置并重新初始化。
//地图重建： 需要重建地图或更改数据集时，清空当前数据。
//系统异常处理： 关键模块异常或数据损坏时，通过重置恢复正常工作状态。

void Tracking::Reset()
{

    cout << "System Reseting" << endl;
    //重置查看器 (Viewer), 清空可视化缓存数据，例如关键帧、地图点和轨迹信息。恢复查看器初始状态，为新的数据输入做准备。
    mpViewer->RequestReset();

    //重置局部建图模块 (Local Mapper), 清空局部优化过程中的关键帧和地图点缓存。
    // 停止当前正在运行的线程，准备重新初始化。
    mpLocalMapper->RequestReset();
    //清空关键帧数据库，删除所有关键帧的 BoW 描述子和索引信息。重置数据库，为新的关键帧插入做准备。
    mpKeyFrameDB->clear();

   //重置 ID 计数器, 将关键帧、普通帧和地图点的 ID 计数器重置为 0：确保新插入的元素从 ID=0 开始，不会与之前数据混淆。
   // 适用于重新构建地图或场景时，避免 ID 冲突。
    KeyFrame::nNextId = 0;
    Frame::nNextId = 0;
    MapPoint::nNextId = 0;
    //  重置状态标志, 将系统状态设置为未接收图像 (NO_IMAGES_YET)：停止当前跟踪任务，等待新图像输入开始初始化。
    // 避免误操作导致状态混乱。
    mState = NO_IMAGES_YET;

    // 清除初始化器, 重置初始化器：释放内存，防止旧初始化器影响新初始化过程。
   // 确保重新初始化时重新创建初始化器，适应新的输入数据。
    if(mpInitializer)
        mpInitializer = nullptr;

  // 通信模块重置, 请求通信模块重置：清除分布式 SLAM 中的客户端状态和缓存信息。
  // 恢复通信模块为初始状态，准备接收新的客户端连接或数据同步请求。
    mpComm->RequestReset();

   //清空地图数据,   清除地图中的所有关键帧和地图点：删除三维空间中的所有位置信息，恢复到空地图状态。
   // 避免旧地图与新数据冲突，确保一致性。
    mpMap->clear();

   // 清空缓存数据, 清除跟踪过程中的缓存信息，包括：
   //帧间相对位姿 (mlRelativeFramePoses)： 清空用于跟踪的位姿缓存。
  //参考关键帧指针 (mlpReferences)： 清除关键帧引用记录。
  //时间戳缓存 (mlFrameTimes)： 清空帧时间记录，防止时间错位。
  //丢失状态记录 (mlbLost)： 清除跟踪丢失状态标记，恢复正常跟踪状态。

    mlRelativeFramePoses.clear();
    mlpReferences.clear();
    mlFrameTimes.clear();
    mlbLost.clear();

    cout << "Reseting Done..." << endl;
}

//定义了视觉 SLAM 系统中的 参考关键帧获取函数 Tracking::GetReferenceKF()，用于获取当前参考关键帧的指针 (mpReferenceKF)
Tracking::kfptr Tracking::GetReferenceKF()
{
    //Works w/o mutex, since tracking is locked when this method is called by comm
  //线程安全检查, mpCC: 通信控制模块指针，管理跟踪过程中的线程锁定状态。IsTrackingLocked()： 检查跟踪模块是否已经锁定：
  //锁定状态： 确保跟踪过程不会与其他线程竞争资源，保证数据一致性。非锁定状态： 输出警告信息，提醒可能存在数据竞争或多线程访问冲突风险。

    if(!mpCC->IsTrackingLocked())
        cout << "\033[1;33m!!! WARN !!!\033[0m " << __func__ << ":" << __LINE__ << " Tracking assumed to be locked " << endl;

    // 返回参考关键帧指针, mpReferenceKF: 存储当前帧与关键帧之间的几何关系，用于以下功能：
    //位姿估计和约束：提供局部优化的参考。
   // 特征点匹配：基于参考关键帧执行特征点投影和匹配。
   // 数据同步：支持多客户端之间共享关键帧信息，增强分布式 SLAM 的一致性。
    return mpReferenceKF;
}

} //end ns
