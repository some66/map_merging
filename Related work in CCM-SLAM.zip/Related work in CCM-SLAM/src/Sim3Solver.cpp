#include <cslam/Sim3Solver.h>

namespace cslam {

Sim3Solver::Sim3Solver(kfptr pKF1, kfptr pKF2, const vector<mpptr > &vpMatched12, const bool bFixScale):
    mnIterations(0), mnBestInliers(0), mbFixScale(bFixScale)
{
    mpKF1 = pKF1;
    mpKF2 = pKF2;

    vector<mpptr> vpKeyFrameMP1 = pKF1->GetMapPointMatches();

    mN1 = vpMatched12.size();

    mvpMapPoints1.reserve(mN1);
    mvpMapPoints2.reserve(mN1);
    mvpMatches12 = vpMatched12;
    mvnIndices1.reserve(mN1);
    mvX3Dc1.reserve(mN1);
    mvX3Dc2.reserve(mN1);

    cv::Mat Rcw1 = pKF1->GetRotation();
    cv::Mat tcw1 = pKF1->GetTranslation();
    cv::Mat Rcw2 = pKF2->GetRotation();
    cv::Mat tcw2 = pKF2->GetTranslation();

    mvAllIndices.reserve(mN1);

    size_t idx=0;
    for(int i1=0; i1<mN1; i1++)
    {
        if(vpMatched12[i1])
        {
            mpptr pMP1 = vpKeyFrameMP1[i1];
            mpptr pMP2 = vpMatched12[i1];

            if(!pMP1)
            {
                cout << "!pMP1" << endl;
                continue;
            }

            if(pMP1->isBad() || pMP2->isBad())
            {
                continue;
            }

            int indexKF1 = pMP1->GetIndexInKeyFrame(pKF1);
            int indexKF2 = pMP2->GetIndexInKeyFrame(pKF2);

//            cout << "#obs pMP1: " << pMP1->GetObservations().size();
//            cout << "#obs pMP2: " << pMP2->GetObservations().size();

            if(indexKF1<0 || indexKF2<0)
            {
//                if (indexKF1<0) cout << "indexKF1<0" << endl;
//                if (indexKF2<0) cout << "indexKF2<0" << endl;
                continue;
            }

            const cv::KeyPoint &kp1 = pKF1->mvKeysUn[indexKF1];
            const cv::KeyPoint &kp2 = pKF2->mvKeysUn[indexKF2];

            const float sigmaSquare1 = pKF1->mvLevelSigma2[kp1.octave];
            const float sigmaSquare2 = pKF2->mvLevelSigma2[kp2.octave];

            mvnMaxError1.push_back(9.210*sigmaSquare1);
            mvnMaxError2.push_back(9.210*sigmaSquare2);

            mvpMapPoints1.push_back(pMP1);
            mvpMapPoints2.push_back(pMP2);
            mvnIndices1.push_back(i1);

            cv::Mat X3D1w = pMP1->GetWorldPos();
            mvX3Dc1.push_back(Rcw1*X3D1w+tcw1);

            cv::Mat X3D2w = pMP2->GetWorldPos();
            mvX3Dc2.push_back(Rcw2*X3D2w+tcw2);

            mvAllIndices.push_back(idx);
            idx++;
        }
    }

    mK1 = pKF1->mK;
    mK2 = pKF2->mK;

    FromCameraToImage(mvX3Dc1,mvP1im1,mK1);
    FromCameraToImage(mvX3Dc2,mvP2im2,mK2);

    SetRansacParameters();
}

void Sim3Solver::SetRansacParameters(double probability, int minInliers, int maxIterations)
{
    //std::cout << "mnInliersi: " << minInliers<< std::endl; 
    mRansacProb = probability;
    mRansacMinInliers = minInliers;
    mRansacMaxIts = maxIterations;

    N = mvpMapPoints1.size(); // number of correspondences

    mvbInliersi.resize(N);

    // Adjust Parameters according to number of correspondences
    float epsilon = (float)mRansacMinInliers/N;

    // Set RANSAC iterations according to probability, epsilon, and max iterations
    int nIterations;

    if(mRansacMinInliers==N)
        nIterations=1;
    else
        nIterations = ceil(log(1-mRansacProb)/log(1-pow(epsilon,3)));

    mRansacMaxIts = max(1,min(nIterations,mRansacMaxIts));

    mnIterations = 0;
}


//函数可以返回最优的变换矩阵mBestT12或在特定条件下返回空矩阵。
//bNoMore：这是一个引用布尔值，如果无法再进行迭代（例如，已达到最大迭代次数或未找到足够的内点），该值会被设置为true。
//vbInliers：这个向量用于记录哪些点被认为是内点（符合估计的模型）。
//nInliers：这个引用整数被设置为内点的数量。
cv::Mat Sim3Solver::iterate(int nIterations, bool &bNoMore, vector<bool> &vbInliers, int &nInliers)
{ 
    bNoMore = false;
    //将vbInliers初始化为包含false的向量，长度为mN1（一组点的数量）。
    vbInliers = vector<bool>(mN1,false);
    //内点计数nInliers设置为0。
    nInliers=0;

//    if(mVerboseMode == -7 || mVerboseMode == -8) cout << "Sim3Solver::iterate --> N: " << N << endl;
//    if(mVerboseMode == -7 || mVerboseMode == -8) cout << "Sim3Solver::iterate --> mN1: " << mN1 << endl;

//如果输入点的数量少于所需的最小内点数mRansacMinInliers，则直接返回并设置bNoMore为true。
    if(N<mRansacMinInliers)
    {
        bNoMore = true;
        return cv::Mat();
    }

//这个向量用于存储可用于随机选择的点的索引。在迭代过程中，每次从这个向量中随机选择三个索引，用以获取对应的3D点，以计算变换。
//随着每次迭代使用完这些索引，它们会从向量中移除，确保每个点在单次迭代中只被选用一次。
    vector<size_t> vAvailableIndices;

//初始化两个cv::Mat对象, 这两个矩阵用于存储每次迭代中随机选取的三个3D点。
    cv::Mat P3Dc1i(3,3,CV_32F);   
    cv::Mat P3Dc2i(3,3,CV_32F);

    int nCurrentIterations = 0;
    //进行多次迭代，直到达到指定的迭代次数nIterations或全局迭代次数mnIterations达到最大限度mRansacMaxIts。
    while(mnIterations<mRansacMaxIts && nCurrentIterations<nIterations)
    {
        nCurrentIterations++;
        mnIterations++;

        vAvailableIndices = mvAllIndices;

        // Get min set of points
        //选择三个点是因为在三维空间中，至少需要三个点来确定一个Sim3变换（包括旋转、平移和尺度）。
        for(short i = 0; i < 3; ++i)
        {
            //随机选择索引, 在这里使用DUtils::Random::RandomInt函数从0到vAvailableIndices.size()-1的范围内生成一个随机数。
            //这个随机数randi作为选中索引在vAvailableIndices中的位置。
            int randi = DUtils::Random::RandomInt(0, vAvailableIndices.size()-1);

        //idx是从vAvailableIndices中获取的实际索引
        //使用这个索引从两组3D点数组mvX3Dc1和mvX3Dc2中提取相应的点，然后复制到P3Dc1i和P3Dc2i矩阵的第i列。
        //这两个数组分别包含第一组和第二组的3D点数据，其中每个元素都是一个包含x、y、z坐标的结构或对象。
            int idx = vAvailableIndices[randi];
            mvX3Dc1[idx].copyTo(P3Dc1i.col(i));
            mvX3Dc2[idx].copyTo(P3Dc2i.col(i));

        //  vAvailableIndices[idx] = vAvailableIndices.back();
        //更新可用索引向量, 选择过的索引randi被替换为vAvailableIndices中的最后一个元素，
        //然后通过pop_back()方法从向量中移除，以确保每个点只被随机选择一次。
            vAvailableIndices[randi] = vAvailableIndices.back();
            vAvailableIndices.pop_back();
        }

       //调用ComputeSim3(P3Dc1i, P3Dc2i)计算从P3Dc1i到P3Dc2i的Sim3变换。
       //函数来自于sim3solver.cpp文件中
        ComputeSim3(P3Dc1i,P3Dc2i);

       //CheckInliers()函数将评估当前的Sim3变换，并更新内点的数目mnInliersi。
        CheckInliers();

        //std::cout << "mnInliersi: " << mnInliersi<< std::endl; 一直是0
        //std::cout << "mnBestInliers: " << mnBestInliers << std::endl;一直是0
        //如果当前的内点数目mnInliersi超过了之前的最好结果mnBestInliers，更新最好的内点集、变换矩阵、旋转、平移和尺度参数。
        if(mnInliersi>=mnBestInliers)
        {
            mvbBestInliers = mvbInliersi;
            mnBestInliers = mnInliersi;
            mBestT12 = mT12i.clone();
            mBestRotation = mR12i.clone();
            mBestTranslation = mt12i.clone();
            mBestScale = ms12i;

          // std::cout << "mnInliersi: " << mnInliersi<< std::endl; 一直是0
           //  std::cout << "mRansacMinInliers: " << mRansacMinInliers << std::endl;一直是6
           //如果内点数超过了最小内点阈值mRansacMinInliers，则设置输出内点标志vbInliers，更新nInliers，并返回最优的变换矩阵mBestT12。
            if(mnInliersi>mRansacMinInliers)
            {
                nInliers = mnInliersi;
                for(int i=0; i<N; i++)
                    if(mvbInliersi[i])
                        vbInliers[mvnIndices1[i]] = true;
                  
                 //cout << "!!!FENG YU XUAN !!! 222" << endl;         
                return mBestT12;
            }
        }
    }
     //如果达到了最大迭代次数，设置bNoMore为true。
    if(mnIterations>=mRansacMaxIts)
        bNoMore=true;
    return cv::Mat();
}




cv::Mat Sim3Solver::find(vector<bool> &vbInliers12, int &nInliers)
{
    bool bFlag;
    return iterate(mRansacMaxIts,bFlag,vbInliers12,nInliers);
}

void Sim3Solver::ComputeCentroid(cv::Mat &P, cv::Mat &Pr, cv::Mat &C)
{
    cv::reduce(P,C,1,CV_REDUCE_SUM);
    C = C/P.cols;

    for(int i=0; i<P.cols; i++)
    {
        Pr.col(i)=P.col(i)-C;
    }
}


//计算两组3D点之间的相似性变换（包括缩放、旋转和平移）的详尽实现。
void Sim3Solver::ComputeSim3(cv::Mat &P1, cv::Mat &P2)
{
    // Custom implementation of:
    // Horn 1987, Closed-form solution of absolute orientataion using unit quaternions

    // Step 1: Centroid and relative coordinates
    //步骤1：质心和相对坐标, 
    //质心计算： 计算两组点（P1 和 P2）的质心（O1 和 O2）。质心是每组中所有点的平均位置。
    //相对坐标： 将每组点平移到以其质心为原点，得到 Pr1 和 Pr2。这一步通过关注点的相对位置来促进对齐过程。
    cv::Mat Pr1(P1.size(),P1.type()); // Relative coordinates to centroid (set 1)
    cv::Mat Pr2(P2.size(),P2.type()); // Relative coordinates to centroid (set 2)
    cv::Mat O1(3,1,Pr1.type()); // Centroid of P1
    cv::Mat O2(3,1,Pr2.type()); // Centroid of P2

    ComputeCentroid(P1,Pr1,O1);
    ComputeCentroid(P2,Pr2,O2);

    // Step 2: Compute M matrix
    //步骤2：计算M矩阵
    //交叉协方差矩阵（M）： M 矩阵通过计算 P2 的相对坐标矩阵与 P1 的相对坐标矩阵的转置的乘积来得到。
    //M 矩阵对确定两组点集之间的旋转至关重要。
    cv::Mat M = Pr2*Pr1.t();

    // Step 3: Compute N matrix
  //步骤3：计算N矩阵,  这个矩阵是由 M 矩阵的特定元素的和与差构成的。它用于形成旋转的四元数表示。
    double N11, N12, N13, N14, N22, N23, N24, N33, N34, N44;

    cv::Mat N(4,4,P1.type());

    N11 = M.at<float>(0,0)+M.at<float>(1,1)+M.at<float>(2,2);
    N12 = M.at<float>(1,2)-M.at<float>(2,1);
    N13 = M.at<float>(2,0)-M.at<float>(0,2);
    N14 = M.at<float>(0,1)-M.at<float>(1,0);
    N22 = M.at<float>(0,0)-M.at<float>(1,1)-M.at<float>(2,2);
    N23 = M.at<float>(0,1)+M.at<float>(1,0);
    N24 = M.at<float>(2,0)+M.at<float>(0,2);
    N33 = -M.at<float>(0,0)+M.at<float>(1,1)-M.at<float>(2,2);
    N34 = M.at<float>(1,2)+M.at<float>(2,1);
    N44 = -M.at<float>(0,0)-M.at<float>(1,1)+M.at<float>(2,2);

    N = (cv::Mat_<float>(4,4) << N11, N12, N13, N14,
                                 N12, N22, N23, N24,
                                 N13, N23, N33, N34,
                                 N14, N24, N34, N44);


    // Step 4: Eigenvector of the highest eigenvalue
    //最大特征值的特征向量
    //对矩阵 N 进行特征分解。对应于最大特征值的特征向量代表了所需旋转的四元数。
    //这个四元数随后被转换为角轴表示，这种表示更直观且对后续计算更有用。
    cv::Mat eval, evec;

    cv::eigen(N,eval,evec); //evec[0] is the quaternion of the desired rotation

    cv::Mat vec(1,3,evec.type());
    (evec.row(0).colRange(1,4)).copyTo(vec); //extract imaginary part of the quaternion (sin*axis)

    // Rotation angle. sin is the norm of the imaginary part, cos is the real part
    double ang=atan2(norm(vec),evec.at<float>(0,0));

    vec = 2*ang*vec/norm(vec); //Angle-axis representation. quaternion angle is the half

    mR12i.create(3,3,P1.type());

    cv::Rodrigues(vec,mR12i); // computes the rotation matrix from angle-axis

    // Step 5: Rotate set 2
    //步骤5：旋转第二组点, 使用从角轴表示通过Rodrigues旋转公式得到的旋转矩阵，旋转 P2 的相对坐标，使其与 P1 对齐。
    cv::Mat P3 = mR12i*Pr2;

    // Step 6: Scale
//步骤6：缩放,  如果未固定缩放（mbFixScale 为假），则计算它为 Pr1 与旋转后的 P2（现在为 P3）的点积与 P3 元素平方和的比率。
//这个缩放因子调整第二组点的大小以匹配第一组。
    if(!mbFixScale)
    {
        double nom = Pr1.dot(P3);
        cv::Mat aux_P3(P3.size(),P3.type());
        aux_P3=P3;
        cv::pow(P3,2,aux_P3);
        double den = 0;

        for(int i=0; i<aux_P3.rows; i++)
        {
            for(int j=0; j<aux_P3.cols; j++)
            {
                den+=aux_P3.at<float>(i,j);
            }
        }

        ms12i = nom/den;
    }
    else
        ms12i = 1.0f;

    // Step 7: Translation
    //平移向量（mt12i）通过将缩放和旋转后的 P2 的质心平移到 P1 的质心来确定。
    mt12i.create(1,3,P1.type());
    mt12i = O1 - ms12i*mR12i*O2;

    // Step 8: Transformation
    //步骤8：最终变换矩阵
    // Step 8.1 T12
    //T12： 从 P1 到 P2 的变换矩阵使用缩放因子、旋转矩阵和平移向量组装。
    mT12i = cv::Mat::eye(4,4,P1.type());

    cv::Mat sR = ms12i*mR12i;

    sR.copyTo(mT12i.rowRange(0,3).colRange(0,3));
    mt12i.copyTo(mT12i.rowRange(0,3).col(3));

    // Step 8.2 T21
    //T21： 同样计算从 P2 到 P1 的逆变换矩阵。它使用缩放和旋转的逆来正确地将点从 P2 映射回 P1。
    mT21i = cv::Mat::eye(4,4,P1.type());
    cv::Mat sRinv = (1.0/ms12i)*mR12i.t();

    sRinv.copyTo(mT21i.rowRange(0,3).colRange(0,3));
    cv::Mat tinv = -sRinv*mt12i;
    tinv.copyTo(mT21i.rowRange(0,3).col(3));
}


void Sim3Solver::CheckInliers()
{
    vector<cv::Mat> vP1im2, vP2im1;
    Project(mvX3Dc2,vP2im1,mT12i,mK1);
    Project(mvX3Dc1,vP1im2,mT21i,mK2);

    mnInliersi=0;

    for(size_t i=0; i<mvP1im1.size(); i++)
    {
        cv::Mat dist1 = mvP1im1[i]-vP2im1[i];
        cv::Mat dist2 = vP1im2[i]-mvP2im2[i];

        const float err1 = dist1.dot(dist1);
        const float err2 = dist2.dot(dist2);

        if(err1<mvnMaxError1[i] && err2<mvnMaxError2[i])
        {
            mvbInliersi[i]=true;
            mnInliersi++;
        }
        else
            mvbInliersi[i]=false;
    }
}


cv::Mat Sim3Solver::GetEstimatedRotation()
{
    return mBestRotation.clone();
}

cv::Mat Sim3Solver::GetEstimatedTranslation()
{
    return mBestTranslation.clone();
}

float Sim3Solver::GetEstimatedScale()
{
    return mBestScale;
}

void Sim3Solver::Project(const vector<cv::Mat> &vP3Dw, vector<cv::Mat> &vP2D, cv::Mat Tcw, cv::Mat K)
{
    cv::Mat Rcw = Tcw.rowRange(0,3).colRange(0,3);
    cv::Mat tcw = Tcw.rowRange(0,3).col(3);
    const float &fx = K.at<float>(0,0);
    const float &fy = K.at<float>(1,1);
    const float &cx = K.at<float>(0,2);
    const float &cy = K.at<float>(1,2);

    vP2D.clear();
    vP2D.reserve(vP3Dw.size());

    for(size_t i=0, iend=vP3Dw.size(); i<iend; i++)
    {
        cv::Mat P3Dc = Rcw*vP3Dw[i]+tcw;
        const float invz = 1/(P3Dc.at<float>(2));
        const float x = P3Dc.at<float>(0)*invz;
        const float y = P3Dc.at<float>(1)*invz;

        vP2D.push_back((cv::Mat_<float>(2,1) << fx*x+cx, fy*y+cy));
    }
}

void Sim3Solver::FromCameraToImage(const vector<cv::Mat> &vP3Dc, vector<cv::Mat> &vP2D, cv::Mat K)
{
    const float &fx = K.at<float>(0,0);
    const float &fy = K.at<float>(1,1);
    const float &cx = K.at<float>(0,2);
    const float &cy = K.at<float>(1,2);

    vP2D.clear();
    vP2D.reserve(vP3Dc.size());

    for(size_t i=0, iend=vP3Dc.size(); i<iend; i++)
    {
        const float invz = 1/(vP3Dc[i].at<float>(2));
        const float x = vP3Dc[i].at<float>(0)*invz;
        const float y = vP3Dc[i].at<float>(1)*invz;

        vP2D.push_back((cv::Mat_<float>(2,1) << fx*x+cx, fy*y+cy));
    }
}

}
