/**
* This file is part of CCM-SLAM.
*
* Copyright (C): Patrik Schmuck <pschmuck at ethz dot ch> (ETH Zurich)
* For more information see <https://github.com/patriksc/CCM-SLAM>
*
* CCM-SLAM is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* CCM-SLAM is based in the monocular version of ORB-SLAM2 by Raúl Mur-Artal.
* CCM-SLAM partially re-uses modules of ORB-SLAM2 in modified or unmodified condition.
* For more information see <https://github.com/raulmur/ORB_SLAM2>.
*
* CCM-SLAM is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CCM-SLAM. If not, see <http://www.gnu.org/licenses/>.
*/

#include <cslam/MapMerger.h>

namespace cslam {

 //使用于MapMatcher.cpp中
//matchptr pMatcher：这个参数是一个智能指针，指向一个匹配器对象。
//matchptr很可能是std::shared_ptr或类似的智能指针类型，用于自动管理资源（如自动释放内存）。匹配器对象负责执行地图之间的数据匹配。
MapMerger::MapMerger(matchptr pMatcher)
    : bIsBusy(false), mpMatcher(pMatcher)
//bIsBusy(false)：这个成员变量可能用于表示MapMerger对象当前是否在执行某个任务。这里在构造函数中被初始化为false，表明在创建时对象是空闲的。
//mpMatcher(pMatcher)：将传入的匹配器指针pMatcher赋值给类的成员变量mpMatcher。这样，MapMerger对象可以使用这个匹配器来执行地图合并任务。
{
    if(!mpMatcher)   //确认传入的匹配器指针不是空的。如果匹配器指针为空，则后续使用该指针时将导致程序崩溃。
    {
        ROS_ERROR_STREAM("In \" MapMerger::MapMerger()\": nullptr passed");  //通过ROS的错误流输出一条错误信息。
        throw estd::infrastructure_ex();   //抛出一个名为estd::infrastructure_ex的异常
        //
    }
}

//使用于MapMatcher.cpp中
//目的是将两个地图进行合并。这种合并基于地图匹配的结果。
//MapMerger::mapptr：这是一个由 MapMerger 类定义的类型，很可能是指向地图的智能指针，用于自动管理地图对象的生命周期。
//mapptr pMapCurr：当前活动或局部地图的指针。
//mapptr pMapMatch：需要与当前地图合并的另一个地图的指针。
//vector<MapMatchHit> vMatchHits：一个包含地图匹配结果的向量，每个 MapMatchHit 可能包含关于两个地图之间如何对齐和匹配的信息。
//SLAM系统中合并两张地图的详细过程，使用多个技术步骤确保地图的正确性和一致性。
//代码中不仅包括了基本的合并逻辑，还处理了地图更新、错误检查、锁定机制，以及在必要时终止正在进行的全局BA.

MapMerger::mapptr MapMerger::MergeMaps(mapptr pMapCurr, mapptr pMapMatch, vector<MapMatchHit> vMatchHits)
{
    
    // Make sure no other module can start GBA
    //初始化一个标志变量，用于指示是否存在阻止启动GBA的条件。
    bool bProblem = false;

//检查两个地图的GBA启动状态：这两个条件检查每个地图对象是否设置了禁止启动GBA的状态。
//如果任一地图处于此状态，将 bProblem 标志设置为 true，表示存在问题。
    if(pMapCurr->isNoStartGBA())
    {
        bProblem = true;
    }

    if(pMapMatch->isNoStartGBA())
    {
        bProblem = true;
    }

// 如果检测到问题（即 bProblem 为 true），则进入等待循环，直到两个地图都不再禁止启动GBA。
// 这通过持续检查地图的状态并等待直到状态变更来实现。
    if(bProblem)
    {
        //在等待期间，会定期输出等待信息，包括当前函数名称和代码行号，以便于问题跟踪和调试。
        std::cout << __func__ << ":" << __LINE__ << " Waiting for GBA to be able to Start" << std::endl;
       // 使用 usleep(params::timings::miLockSleep); 函数调用来暂停执行，防止无限循环占用过多处理资源。
       // 这里 params::timings::miLockSleep 是定义的等待时长。
        while(pMapCurr->isNoStartGBA() || pMapMatch->isNoStartGBA())
        {
            usleep(params::timings::miLockSleep);
        }
        std::cout << __func__ << ":" << __LINE__  << "Continue" << std::endl;
    }

//在确认无其他模块可以或正在尝试启动GBA后，将两个地图的状态设置为禁止启动GBA：这是为了确保在合并操作进行期间不会有新的GBA被触发。
    pMapCurr->setNoStartGBA();
    pMapMatch->setNoStartGBA();

    // If a Global Bundle Adjustment is running, abort it
    //安全停止正在运行的GBA： 如果任一地图正在进行GBA，该过程将被停止，以便进行地图合并。
    if(pMapCurr->isRunningGBA())
        pMapCurr->StopGBA();

    if(pMapMatch->isRunningGBA())
        pMapMatch->StopGBA();

   //设置忙碌状态： SetBusy方法可能用来设置一个标志，表示当前对象正在处理重要任务，防止其他进程干扰。
    this->SetBusy();

    // 这些布尔变量被初始化为 false，用于后续追踪和管理各个中央控制器（Central Controllers, CCs）的状态。
    // 这些变量可能用于记录是否已经对每个CC进行了某种特定处理，如锁定操作、状态更新或数据同步等。
    bool b0 = false;
    bool b1 = false;
    bool b2 = false;
    bool b3 = false;

// 从当前地图 (pMapCurr) 和匹配地图 (pMapMatch) 获取中央控制器的指针集合。
// 每个 ccptr（可能是智能指针类型）指向一个中央控制器对象，这些对象负责管理和控制与其关联的地图和关键帧数据。
// 这些中央控制器通常负责执行如数据同步、状态管理、资源调度等任务，并在多客户端系统中起到协调各个节点行为的作用。

//注意pMapCurr的ID与vMatchHits的第一帧是没有关系的。因为MAP的ID是一开始就固定的，但是关键帧(a,b)or(b,a)选择从哪个机器人来是随机的。
    set<ccptr> spCCC = pMapCurr->GetCCPtrs();    
    set<ccptr> spCCM = pMapMatch->GetCCPtrs();
//通过 GetCCPtrs() 获取到所有的客户端控制器，系统能够集中处理诸如数据同步、任务分配和状态监控等任务。


//锁定机制：对相关的客户端控制器（Central Controllers）进行多种锁定，包括通信锁、映射锁和位置识别锁，确保在合并过程中数据不会被外部更改。
    #ifdef LOGGING  //预处理指令，用于在编译时检查是否定义了LOGGING宏。如果定义了这个宏，则编译包含在#ifdef和#endif之间的代码。
    ccptr pCClog = *(spCCC.begin());   //选择当前地图的第一个中央控制器（假设它存在），用于后续的日志记录。
    pCClog->mpLogger->SetMerge(__LINE__,0);  
    //调用日志记录函数SetMerge，记录当前代码的行号和一个额外的参数0。这可能用于跟踪合并操作的位置或状态。
    #endif

//比较 spCCC（当前地图的中央控制器集合）的大小和 pMapCurr->msuAssClients（当前地图的关联客户端集合）的大小。
//如果数量不匹配，则表示数据有问题，需要处理。
//在地图合并之前确保数据的一致性和完整性。
//通过验证关联客户端和中央控制器的数量匹配，可以防止在合并过程中由于数据不一致导致的潜在问题。
    if(spCCC.size() != pMapCurr->msuAssClients.size())
    {
        //使用ANSI转义码(\033[1;31m和\033[0m)来格式化错误消息，使其在终端中显示为红色，提高错误消息的可见性和紧急程度。
        //提示在 MapMerger::MergeMaps() 函数中发现数量不匹配的错误。
        cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": spCCC.size() != pMapCurr->msuAssClients.size()" << endl;
        //输出当前地图的ID。
        cout << "Map id: " << pMapCurr->mMapId << endl;
        //输出关联的客户端ID。
        cout << "Associated client IDs:" << endl;

     //使用一个 for 循环遍历 pMapCurr->msuAssClients 集合，逐个输出每个客户端的ID。
        for(set<size_t>::const_iterator sit = pMapCurr->msuAssClients.begin();sit!=pMapCurr->msuAssClients.end();++sit)
            cout << *sit << endl;
        //输出关联的中央控制器ID。
        cout << "Associated pCCs:" << endl;
        //输出每个中央控制器的客户端ID。
        for(set<ccptr>::const_iterator sit = spCCC.begin();sit!=spCCC.end();++sit)
            cout << (*sit)->mClientId << endl;
        //如果检测到数量不匹配，抛出一个自定义的基础设施异常 estd::infrastructure_ex
        throw estd::infrastructure_ex();
    }


// 针对匹配地图 (pMapMatch) 的检查。它确保匹配地图的关联客户端数量与其中央控制器集合的数量相匹配。
// 如果不匹配，则输出详细的错误信息并抛出异常。
    if(spCCM.size() != pMapMatch->msuAssClients.size())
    {
        cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": spCCM.size() != pMapMatch->msuAssClients.size()" << endl;
        cout << "Map id: " << pMapMatch->mMapId << endl;
        cout << "Associated client IDs:" << endl;
        for(set<size_t>::const_iterator sit = pMapMatch->msuAssClients.begin();sit!=pMapMatch->msuAssClients.end();++sit)
            cout << *sit << endl;
        cout << "Associated pCCs:" << endl;
        for(set<ccptr>::const_iterator sit = spCCM.begin();sit!=spCCM.end();++sit)
            cout << (*sit)->mClientId << endl;
        throw estd::infrastructure_ex();
    }


//遍历当前地图的中央控制器集合 spCCC，对每个中央控制器进行检查和处理。
//它主要确保每个中央控制器的客户端ID在预期范围内，并进行相关的锁定操作以准备地图合并。
//遍历中央控制器集合：spCCC
//et<ccptr>: 声明 spCCC 是一个集合（std::set），其中的元素是 ccptr 类型的指针。
//ccptr 可能是 std::shared_ptr 或其他智能指针类型，指向客户端控制器对象。
    for(set<ccptr>::iterator sit = spCCC.begin();sit!=spCCC.end();++sit)
    {
        ccptr pCC = *sit;

        //输出当前遍历到的中央控制器的客户端ID。
        //指的是与该机器人关联的客户端ID，不包括自己本身的ID。
        cout << "spCCC: pCC->mClientId: " << pCC->mClientId << endl;

        //检查客户端ID是否大于3，如果越界则输出错误信息。
        if(pCC->mClientId > 3) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId out of bounds (" << pCC->mClientId << ")" << endl;
        //检查客户端ID是否在关联客户端集合 msuAssClients 中，如果不在则输出错误信息。
        if(!(pMapCurr->msuAssClients.count(pCC->mClientId))) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId in pCC but not in msuAssClients" << endl;
       
       //根据客户端ID进行不同的处理。
        switch(pCC->mClientId)
        {
            //检查是否已经处理过该客户端ID，如果已经处理过则输出错误信息。
            case(static_cast<size_t>(0)):
                if(b0) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId found twice" << endl;
                //设置对应的布尔变量（如 b0，b1 等）为 true，表示该客户端ID已经处理过。
                b0 = true;
                //尝试锁定通信，直到成功为止。
                while(!pCC->LockComm()){usleep(params::timings::miLockSleep);}
                #ifdef LOGGING
//                pCC->mpLogger->SetMappingLock(__LINE__,pCC->mClientId);
                #endif
                //尝试锁定映射，直到成功为止。
                while(!pCC->LockMapping()){usleep(params::timings::miLockSleep);}
                //尝试锁定位置识别，直到成功为止。
                while(!pCC->LockPlaceRec()){usleep(params::timings::miLockSleep);}
                break;

            case(static_cast<size_t>(1)):
                if(b1) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId found twice" << endl;
                b1 = true;
                while(!pCC->LockComm()){usleep(params::timings::miLockSleep);}
                #ifdef LOGGING
//                pCC->mpLogger->SetMappingLock(__LINE__,pCC->mClientId);
                #endif
                while(!pCC->LockMapping()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockPlaceRec()){usleep(params::timings::miLockSleep);}
                break;

            case(static_cast<size_t>(2)):
                if(b2) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId found twice" << endl;
                b2 = true;
                while(!pCC->LockComm()){usleep(params::timings::miLockSleep);}
                #ifdef LOGGING
//                pCC->mpLogger->SetMappingLock(__LINE__,pCC->mClientId);
                #endif
                while(!pCC->LockMapping()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockPlaceRec()){usleep(params::timings::miLockSleep);}
                break;

            case(static_cast<size_t>(3)):
                if(b3) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId found twice" << endl;
                b3 = true;
                while(!pCC->LockComm()){usleep(params::timings::miLockSleep);}
                #ifdef LOGGING
//                pCC->mpLogger->SetMappingLock(__LINE__,pCC->mClientId);
                #endif
                while(!pCC->LockMapping()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockPlaceRec()){usleep(params::timings::miLockSleep);}
                break;

            //处理客户端ID超出预期范围的情况，输出错误信息。
            default: cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId out of bounds" << endl;
        }
    }

   //控制代码中的调试或日志记录功能，使其在开发或调试期间启用，而在生产环境中禁用
    #ifdef LOGGING
    pCClog->mpLogger->SetMerge(__LINE__,0);  
    //调用了 pCClog 对象的 mpLogger 成员的 SetMerge 方法。pCClog 是指向当前地图中央控制器（Central Controller）的智能指针，mpLogger 是其成员，负责日志记录。
    //SetMerge 方法的第一个参数是 __LINE__，这是一个预定义宏，代表当前源代码中的行号。使用 __LINE__ 可以记录代码执行到的具体位置，有助于调试和跟踪程序运行。
    //第二个参数是 0，这个参数的具体含义取决于 SetMerge 方法的实现。它可能表示特定的状态或标志。
    #endif

   
 //遍历当前地图的中央控制器集合 spCCM，对每个中央控制器进行检查和处理。
//它主要确保每个中央控制器的客户端ID在预期范围内，并进行相关的锁定操作以准备地图合并。
    for(set<ccptr>::iterator sit = spCCM.begin();sit!=spCCM.end();++sit)
    {
        ccptr pCC = *sit;

        cout << "spCCM: pCC->mClientId: " << pCC->mClientId << endl;

        if(pCC->mClientId > 3) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId out of bounds (" << pCC->mClientId << ")" << endl;
        if(!(pMapMatch->msuAssClients.count(pCC->mClientId))) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId in pCC but not in msuAssClients" << endl;
        switch(pCC->mClientId)
        {
            case(static_cast<size_t>(0)):
                if(b0) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId found twice" << endl;
                b0 = true;
                while(!pCC->LockComm()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockMapping()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockPlaceRec()){usleep(params::timings::miLockSleep);}
                break;
            case(static_cast<size_t>(1)):
                if(b1) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId found twice" << endl;
                b1 = true;
                while(!pCC->LockComm()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockMapping()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockPlaceRec()){usleep(params::timings::miLockSleep);}
                break;
            case(static_cast<size_t>(2)):
                if(b2) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId found twice" << endl;
                b2 = true;
                while(!pCC->LockComm()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockMapping()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockPlaceRec()){usleep(params::timings::miLockSleep);}
                break;
            case(static_cast<size_t>(3)):
                if(b3) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId found twice" << endl;
                b3 = true;
                while(!pCC->LockComm()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockMapping()){usleep(params::timings::miLockSleep);}
                while(!pCC->LockPlaceRec()){usleep(params::timings::miLockSleep);}
                break;
            default: cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps()\": associated ClientId out of bounds" << endl;
        }
    }

    #ifdef LOGGING
    pCClog->mpLogger->SetMerge(__LINE__,0);
    #endif

//在合并操作前锁定当前地图和匹配地图的更新操作，并标记相关的中央控制器（CCs）为活跃状态。
//它还包括对地图指针的空值检查，以确保后续操作的安全。

    //尝试锁定当前地图 (pMapCurr) 和匹配地图 (pMapMatch) 的更新操作。
    //LockMapUpdate() 方法用于获取地图更新的互斥锁，确保在锁定期间，其他线程无法修改地图数据。
    //usleep(params::timings::miLockSleep); 用于暂停一段时间（由 miLockSleep 指定），防止频繁尝试锁定导致CPU资源浪费。
    //这个函数以微秒为单位暂停线程。
    while(!pMapCurr->LockMapUpdate()){usleep(params::timings::miLockSleep);}
    while(!pMapMatch->LockMapUpdate()){usleep(params::timings::miLockSleep);}

   //标记当前地图的中央控制器：第一个 for 循环遍历当前地图的中央控制器集合 spCCC，
    //将每个中央控制器的 mbOptActive 标志设置为 true，表示这些控制器正在进行优化或重要操作。
    for(set<ccptr>::iterator sit = spCCC.begin();sit!=spCCC.end();++sit)
    {
        (*sit)->mbOptActive = true;
    }
        //标记匹配地图的中央控制器：第二个 for 循环遍历匹配地图的中央控制器集合 spCCM，将每个中央控制器的 mbOptActive 标志设置为 true。
    for(set<ccptr>::iterator sit = spCCM.begin();sit!=spCCM.end();++sit)
    {
        (*sit)->mbOptActive = true;
    }

     //检查地图指针是否为空：检查 pMapCurr 和 pMapMatch 是否为 nullptr，即确保两个地图对象都已经正确初始化。
    if(pMapCurr == nullptr || pMapMatch == nullptr)
    {
        //如果任一地图指针为空，输出错误信息，提示在 MapMerger::MergeMaps 函数中至少有一个地图为空。
        cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps\": at least one map is nullptr" << endl;
        //调用 SetIdle() 方法，可能用于重置忙碌状态标志。
        this->SetIdle();
        //返回 nullptr，终止当前合并操作。
        return nullptr;
    }

 
 //创建新地图并初始化相关数据结构和变量
 //使用 new Map(pMapMatch, pMapCurr) 创建一个新的 Map 对象，表示将当前地图 pMapCurr 和匹配地图 pMapMatch 融合到一个新地图中。
//mapptr 是一个智能指针类型，负责管理 Map 对象的生命周期，确保在不再需要时自动释放内存。
    mapptr pFusedMap{new Map(pMapMatch,pMapCurr)}; 

//锁定新地图的更新操作：通过循环调用 LockMapUpdate() 方法，尝试获取新地图的更新锁，确保在锁定期间，其他线程无法修改新地图的数据。
//使用 usleep(params::timings::miLockSleep); 暂停一段时间，防止频繁尝试锁定导致的资源浪费。
    while(!pFusedMap->LockMapUpdate()){usleep(params::timings::miLockSleep);}
//更新关联数据：调用 UpdateAssociatedData() 方法，更新新地图的相关数据结构。这可能包括关联的关键帧、地图点、连接信息等。
    pFusedMap->UpdateAssociatedData();

  // !!!!!!! 修改程序,  打印关键帧ID  !!!!!!!
  for (int i = 0; i < vMatchHits.size(); ++i) 
  {
    size_t IdC = vMatchHits[i].mpKFCurr->mId.second;
     std::cout << "First Keyframe ID:" << std::endl;
    std::cout << IdC << std::endl;

    size_t IdM = vMatchHits[i].mpKFMatch->mId.second;
     std::cout << "Second Keyframe ID:" << std::endl;
    std::cout << IdM << std::endl;
  }
    // !!!!!!! 修改程序,  打印缩放因子  !!!!!!!
        for (size_t i = 0; i < vMatchHits.size(); ++i)
    {
        // 获取当前元素的Sim3变换
        g2o::Sim3& Taibj = vMatchHits[i].mg2oScw;
        double Taibj_scale = Taibj.scale();
        std::cout << "ALL  Scale:" << std::endl;
        std::cout << Taibj_scale << std::endl;
    }
      // #####################修改处！！！，显示关键帧数量//
     std::cout << "THE NUMBER OF  KEYFRAME:" << std::endl;
     std::cout << vMatchHits.size() << std::endl;
      // #####################修改处！！！，显示关键帧数量//


//从匹配结果 vMatchHits 中提取当前关键帧和匹配关键帧的客户端ID。这些ID将在后续操作中使用。
    size_t IdC = vMatchHits[0].mpKFCurr->mId.second;
    size_t IdM = vMatchHits[0].mpKFMatch->mId.second;
//世界坐标系中匹配地图和当前地图之间的相对变换，Taibj*Tbj= Tba *Tai 
    g2o::Sim3 g2oS_wm_wc; //world match - world curr

 //初始化循环闭合关键帧对,  idpair 可能是一个表示关键帧对的类型，nLoopKf 将用于存储在优化过程中发现的循环闭合关键帧对。
    idpair nLoopKf;

     //提取匹配结果中的关键帧和地图点, 只提取了第一个
     //从匹配结果 vMatchHits 中提取当前关键帧 pKFCur 和匹配关键帧 pKFMatch。
    //提取匹配结果中的相似变换 g2oScw，表示从当前关键帧到匹配关键帧的变换。
    //vMatchHits 结构体在mapmatcher.h文件中
    int idx = 0;
    kfptr pKFCur = vMatchHits[idx].mpKFCurr;
    kfptr pKFMatch = vMatchHits[idx].mpKFMatch;
    //注意这里的g2oScw不仅仅是闭环的相对运动估计Taibj,  而是Taibj *Tbj
    g2o::Sim3 g2oScw = vMatchHits[idx].mg2oScw;   // 通过之前闭环计算出的两帧间相对运行关系
   

    //提取匹配的地图点：
    //vpCurrentMatchedPoints 和 vpLoopMapvMatchHits.size()Points 分别表示在当前关键帧和匹配关键帧中匹配到的地图点。
    std::vector<mpptr> vpCurrentMatchedPoints = vMatchHits[idx].mvpCurrentMatchedPoints;
    std::vector<mpptr> vpLoopMapPoints = vMatchHits[idx].mvpLoopMapPoints;

    //获取当前地图的所有关键帧, 调用 GetAllKeyFrames() 方法
    vector<kfptr> vpKeyFramesCurr = pMapCurr->GetAllKeyFrames();

 //检查匹配结果的客户端ID是否一致：通过比较从匹配结果提取的客户端ID (IdC 和 IdM) 和当前关键帧 (pKFCur) 以及匹配关键帧 (pKFMatch) 的客户端ID (mId.second)，验证匹配信息的正确性。
//如果不一致，输出错误信息，提示在 MapMerger::MergeMaps 函数中出现了客户端ID不匹配的错误。
    if(IdC != pKFCur->mId.second || IdM != pKFMatch->mId.second)
        cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps\": client ID mismatch" << endl;

//更新当前关键帧的连接关系：调用 UpdateConnections() 方法，更新当前关键帧 pKFCur 的连接关系。
//这通常包括更新与其他关键帧和地图点的连接信息，确保其反映最新的图结构。
    // Ensure current keyframe is updated
    pKFCur->UpdateConnections();

//获取与当前关键帧相连的关键帧：调用 GetVectorCovisibleKeyFrames() 方法，获取与当前关键帧 pKFCur 具有共视关系的关键帧集合。
//这些关键帧是通过共享相同地图点而直接或间接连接在一起的。
//将当前关键帧 pKFCur 自己也添加到 mvpCurrentConnectedKFs 集合中。这是因为当前关键帧本身也是需要进行校正的一部分。
    // Retrive keyframes connected to the current keyframe and compute corrected Sim3 pose by propagation
    mvpCurrentConnectedKFs = pKFCur->GetVectorCovisibleKeyFrames();
    mvpCurrentConnectedKFs.push_back(pKFCur);

//初始化循环闭合关键帧对：将当前关键帧 pKFCur 的ID赋值给 nLoopKf。
//这可能用于标识在优化过程中涉及到的关键帧对，以便进行相应的处理和校正。
    nLoopKf = pKFCur->mId;

//用于存储关键帧及其对应姿态（pose）信息的数据结构，
//这里定义了两个变量 CorrectedSim3 和 NonCorrectedSim3，分别用于存储经过校正的和未经校正的关键帧与其相应的姿态信息。
//KeyFrameAndPose 是一个自定义的数据结构，用于存储关键帧及其相关的位姿信息。CorrectedSim3 和 NonCorrectedSim3 是这种数据结构的实例，分别用于存储校正后和未校正的Sim3变换。
 //KeyFrameAndPose 类型（一个特别定制的 std::map），为其赋值涉及插入键值对到映射中。键是关键帧的指针 kfptr，值是与之关联的 g2o::Sim3 对象
//类似于重新定义了一个变量，包含关键帧对象与其对应的位姿
    KeyFrameAndPose CorrectedSim3, NonCorrectedSim3;

//将变量 g2oScw（一个表示姿态的Sim3变换，包括旋转、平移和缩放）赋值给当前处理的关键帧 pKFCur 在 CorrectedSim3 映射中的条目。
//这表示 pKFCur 关键帧的校正姿态已被更新为 g2oScw。
//重新定义了一个变量，包含关键帧对象与其对应的位姿，注意这里pKFCur对应的位姿不是之前的机器人位姿，而是相对闭环转化！！！
    CorrectedSim3[pKFCur]=g2oScw;
         
   // #####################修改处！！！，显示转化的相对坐标系//  
      /******************使用鲁棒优化算法求解********************/
    g2oS_wm_wc =  OptimizeTransforms(vMatchHits);

        //判断客户端ID与关键帧输入的第一帧ID是否一致，如果不一致则进行逆运算；
        //如果客户端的PCC是alpha, Tab* (Taibj *Tbj )= Tai , 第一帧是alpha, 计算的结果是beta到alpha . 如果对其取逆，即PCC属于PCF时运行；
        //如果客户端的PCC是beta,  第一帧是alpha, 计算的结果是beta到alpha , 那么PCC属于PCF时运行；
        
            for(set<ccptr>::iterator sit = spCCC.begin();sit!=spCCC.end();++sit)
         {
           ccptr pCC = *sit;
           size_t IdCli= pCC->mClientId; 
            if ( IdCli ==IdC)
             {
                      g2oS_wm_wc = g2oS_wm_wc;
              }else
              {
                     g2oS_wm_wc = g2oS_wm_wc.inverse();
              }
         }
        
        Eigen::Matrix3d rotation = g2oS_wm_wc.rotation().toRotationMatrix();
        Eigen::Vector3d translation = g2oS_wm_wc.translation();
        double scale = g2oS_wm_wc.scale();
         
        // 打印旋转矩阵
        std::cout << "Optimization TO  GLOBAL Rotation Matrix:" << std::endl;
        std::cout << rotation << std::endl;
        // 打印平移向量
        std::cout << "Optimization TO  GLOBAL Translation Vector:" << std::endl;
        std::cout << translation.transpose() << std::endl;
        // 打印缩放因子
        std::cout << "Optimization TO  GLOBAL Scale:" << std::endl;
        std::cout << scale << std::endl;
        //#####################//
     

    cv::Mat Twc = pKFCur->GetPoseInverse();  //表示从世界坐标系到相机坐标系的变换,  是一个4x4的变换矩阵
    /****************原始求解方案**********************/
   /**************************************/
    /*
    {
        cv::Mat Rwc = Twc.rowRange(0,3).colRange(0,3);   //从 Twc 中提取了旋转矩阵部分
        cv::Mat twc = Twc.rowRange(0,3).col(3);   //提取了 Twc 中的平移向量
        //  g2o 库中的一个对象，用于表示三维的相似变换，包括旋转、平移和尺度变换。在这里，尺度被设置为1.0，表示没有缩放。
        //Converter::toMatrix3d(Rwc) 和 Converter::toVector3d(twc) 是类型转换函数，分别将 OpenCV 的 Mat 类型转换为 g2o 需要的矩阵和向量类型。
        g2o::Sim3 g2oSwc(Converter::toMatrix3d(Rwc),Converter::toVector3d(twc),1.0);
        //计算了两个 Sim3 对象之间的变换。g2oScw.inverse() 表示取 g2oScw 的逆变换，其中 g2oScw 可能之前定义为从相机坐标系到世界坐标系的变换。
        //g2oSwc.inverse() 是从相机坐标系到世界坐标系的逆变换。这行代码最终计算的是从 g2oScw 到 g2oSwc 的相对变换。
        //    Tab= inv(Taibj *Tbj) * Tai,     Tab* (Taibj *Tbj )= Tai ,  beta坐标系到alpha坐标系的转化
        g2oS_wm_wc = (g2oScw.inverse())*(g2oSwc.inverse());  //.inverse()
    }
    */


    // KeyFrameAndPose 类型的变量 CorrectedSim3All 和 NonCorrectedSim3All 的初始化，
    //这两个变量分别用于存储校正后的姿态 (CorrectedSim3All) 和未校正的姿态 (NonCorrectedSim3All)
    //以及将当前关键帧 pKFCur 的校正姿态 g2oScw 添加到 CorrectedSim3All 中
    KeyFrameAndPose CorrectedSim3All, NonCorrectedSim3All;
    CorrectedSim3All[pKFCur]=g2oScw;   //将 pKFCur 作为键，将 g2oScw 作为值，添加到 CorrectedSim3All 映射中

// 遍历共视关键帧,  计算并存储它们的校正和非校正姿态。
//遍历当前关键帧 pKFCur 的所有共视关键帧 mvpCurrentConnectedKFs。
    for(vector<kfptr>::iterator vit=mvpCurrentConnectedKFs.begin(), vend=mvpCurrentConnectedKFs.end(); vit!=vend; vit++)
    {
        // 获取姿态矩阵：对于每个关键帧 pKFi，获取其姿态矩阵 Tiw。
        kfptr pKFi = *vit;
        cv::Mat Tiw = pKFi->GetPose();

    //跳过当前关键帧：如果 pKFi 是当前关键帧 pKFCur，则跳过校正计算。
        if(pKFi!=pKFCur)
        {
            //计算相对变换：计算 Tic，表示从当前关键帧到共视关键帧的变换。
            cv::Mat Tic = Tiw*Twc;
            cv::Mat Ric = Tic.rowRange(0,3).colRange(0,3);
            cv::Mat tic = Tic.rowRange(0,3).col(3);
            //创建相似变换 g2o::Sim3 对象：将 Ric 和 tic 转换为 Eigen::Matrix3d 和 Eigen::Vector3d 后，创建 g2o::Sim3 对象 g2oSic。
            g2o::Sim3 g2oSic(Converter::toMatrix3d(Ric),Converter::toVector3d(tic),1.0);
            //计算校正后的姿态：通过相乘得到校正后的姿态 g2oCorrectedSiw，并将其存储在 CorrectedSim3 映射中。
            g2o::Sim3 g2oCorrectedSiw = g2oSic*g2oScw;
            //Pose corrected with the Sim3 of the loop closure
            CorrectedSim3[pKFi]=g2oCorrectedSiw;
        }
      // 计算并存储未校正姿态
        cv::Mat Riw = Tiw.rowRange(0,3).colRange(0,3);
        cv::Mat tiw = Tiw.rowRange(0,3).col(3);
        g2o::Sim3 g2oSiw(Converter::toMatrix3d(Riw),Converter::toVector3d(tiw),1.0);
        //Pose without correction
        NonCorrectedSim3[pKFi]=g2oSiw;
    }

//遍历所有当前地图中的关键帧，对每一个关键帧检查和更新其校正后和未校正的姿态
//遍历所有关键帧，并将它们的校正姿态和未校正姿态分别存储在 CorrectedSim3All 和 NonCorrectedSim3All 中。
//如果关键帧已经存在于 CorrectedSim3 映射中，则直接使用该值；否则，计算新的校正和未校正姿态。
    for(vector<kfptr>::iterator vit = vpKeyFramesCurr.begin();vit!=vpKeyFramesCurr.end();++vit)
    {
        // 获取当前迭代器指向的关键帧
        kfptr pKFi = *vit;
          // 在已校正的姿态映射中查找当前关键帧
        KeyFrameAndPose::const_iterator it = CorrectedSim3.find(pKFi);

        // 如果当前关键帧已有校正后的姿态
        if(it!=CorrectedSim3.end())
        {            
            // 将校正后的姿态保存到全局映射中
            CorrectedSim3All[pKFi] = it->second;

            // 在未校正的姿态映射中查找当前关键帧
            KeyFrameAndPose::const_iterator it2 = NonCorrectedSim3.find(pKFi);
            //// 如果在未校正的姿态映射中找不到当前关键帧，输出错误信息
            if(it2==NonCorrectedSim3.end()) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMerger::MergeMaps\": Siw for KF in CorrectedSim3 but not in NonCorrectedSim3" << endl;
             // 将未校正的姿态保存到全局映射中
            NonCorrectedSim3All[pKFi] = NonCorrectedSim3[pKFi];
        }
        else
        {
            cv::Mat Tiw = pKFi->GetPose();   // 获取当前关键帧的姿态矩阵

            //CorrectedSim3All
            cv::Mat Tic = Tiw*Twc;       // 计算从世界坐标到关键帧坐标的变换矩阵
            cv::Mat Ric = Tic.rowRange(0,3).colRange(0,3);
            cv::Mat tic = Tic.rowRange(0,3).col(3);
            g2o::Sim3 g2oSic(Converter::toMatrix3d(Ric),Converter::toVector3d(tic),1.0);    // 创建表示从世界坐标到关键帧坐标的相似变换对象
            g2o::Sim3 g2oCorrectedSiw = g2oSic*g2oScw;     // 通过将相似变换和全局相似变换相乘，计算校正后的姿态
            //Pose corrected with the Sim3 of the loop closure
            CorrectedSim3All[pKFi]=g2oCorrectedSiw;      // 将校正后的姿态保存到全局映射中

            //NonCorrectedSim3All
            cv::Mat Riw = Tiw.rowRange(0,3).colRange(0,3);
            cv::Mat tiw = Tiw.rowRange(0,3).col(3);
            g2o::Sim3 g2oSiw(Converter::toMatrix3d(Riw),Converter::toVector3d(tiw),1.0);
            //Pose without correction
            NonCorrectedSim3All[pKFi]=g2oSiw;
        }
    }


// 涉及了对SLAM系统中地图点（MapPoints）和关键帧（KeyFrames）的校正过程，尤其是在环路闭合检测之后进行的全局优化过程中
//  使用已校正的姿态更新地图点的世界坐标位置，确保数据一致性。
//  将校正后的Sim3变换（包括旋转和平移）转换成SE3变换，并更新关键帧的姿态。
//  更新关键帧的连接和地图点的信息，确保SLAM系统的地图反映最新的环境状态。
    // Correct MapPoints and KeyFrames of current map
    // 遍历所有已校正的关键帧
    for(KeyFrameAndPose::iterator mit=CorrectedSim3All.begin(), mend=CorrectedSim3All.end(); mit!=mend; mit++)
    {
        // 获取关键帧指针和对应的校正后的Sim3变换, 以及逆变换
        kfptr pKFi = mit->first;
        g2o::Sim3 g2oCorrectedSiw = mit->second;
        g2o::Sim3 g2oCorrectedSwi = g2oCorrectedSiw.inverse();

       // 获取未校正的Sim3变换
        g2o::Sim3 g2oSiw =NonCorrectedSim3All[pKFi];

       // 获取关键帧对应的所有地图点
        vector<mpptr> vpMPsi = pKFi->GetMapPointMatches();
         // 遍历所有地图点
        for(size_t iMP=0, endMPi = vpMPsi.size(); iMP<endMPi; iMP++)
        {
            mpptr pMPi = vpMPsi[iMP];
            // 检查地图点是否有效
            if(!pMPi)
                continue;
            if(pMPi->isBad())
                continue;
            if(pMPi->mCorrectedByKF_MM==pKFCur->mId)
                continue;

            // Project with non-corrected pose and project back with corrected pose
             // 获取地图点的世界坐标位置
            cv::Mat P3Dw = pMPi->GetWorldPos();
             // 将世界坐标转换为Eigen向量
            Eigen::Matrix<double,3,1> eigP3Dw = Converter::toVector3d(P3Dw);
            // 使用未校正的姿态投影并用校正后的姿态重新投影回去
            Eigen::Matrix<double,3,1> eigCorrectedP3Dw = g2oCorrectedSwi.map(g2oSiw.map(eigP3Dw));

           // 将重新投影后的坐标转换为OpenCV的Mat格式
            cv::Mat cvCorrectedP3Dw = Converter::toCvMat(eigCorrectedP3Dw);
            // 更新地图点的世界坐标
            pMPi->SetWorldPos(cvCorrectedP3Dw,true);
             // 记录地图点被校正的关键帧ID和唯一ID
            pMPi->mCorrectedByKF_MM = pKFCur->mId;
            pMPi->mCorrectedReference_MM = pKFCur->mUniqueId;
            // 更新地图点的法线和深度信息
            pMPi->UpdateNormalAndDepth();
        }

         // 将校正后的Sim3变换转换为SE3变换（忽略尺度因子）
        Eigen::Matrix3d eigR = g2oCorrectedSiw.rotation().toRotationMatrix();
        Eigen::Vector3d eigt = g2oCorrectedSiw.translation();
        double s = g2oCorrectedSiw.scale();       // 获取缩放因子

        eigt *=(1./s); //[R t/s;0 1]       // 缩放平移分量

        // 将SE3变换转换为OpenCV的Mat格式
        cv::Mat correctedTiw = Converter::toCvSE3(eigR,eigt);
        // 更新关键帧的姿态
        pKFi->SetPose(correctedTiw,true);
         // 确保关键帧的连接关系更新
        // Make sure connections are updated
        pKFi->UpdateConnections();
        // 记录关键帧被校正
        pKFi->mCorrected_MM = pKFCur->mId;
    }

    //从当前地图（pMapCurr）获取被删除（擦除）的关键帧（KeyFrames）和地图点（MapPoints）的集合
    //map<idpair, kfptr>：这是一个映射，其中的键（idpair）通常是由两个整数组成的配对，
    //代表关键帧的唯一标识符。值（kfptr）是指向关键帧对象的智能指针。
      //GetMmpErasedKeyFrames()：这是一个成员函数，返回当前地图中所有已被擦除但仍保留引用的关键帧。
    //这些关键帧可能已经从主视图中删除，但由于某些原因（如延迟处理或需要稍后再访问）仍被保留。
    //获取被擦除的关键帧
    map<idpair,kfptr>  mpErasedKFs = pMapCurr->GetMmpErasedKeyFrames();
     //获取被擦除的地图点
    map<idpair,mpptr>  mpErasedMPs = pMapCurr->GetMmpErasedMapPoints();
     //在SLAM系统中，经常需要管理和更新大量的动态数据。在某些情况下，关键帧或地图点可能因为视野变化、优化过程中的冗余性判断等）
     //被认为不再需要，因此被标记为删除。然而，这些数据项可能还需要被暂时保留以完成某些后续处理步骤，如环路闭合检测、地图合并等。

//处理已被擦除的关键帧，这些关键帧可能因为不再可见或其他原因而被标记为删除，
//但由于它们可能仍然与地图的其他部分有联系（例如通过共视关系），所以仍然保留在内存中。
// 遍历所有被擦除但仍保留的关键帧
    for(map<idpair,kfptr>::iterator mitEr = mpErasedKFs.begin();mitEr != mpErasedKFs.end();++mitEr)
    {
        // 获取当前迭代到的关键帧指针
        kfptr pKFi = mitEr->second;
        // 检查关键帧指针是否有效
        if(!pKFi)
        {
            // 如果关键帧指针无效，则输出警告信息并跳过当前循环迭代
            cout << "\033[1;33m!!! WARN !!!\033[0m " << __func__ << ":" << __LINE__ << ": KF is nullptr" << endl;
            continue;
        }
         // 检查关键帧是否标记为"bad"（即已从主数据结构中删除）
        if(!pKFi->isBad())
        // 如果关键帧没有被标记为"bad"但已被擦除，输出警告信息
            cout << "\033[1;33m!!! WARN !!!\033[0m " << __func__ << ":" << __LINE__ << ": KF is erased, but !bad" << endl;

        // 检查当前关键帧是否已经被校正
        if(pKFi->mCorrected_MM == pKFCur->mId)
        {
            // 如果已经校正，输出警告信息并跳过当前迭代
            cout << "\033[1;33m!!! WARN !!!\033[0m " << __func__ << ":" << __LINE__ << ": KF already corrected" << endl;
            continue;
        }
        // 获取当前关键帧的父关键帧
        kfptr pP = pKFi->GetParent();
        // 获取从当前关键帧到其父关键帧的变换矩阵
        cv::Mat Tcp = pKFi->mTcp;
        // 检查父关键帧是否被标记为"bad"，如果是，则继续向上查找直到找到有效的父关键帧
        while(pP->isBad())
        {
            Tcp = pP->mTcp;
            pP = pP->GetParent();
        }
        // 标记当前关键帧已被校正
        pKFi->mCorrected_MM = pKFCur->mId;
    }



//处理了一个类似于先前关键帧处理的循环，但这次针对的是已经被擦除的地图点（MapPoints）。
//代码详细检查每个地图点的状态，并在必要时输出警告信息。
// 遍历所有已被擦除的地图点
    for(map<idpair,mpptr>::iterator mitEr = mpErasedMPs.begin();mitEr != mpErasedMPs.end();++mitEr)
    {
        //获取当前迭代到的地图点指针
        mpptr pMPi = mitEr->second;
        // 检查地图点指针是否有效
        if(!pMPi)
        {
            // 如果地图点指针无效，则输出警告信息并跳过当前循环迭代
            cout << "\033[1;33m!!! WARN !!!\033[0m " << __func__ << ":" << __LINE__ << ": MP is nullptr" << endl;
            continue;
        }
          // 检查地图点是否标记为"bad"（即已从主数据结构中删除）
        if(!pMPi->isBad())
            // 如果地图点没有被标记为"bad"但已被擦除，输出警告信息
            cout << "\033[1;33m!!! WARN !!!\033[0m " << __func__ << ":" << __LINE__ << ": MP is erased, but !bad" << endl;
       // 检查当前地图点是否已经被校正
        if(pMPi->mCorrectedByKF_MM == pKFCur->mId)
        {
            // 如果已经校正，输出警告信息并跳过当前迭代
            cout << "\033[1;33m!!! WARN !!!\033[0m " << __func__ << ":" << __LINE__ << ": MP already corrected" << endl;
            continue;
        }
        // 不对已经被擦除的地图点进行校正
        //do not correct erase MPs
    }


// 更新匹配的地图点，并在有重复的情况下进行替换
//环路检测与融合：在SLAM系统中，环路检测是识别机器人已经回到之前访问过的位置的过程。环路融合是根据这些信息调整地图点，确保地图的准确性。
//更新地图点：代码中检查了每个从环路检测过程中匹配的地图点。如果当前关键帧已经有一个地图点与之对应，则替换为新的地图点，并锁定以避免在后续处理中被修改。
//添加新的观察：如果当前关键帧在该位置没有地图点，则添加新的地图点，并将当前关键帧注册为该地图点的观察者。这样做可以增强地图点的稳定性和重建质量。
//计算描述符：为新添加或更新的地图点计算独特的描述符，这有助于提高特征匹配的准确性和后续视觉处理的效率。
    for(size_t i=0; i<vpCurrentMatchedPoints.size(); i++)
    {
        // 检查当前索引的地图点是否存在
        if(vpCurrentMatchedPoints[i])
        {
            // 获取当前关键帧中匹配的地图点
            mpptr pLoopMP = vpCurrentMatchedPoints[i];
            // 从当前关键帧获取对应索引的地图点
            mpptr pCurMP = pKFCur->GetMapPoint(i);

            // 如果当前关键帧的该位置已经有地图点
            if(pCurMP)
            {
                // 用环路中的地图点替换当前关键帧中的地图点，并锁定该点
                pCurMP->ReplaceAndLock(pLoopMP);
            }
            else
            {
                // 如果当前关键帧的该位置没有地图点，则添加环路中的地图点
                pKFCur->AddMapPoint(pLoopMP,i,true); //lock this MapPoint
                // 将当前关键帧添加为环路中地图点的观察者，并锁定
                pLoopMP->AddObservation(pKFCur,i,true);
                // 重新计算环路中地图点的独特描述符
                pLoopMP->ComputeDistinctiveDescriptors();
            }
        }
    }


    // Project MapPoints observed in the neighborhood of the loop keyframe
    // into the current keyframe and neighbors using corrected poses.
    // Fuse duplications.
    // 使用校正后的姿态，将环路关键帧周边观测到的地图点投影到当前关键帧及其邻居
//SearchAndFuse 函数：这个函数的作用是将给定的地图点（这里是环路关键帧周边的地图点vpLoopMapPoints）
//根据校正后的姿态（CorrectedSim3包含所有已校正的关键帧及其对应的校正姿态）投影到当前关键帧及其邻居。
//重投影与融合：根据校正后的姿态将地图点重新投影到当前关键帧和其邻居关键帧中。如果这些地图点已存在于当前关键帧或其邻居中，它们将被融合以消除重复，增强地图的一致性和精确性。
    SearchAndFuse(CorrectedSim3,vpLoopMapPoints);

    // After the MapPoint fusion, new links in the covisibility graph will appear attaching both sides of the loop
    //// 在地图点融合后，共视图中会出现新的链接，连接环路的两侧
    //共视图更新：LoopConnections用于存储环路闭合过程中识别出的新共视关系。共视关系是指两个或多个关键帧观测到许多相同的地图点，这种关系对于理解关键帧之间的空间关系非常重要。
    //增强共视图：在环路闭合时，通过识别并添加新的共视关系，可以显著增强共视图的连通性，这对于全局优化和提高地图精度非常关键。
    map<kfptr, set<kfptr> > LoopConnections;


//更新每个关键帧的连接状态，同时确定由于环路闭合新建立的共视关系。
// 遍历当前连接到环路关键帧的所有关键帧
//更新共视关系：UpdateConnections 方法对每个关键帧调用，以确保它们的共视关系是最新的，特别是在环路闭合后，可能会发现新的或更强的共视关系。
//维护共视图：LoopConnections 映射用于记录更新后的共视关系。这是非常重要的，因为它帮助维护了关键帧间的拓扑结构，这对于后续的地图优化和特征匹配非常关键。
//消除旧的共视关系：通过在 LoopConnections 中删除以前的和当前循环中的共视关系，可以确保不会受到旧数据的干扰，特别是在进行全局优化时，精确的共视信息至关重要。

    for(vector<kfptr>::iterator vit=mvpCurrentConnectedKFs.begin(), vend=mvpCurrentConnectedKFs.end(); vit!=vend; vit++)
    {
        // 获取迭代器当前指向的关键帧
        kfptr pKFi = *vit;
        // 获取该关键帧的先前共视关键帧列表
        vector<kfptr> vpPreviousNeighbors = pKFi->GetVectorCovisibleKeyFrames();

        // Update connections. Detect new links.
        // 更新当前关键帧的连接，这一步会重新计算与该关键帧共视的关键帧
        pKFi->UpdateConnections();
        // 将更新后的共视关键帧列表保存到LoopConnections映射中
        LoopConnections[pKFi]=pKFi->GetConnectedKeyFrames();
         // 删除之前已经存在的共视关系，避免重复计算
        for(vector<kfptr>::iterator vit_prev=vpPreviousNeighbors.begin(), vend_prev=vpPreviousNeighbors.end(); vit_prev!=vend_prev; vit_prev++)
        {
            LoopConnections[pKFi].erase(*vit_prev);
        }
         // 进一步清除所有当前环路中关键帧间的直接连接，确保环路中的关键帧仅通过新发现的共视关系相连接
        for(vector<kfptr>::iterator vit2=mvpCurrentConnectedKFs.begin(), vend2=mvpCurrentConnectedKFs.end(); vit2!=vend2; vit2++)
        {
            LoopConnections[pKFi].erase(*vit2);
        }
    }


 // Optimize graph,  函数来自于optimizer.cpp文件中
//专注于优化关键帧之间的关系，而不是优化地图点的位置, 优化地图中关键帧的图结构
//pFusedMap：这是一个地图对象，通常是两个或多个地图的融合结果。在环路闭合后，可能需要将多个地图段融合为一个统一的地图表示。
//pKFMatch：这是一个关键帧，它与当前关键帧（pKFCur）在环路检测中被匹配为历史相遇点。这通常表示在之前的某个时刻，这两个关键帧观测到了很多相同的地图点。
//pKFCur：当前关键帧，它与pKFMatch在环路闭合检测中被识别为具有重叠视域的关键帧。
//LoopConnections：这是一个包含新建立的共视关系的映射。这些连接通常是在环路闭合过程中新发现的，需要被添加到图中以增强图的结构。
//false：这个参数可能代表一个选项，如是否使用某种特定的优化策略。在这里，假设它指定了是否进行某种形式的强制优化或检查。
    Optimizer::OptimizeEssentialGraphMapFusion(pFusedMap, pKFMatch, pKFCur, LoopConnections, false);



    // Add loop edge
    //为环路闭合中识别的关键帧对添加双向的连接
    pKFMatch->AddLoopEdge(pKFCur);
    pKFCur->AddLoopEdge(pKFMatch);

     //优化和全局束调整 (GBA)
     //通过在控制台输出状态信息，标记全局束调整的开始，并设置相关的状态标志。
     //pFusedMap的几个方法被调用以控制GBA的执行流程和确保它不被意外中断。
    cout << "Essential graph optimized" << endl;
    cout << ">>>>> MapMerger::MergeMaps --> Global Bundle Adjustment" << endl;

    pFusedMap->setRunningGBA();
    pFusedMap->setFinishedGBA();
    pFusedMap->mbStopGBA = false;

    #ifdef DONOTINTERRUPTMERGE
    pFusedMap->setMergeStepGBA();
    #endif

    #ifdef DEBUGGING2
    pFusedMap->CheckStructure();
    #endif

    // Launch a new thread to perform Global Bundle Adjustment
    //启动全局束调整线程,  这里创建了一个新的线程来执行全局束调整，这是一个计算密集型的过程，通常在后台运行，以优化整个地图的结构。
    cout << "--- Launch GBA thread" << endl;
    pFusedMap->mpThreadGBA = new thread(&MapMerger::RunGBA,this,nLoopKf,pFusedMap);

//    std::cout << "MapMerger: Wait for GBA to finish" << std::endl;
//    while(pFusedMap->isRunningGBA()) {
//        usleep(10000);
//    }
//    std::cout << "MapMerger: GBA finished - continue" << std::endl;

  //地图和控制中心更新, 在全局束调整后，此代码段更新了地图的状态，并确保了所有相关的控制中心（ccptr）被正确更新，
  // 包括切换它们当前的活动地图和清理可能的残留数据。这确保了地图和其控制中心在数据和逻辑上保持同步。
  
    cout << "\033[1;32;41m!!! MAPS MERGED !!!\033[0m" << endl;
    this->SetIdle();   //设置系统状态,  将系统状态设置为闲置，可能是为了准备地图合并后的清理和更新操作。

    //delete old maps and set new ones in threads
    //标记旧地图为过时,  将当前地图和匹配地图标记为过时，表示这些地图不再是最新的，应该停止使用。
    pMapCurr->SetOutdated();
    pMapMatch->SetOutdated();

    //更新中央控制指针集合和地图,  从合并后的地图 pFusedMap 中获取所有相关的中央控制指针（ccptr），
    //这些控制指针代表着与地图相关的不同组件或客户端。
    set<ccptr> spCCF = pFusedMap->GetCCPtrs();

    //遍历 spCCF 集合，更新每个中央控制的地图指向和状态：
   //如果中央控制指针在 spCCC（一个集合，可能代表当前激活的控制指针集合）中，使用 g2oS_wm_wc 更新对应的客户端处理器 pCH 的地图。
   //如果不在 spCCC 中，使用单位矩阵（代表无变换）更新地图，并清除覆盖图相关数据。
   //这行代码初始化了一个迭代器sit来遍历set容器spCCF，这个容器里面存储的元素类型是ccptr（看起来像是一个指针类型。
   //for循环会一直执行，直到迭代器sit遍历完spCCF容器中的所有元素。
    for(set<ccptr>::iterator sit = spCCF.begin();sit!=spCCF.end();++sit)
    {
        //在循环体中，首先通过解引用迭代器sit来获取当前元素，赋值给pCC。然后通过pCC指针访问其成员mpCH，并将其存储在pCH中。
        ccptr pCC = *sit;
        chptr pCH = pCC->mpCH;

        //这部分代码首先检查pCC是否存在于另一个容器spCCC中。如果存在，调用pCH的成员函数ChangeMap，传入pFusedMap和g2oS_wm_wc作为参数，
        //并设置pCC的成员mbGotMerged为true。如果pCC不在spCCC中，则同样调用ChangeMap函数，但是第二个参数是g2o::Sim3()的默认构造，然后调用pCH的ClearCovGraph方法清除当前地图的覆盖图。
        if(spCCC.count(pCC))
        {
            //函数在clienthandler.cpp文件中
            pCH->ChangeMap(pFusedMap, g2oS_wm_wc);
            pCC->mbGotMerged = true;
        }
        else
        {
             //函数在clienthandler.cpp文件中，g2o::Sim3()指的是单位矩阵。
            pCH->ChangeMap(pFusedMap,g2o::Sim3());
            pCH->ClearCovGraph(pMapCurr->mMapId);
        }
        //解锁操作,  解锁通信和地点识别锁，这可能是在合并操作开始时加锁的，现在合并完成后需要释放。
        pCC->UnLockComm();
        pCC->UnLockPlaceRec();
    }

   // 地图更新解锁,  解锁地图更新操作，确保地图的更新操作不再被阻塞，允许进一步的操作。
    pMapCurr->UnLockMapUpdate();
    pMapMatch->UnLockMapUpdate();
    pFusedMap->UnLockMapUpdate();

   //重置地图的状态，移除可能在全局捆绑调整（GBA）前设置的任何标志，这通常用于防止在某些操作期间启动GBA。
    pMapCurr->unsetNoStartGBA();
    pMapMatch->unsetNoStartGBA();
    pFusedMap->unsetNoStartGBA();

   //最后，如果启用了日志记录，则记录相关信息，并返回融合后的地图，标志着这一阶段处理的结束。
    #ifdef LOGGING
    pCClog->mpLogger->SetMerge(__LINE__,0);
    #endif

    return pFusedMap;
}


//在SLAM系统中进行地图点的搜索和融合操作，特别是在环路闭合后使用校正后的姿态信息。
//这个函数 SearchAndFuse 是 MapMerger 类的一部分，负责找出并合并重复的地图点
void MapMerger::SearchAndFuse(const KeyFrameAndPose &CorrectedPosesMap, std::vector<mpptr> vpLoopMapPoints)
{
    ORBmatcher matcher(0.8);     // 创建一个ORB特征匹配器，匹配阈值设置为0.8
    //ORBmatcher: 这是一个基于ORB特征的匹配器，用于寻找关键帧之间的匹配地图点。这里的阈值 0.8 可能用于控制匹配的严格程度，一般而言，这个值越低，匹配越严格。

    ////循环遍历：对每个校正后的关键帧和其姿态进行遍历。
    for(KeyFrameAndPose::const_iterator mit=CorrectedPosesMap.begin(), mend=CorrectedPosesMap.end(); mit!=mend;mit++)
    {
        kfptr pKF = mit->first;     // 当前关键帧

        g2o::Sim3 g2oScw = mit->second;   // 获取当前关键帧的校正后的Sim3姿态
        //姿态转换：使用 Converter::toCvMat 函数将 g2o::Sim3 类型的姿态转换为 cv::Mat 类型，以便用于后续的图像处理和特征匹配。
        cv::Mat cvScw = Converter::toCvMat(g2oScw);     // 将g2o的Sim3转换为OpenCV的Mat格式

     //初始化替换向量：创建一个和环路地图点数量相同的向量，初始化为 nullptr，用于存储将要替换的地图点。
    //融合操作：调用 matcher.Fuse 函数，它将使用校正后的姿态和关键帧信息来寻找并融合重复的地图点。
        vector<mpptr> vpReplacePoints(vpLoopMapPoints.size(),nullptr);
        matcher.Fuse(pKF,cvScw,vpLoopMapPoints,4,vpReplacePoints);

        const int nLP = vpLoopMapPoints.size();
        //替换操作：遍历每个可能的替换点，如果找到有效的替换点，
        //则使用 ReplaceAndLock 方法将原始地图点替换为新的地图点，并锁定该点以防止进一步修改。
        for(int i=0; i<nLP;i++)
        {
            mpptr pRep = vpReplacePoints[i];    // 获取替换地图点
            if(pRep)
            {
                pRep->ReplaceAndLock(vpLoopMapPoints[i]);   // 如果存在替换点，则进行替换并锁定
            }
        }
    }
}

//设置 MapMerger 对象的状态为忙碌（bIsBusy 设置为 true）
void MapMerger::SetBusy()
{
    //unique_lock<mutex>: 这行代码创建了一个互斥锁的守护对象，确保在修改 bIsBusy 状态时不会发生数据竞争。
    //unique_lock 提供了比 lock_guard 更灵活的锁管理功能，允许锁的延迟锁定、时间锁定和解锁。
    unique_lock<mutex> lock(mMutexBusy);
    //线程安全: 通过锁定互斥量 mMutexBusy，这个方法在多线程环境中是线程安全的，保证了状态修改的原子性和一致性。
    bIsBusy = true;
}

//将 MapMerger 对象的状态设置为闲置（bIsBusy 设置为 false）。
void MapMerger::SetIdle()
{
    //与 SetBusy 方法相似，这里也使用了 unique_lock<mutex> 来确保在多线程环境中安全地修改状态。
    unique_lock<mutex> lock(mMutexBusy);
    bIsBusy = false;
}

//返回 MapMerger 对象的当前状态，即是否处于忙碌状态。
bool MapMerger::isBusy()
{
    //通过使用 unique_lock<mutex> 锁定互斥量，这个方法在访问 bIsBusy 变量时保护了数据的一致性和完整性。
    unique_lock<mutex> lock(mMutexBusy);
    return bIsBusy;
}

void MapMerger::RunGBA(idpair nLoopKf, mapptr pFusedMap)
{
    cout << "-> Starting Global Bundle Adjustment" << endl;

    Optimizer::MapFusionGBA(pFusedMap,pFusedMap->mMapId,params::opt::mGBAIterations,&(pFusedMap->mbStopGBA),nLoopKf,true);

    set<ccptr> spCC = pFusedMap->GetCCPtrs();

    #ifdef FINALBA
    if(!pFusedMap->mbStopGBA)
    #endif
    {
        unique_lock<mutex> lock(pFusedMap->mMutexGBA);

//        while(!pFusedMap->LockMapUpdate()){usleep(params::timings::miLockSleep);}

        cout << "-> Global Bundle Adjustment finished" << endl;
        cout << "-> Updating map ..." << endl;

        // Correct keyframes starting at map first keyframe
        list<kfptr> lpKFtoCheck(pFusedMap->mvpKeyFrameOrigins.begin(),pFusedMap->mvpKeyFrameOrigins.end());

        cout << "--> Updating KFs ..." << endl;

        while(!lpKFtoCheck.empty())
        {
            kfptr pKF = lpKFtoCheck.front();
            const set<kfptr> sChilds = pKF->GetChilds();
            cv::Mat Twc = pKF->GetPoseInverse();
            for(set<kfptr>::const_iterator sit=sChilds.begin();sit!=sChilds.end();sit++)
            {
                kfptr pChild = *sit;
                if(pChild->mBAGlobalForKF!=nLoopKf)
                {
                    cv::Mat Tchildc = pChild->GetPose()*Twc;
                    pChild->mTcwGBA = Tchildc*pKF->mTcwGBA;
                    #ifdef DEBUGGING2
                    if(!(pChild->mTcwGBA.dims >= 2))
                        std::cout << COUTERROR << " KF" << pChild->mId.first << "|" << pChild->mId.second << ": !(pChild->mTcwGBA.dims >= 2)" << std::endl;
                    #endif
                    pChild->mBAGlobalForKF=nLoopKf;

                }
                lpKFtoCheck.push_back(pChild);
            }

            #ifdef DEBUGGING2
            if(!(pKF->mTcwGBA.dims >= 2))
                std::cout << COUTERROR << " KF" << pKF->mId.first << "|" << pKF->mId.second << ": !(pKF->mTcwGBA.dims >= 2)" << std::endl;
            #endif

            pKF->mTcwBefGBA = pKF->GetPose();
            #ifdef DEBUGGING2
            if(!(pKF->mTcwBefGBA.dims >= 2))
                std::cout << COUTERROR << " KF" << pKF->mId.first << "|" << pKF->mId.second << ": !(pKF->mTcwBefGBA.dims >= 2)" << std::endl;
            #endif
            pKF->SetPose(pKF->mTcwGBA,true);
            lpKFtoCheck.pop_front();
        }

        cout << "--> Updating MPs ..." << endl;

        // Correct MapPoints
        const vector<mpptr> vpMPs = pFusedMap->GetAllMapPoints();

        for(size_t i=0; i<vpMPs.size(); i++)
        {
            mpptr pMP = vpMPs[i];

            if(pMP->isBad())
                continue;

            if(pMP->mBAGlobalForKF==nLoopKf)
            {
                // If optimized by Global BA, just update
                #ifdef DEBUGGING2
                if(!(pMP->mPosGBA.dims >= 2))
                    std::cout << COUTERROR << " MP" << pMP->mId.first << "|" << pMP->mId.second << ": !(pMP->mPosGBA.dims >= 2)" << std::endl;
                #endif
                pMP->SetWorldPos(pMP->mPosGBA,true);
            }
            else
            {
                // Update according to the correction of its reference keyframe
                kfptr pRefKF = pMP->GetReferenceKeyFrame();

                if(!pRefKF)
                {
                    cout << "\033[1;31m!!! ERROR !!!\033[0m In \"LoopFinder::CorrectLoop()\": pRefKf is nullptr" << endl;
                    continue;
                }

                if(pRefKF->mBAGlobalForKF!=nLoopKf)
                    continue;

                #ifdef DEBUGGING2
                if(!(pRefKF->mTcwBefGBA.dims >= 2))
                {
                    std::cout << COUTERROR << " KF" << pRefKF->mId.first << "|" << pRefKF->mId.second << ": !(pRefKF->mTcwBefGBA.dims >= 2)" << std::endl;
                    std::cout << "bad? " << (int)pRefKF->isBad() << std::endl;
                    std::cout << "mBAGlobalForKF: " << pRefKF->mBAGlobalForKF.first << "|" << pRefKF->mBAGlobalForKF.second << std::endl;
                    std::cout << "nLoopKF: " << nLoopKf.first << "|" << nLoopKf.second << std::endl;
//                    kfptr pKFp = pRefKF->GetParent();
//                    std::cout << "Parent " << pKFp->mId.first << "|" << pKFp->mId.second << " -- bad: " << (int)pKFp->isBad() << std::endl;

                    std::cout << "KF Lineage: " << std::endl;
                    kfptr pKFp = pRefKF->GetParent();
                    while(pKFp)
                    {
                        std::cout << "--> " << pKFp->mId.first << "|" << pKFp->mId.second << " -- bad: " << (int)pKFp->isBad() << std::endl;
                        if(pKFp == pKFp->GetParent())
                        {
                            std::cout << "--> " << pKFp->mId.first << "|" << pKFp->mId.second << " -- bad: " << (int)pKFp->isBad() << std::endl;
                            break;
                        }
                        pKFp = pKFp->GetParent();
                    }

                    pRefKF->mTcwBefGBA = pRefKF->GetPose();
                }
                #endif


                // Map to non-corrected camera
                cv::Mat Rcw = pRefKF->mTcwBefGBA.rowRange(0,3).colRange(0,3);
                cv::Mat tcw = pRefKF->mTcwBefGBA.rowRange(0,3).col(3);
                cv::Mat Xc = Rcw*pMP->GetWorldPos()+tcw;

                // Backproject using corrected camera
                cv::Mat Twc = pRefKF->GetPoseInverse();
                cv::Mat Rwc = Twc.rowRange(0,3).colRange(0,3);
                cv::Mat twc = Twc.rowRange(0,3).col(3);

                pMP->SetWorldPos(Rwc*Xc+twc,true);
            }
        }

        cout << "-> Map updated!" << endl;

        #ifdef FINALBA
        pFusedMap->unsetGBAinterrupted();
        #endif

        #ifdef DONOTINTERRUPTMERGE
        pFusedMap->unsetMergeStepGBA();
        #endif

//        pFusedMap->UnLockMapUpdate();
    }
    #ifdef FINALBA
    else
    {
        cout << COUTNOTICE << "GBA interrupted" << endl;

        #ifdef DONOTINTERRUPTMERGE
        if(pFusedMap->isMergeStepGBA())
        {
            cout << COUTFATAL << endl;
            KILLSYS
        }
        #endif

        pFusedMap->setGBAinterrupted();
    }
    #endif

    if(params::stats::mbWriteKFsToFile)
    {
        for(int it=0;it<4;++it)
        {
            std::stringstream ss;
            ss << params::stats::msOutputDir << "KF_GBA_" << it << ".csv";
            pFusedMap->WriteStateToCsv(ss.str(),it);
        }
    }

    pFusedMap->setFinishedGBA();
    pFusedMap->unsetRunningGBA();

    for(set<ccptr>::iterator sit = spCC.begin();sit!=spCC.end();++sit)
    {
        ccptr pCC = *sit;
        pCC->mbOptimized= true;

        pCC->UnLockMapping();

        pCC->mbOptActive = false;
    }

    cout << "-> Leave Thread" << endl;
}

}
