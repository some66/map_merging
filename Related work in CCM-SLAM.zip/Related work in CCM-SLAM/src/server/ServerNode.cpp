/**
* This file is part of CCM-SLAM.
*
* Copyright (C): Patrik Schmuck <pschmuck at ethz dot ch> (ETH Zurich)
* For more information see <https://github.com/patriksc/CCM-SLAM>
*
* CCM-SLAM is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* CCM-SLAM is based in the monocular version of ORB-SLAM2 by Raúl Mur-Artal.
* CCM-SLAM partially re-uses modules of ORB-SLAM2 in modified or unmodified condition.
* For more information see <https://github.com/raulmur/ORB_SLAM2>.
*
* CCM-SLAM is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CCM-SLAM. If not, see <http://www.gnu.org/licenses/>.
*/


#include <cslam/server/ServerSystem.h>

int main(int argc, char **argv) {

//初始化一个ROS节点，命名为"CSLAM server node"。这一步为节点设置基本配置，并处理任何ROS特定的命令行参数。
    ros::init(argc, argv, "CSLAM server node");

//检查命令行参数,  检查传递给程序的命令行参数数量。如果参数数量不正确（不等于2），则向标准错误输出使用说明，并关闭ROS节点，然后退出程序。
    if(argc != 2)
    {
        cerr << endl << "Usage: rosrun cslam clientnode path_to_vocabulary" << endl;
        ros::shutdown();
        return 1;
    }

//创建节点句柄
    ros::NodeHandle Nh;     // 创建一个全局节点句柄，用于通用的ROS通信。
    ros::NodeHandle NhPrivate("~");     //创建一个私有节点句柄，用于访问该节点私有命名空间下的参数。

//创建并初始化服务器系统,   该函数在serversystem.cpp中。
    boost::shared_ptr<cslam::ServerSystem> pSSys{new cslam::ServerSystem(Nh,NhPrivate,argv[1])};
    //使用智能指针创建一个 cslam::ServerSystem 对象实例。
    //构造函数接收节点句柄、私有节点句柄和词汇表路径（从命令行参数获取）

//该函数在serversystem.cpp中。
    pSSys->InitializeClients();
//调用 ServerSystem 类的 InitializeClients 方法，这可能是用于初始化与服务器连接的客户端的方法。

//向ROS控制台输出信息，表明CSLAM服务器节点已启动。
    ROS_INFO("started CSLAM server node...");

//设置并启动多线程消息处理,  创建一个具有两个线程的ros::MultiThreadedSpinner，这允许节点同时处理来自ROS网络的多个消息回调。
    ros::MultiThreadedSpinner MSpin(2);   

    // 调用spin()方法开始消息处理循环，此循环会持续运行，处理所有进入的消息，直到节点被显式地请求关闭。
    MSpin.spin();   

//waitForShutdown()函数会阻塞当前线程，直到ROS节点被外部请求关闭。
//这常见于ROS节点，以确保它们能够持续响应外部命令或处理消息，直到收到停止命令。
    ros::waitForShutdown();    

//正常退出程序,   程序返回0，表示正常退出。 
    return 0;
}
