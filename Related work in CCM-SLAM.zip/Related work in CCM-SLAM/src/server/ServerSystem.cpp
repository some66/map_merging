/**
* This file is part of CCM-SLAM.
*
* Copyright (C): Patrik Schmuck <pschmuck at ethz dot ch> (ETH Zurich)
* For more information see <https://github.com/patriksc/CCM-SLAM>
*
* CCM-SLAM is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* CCM-SLAM is based in the monocular version of ORB-SLAM2 by Raúl Mur-Artal.
* CCM-SLAM partially re-uses modules of ORB-SLAM2 in modified or unmodified condition.
* For more information see <https://github.com/raulmur/ORB_SLAM2>.
*
* CCM-SLAM is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CCM-SLAM. If not, see <http://www.gnu.org/licenses/>.
*/

#include <cslam/server/ServerSystem.h>

namespace cslam{

ServerSystem::ServerSystem(ros::NodeHandle Nh, ros::NodeHandle NhPrivate, const string &strVocFile)
    : mNh(Nh), mNhPrivate(NhPrivate), mMaxClients(4), mpUID(new estd::UniqueIdDispenser())
{
    params::ShowParams();

    mNhPrivate.param("NumOfClients",mNumOfClients,0);

    mServiceSavemap = mNh.advertiseService("ccmslam_savemap",&ServerSystem::CallbackSaveMap, this);

    if(mNumOfClients < 1)
    {
        ROS_ERROR_STREAM("In \" System::System(...)\": Num od clients < 1");
        throw estd::infrastructure_ex();
    }

    //+++++ load vocabulary +++++

    this->LoadVocabulary(strVocFile);

    //+++++ Create KeyFrame Database +++++
    // 函数在本文件下方
    this->InitializeKFDB();

    //+++++ Create the Map +++++
      // 函数在本文件下方
    this->InitializeMaps();

    //+++++ Create the Viewer +++++
    //  // 函数在本文件下方
    this->InitializeViewer();

    #ifdef LOGGING
    mpLogger.reset(new estd::mylog(30.0,10000000));
    mptLogger.reset(new thread(&estd::mylog::run,mpLogger));
    #endif
}


//ROS服务回调函数，用于保存地图数据。该函数从服务请求中接收一个地图ID，并根据该ID将对应的地图数据保存到指定位置。
bool ServerSystem::CallbackSaveMap(ccmslam::ServiceSaveMap::Request &req, ccmslam::ServiceSaveMap::Response &res) {
    int map_id = req.map_id;    //ccmslam::ServiceSaveMap::Request &req：服务请求，包含需要操作的地图ID等信息。
    //ccmslam::ServiceSaveMap::Response &res：服务响应，可以设置响应的状态或返回的数据。（虽然在这段代码中没有显示设置响应内容）
    std::cout << "Service: Save Map for Map-ID " << map_id << std::endl;   

//设置文件路径：使用 std::stringstream 构建文件保存路径，路径由配置参数 params::stats::msOutputDir 和子目录 "map_data/" 组成。
// 输出完整的文件保存路径
    std::stringstream filepath;
    filepath << params::stats::msOutputDir << "map_data/";
    std::cout << "----> saving map to: " << filepath.str() << std::endl;

//检查目录状态：使用 boost::filesystem::is_empty 函数检查指定的文件夹是否为空。如果不为空，输出错误信息并返回 false，表示保存失败。
    if(!boost::filesystem::is_empty(filepath.str())) {
        std::cout << COUTERROR << "folder for map data is not empty!" << std::endl;
        return false;
    }
    //根据地图ID保存地图：通过条件判断，根据请求中的 map_id 调用对应的客户端对象
//（mpClient0, mpClient1, mpClient2, mpClient3）的 SaveMap 方法，传入构建的文件路径作为参数。
    if(map_id == 0) mpClient0->SaveMap(filepath.str());
    if(map_id == 1) mpClient1->SaveMap(filepath.str());
    if(map_id == 2) mpClient2->SaveMap(filepath.str());
    if(map_id == 3) mpClient3->SaveMap(filepath.str());
    std::cout << "----> Done" << std::endl;
    return true;
}


//服务器系统中初始化客户端相关的配置，尤其是处理与关键帧（Key Frames，KFs）文件输出相关的设置。下面是对代码的具体解释：
//在server节点中使用该函数
void ServerSystem::InitializeClients()
{
    //Cannot be called from constructor - shared_from_this() not available
//注释指出 InitializeClients 方法不能从构造函数中调用，因为在构造函数执行期间 shared_from_this() 方法是不可用的。
//shared_from_this() 用于获取当前对象的 shared_ptr 引用，但只有在至少有一个 shared_ptr 已经拥有该对象之后才有效。

//首先检查 params::stats::mbWriteKFsToFile 标志，这是一个布尔值，决定是否需要将关键帧数据写入文件。
//如果该标志为真，则执行以下操作：
    if(params::stats::mbWriteKFsToFile)
    {
        for(int it=0;it<4;++it)
        {
            std::stringstream ss;  
            // 使用 std::stringstream 构建文件名，文件名包括输出目录 params::stats::msOutputDir，
            // 文件基本名称 "KF_GBA_"，循环索引 it，和文件扩展名 ".csv"
            ss << params::stats::msOutputDir << "KF_GBA_" << it << ".csv";
            //调用 CleanWriteOutFile 方法，传入构建的文件路径字符串。
            //这个方法可能负责清除已存在的文件内容或创建一个新的空文件，以便写入新的关键帧数据。
            this->CleanWriteOutFile(ss.str());
        }
    }

    //Client 0,   从ROS节点的私有参数中获取配置信息，并据此配置并初始化一个名为 ClientHandler 的客户端处理器的过程。

    bool bLoadMapFromFile;
     //获取地图加载设置：
    //这行代码使用 param 方法从私有命名空间中获取一个名为 "LoadMap" 的参数，这个参数决定是否从文件中加载地图。
    //bLoadMapFromFile 是一个布尔变量，用来存储获取的参数值。
    //false 是默认值，意味着如果 "LoadMap" 参数在参数服务器上不存在，bLoadMapFromFile 将被设置为 false。
    mNhPrivate.param("LoadMap",bLoadMapFromFile,false);

    // 客户端处理器初始化, 初始化 ClientHandler 对象：
    //  使用智能指针 mpClient0 创建并存储一个 ClientHandler 实例。
    // 构造函数接收多个参数，包括节点句柄、视觉词汇库、关键帧数据库、地图对象、客户端ID、系统状态、一个空字符串（可能用于指定配置或文件路径）、视图显示器对象和地图加载标志。
   // 这样的构造说明 ClientHandler 需要处理视觉词汇、关键帧数据库、地图显示以及可选的地图加载功能。
     //函数来源于ClientHandler.cpp
    mpClient0.reset(new ClientHandler(mNh,mNhPrivate,mpVoc,mpKFDB,mpMap0,0,mpUID,eSystemState::SERVER,string(),mpViewer,bLoadMapFromFile));

    #ifdef LOGGING
    mpClient0->InitializeThreads(mpLogger);
    #else
    //  //函数来源于ClientHandler.cpp
    mpClient0->InitializeThreads();
    #endif

    if(bLoadMapFromFile) {
        std::cout << "### Load Map ###" << std::endl;
        std::stringstream filepath;
        filepath << params::stats::msOutputDir << "map_data";
        std::cout << "----> Load map from: " << filepath.str() << std::endl;
        if(boost::filesystem::is_empty(filepath.str())) {
            std::cout << COUTERROR << "folder for map data is empty!" << std::endl;
        } else
            //函数来源于ClientHandler.cpp
            mpClient0->LoadMap(filepath.str());
    }

    //Client 1
    if(mNumOfClients > 1)
    {
        //函数来源于ClientHandler.cpp
        mpClient1.reset(new ClientHandler(mNh,mNhPrivate,mpVoc,mpKFDB,mpMap1,1,mpUID,eSystemState::SERVER,string(),mpViewer));
        #ifdef LOGGING
        mpClient1->InitializeThreads(mpLogger);
        #else
        mpClient1->InitializeThreads();
        #endif
    }

    //Client 2
    if(mNumOfClients > 2)
    {
        mpClient2.reset(new ClientHandler(mNh,mNhPrivate,mpVoc,mpKFDB,mpMap2,2,mpUID,eSystemState::SERVER,string(),mpViewer));
        #ifdef LOGGING
        mpClient2->InitializeThreads(mpLogger);
        #else
        mpClient2->InitializeThreads();
        #endif
    }

    //Client 3
    if(mNumOfClients > 3)
    {
        mpClient3.reset(new ClientHandler(mNh,mNhPrivate,mpVoc,mpKFDB,mpMap3,3,mpUID,eSystemState::SERVER,string(),mpViewer));
        #ifdef LOGGING
        mpClient3->InitializeThreads(mpLogger);
        #else
        mpClient3->InitializeThreads();
        #endif
    }

    if(mNumOfClients > mMaxClients)
    {
        cout << "\033[1;33m!!! WARN !!!\033[0m Maximum number of clients is " << mMaxClients << endl;
    }

// 函数在该文件的下方
//先初始化ClientHandler的server, 再初始化mapmatcher
    this->InitializeMapMatcher();
}

void ServerSystem::LoadVocabulary(const string &strVocFile)
{
    //Load ORB Vocabulary
    cout << endl << "Loading ORB Vocabulary. This could take a while..." << endl;

    mpVoc.reset(new ORBVocabulary());
    bool bVocLoad = mpVoc->loadFromTextFile(strVocFile);
    if(!bVocLoad)
    {
        cerr << "Wrong path to vocabulary. " << endl;
        cerr << "Failed to open at: " << strVocFile << endl;
        exit(-1);
    }
    cout << "Vocabulary loaded!" << endl << endl;
}

//初始化地图对象：这个方法负责根据服务器系统中客户端的数量，为每个客户端创建和初始化相应的地图对象。
//每个地图对象是 Map 类的实例，用于管理和存储该客户端的地图数据和状态。
void ServerSystem::InitializeMaps()
{
    //这行代码创建了第一个客户端的地图对象。这里使用 reset 方法重新初始化智能指针 mpMap0，指向一个新创建的 Map 对象。
    //该对象使用两个节点句柄（mNh 和 mNhPrivate），客户端ID（0），和系统状态（SERVER）作为构造函数的参数。
    //  //函数来源于Map.cpp
    mpMap0.reset(new Map(mNh,mNhPrivate,0,eSystemState::SERVER));
    
    //如果系统中的客户端数量大于1，那么为第二个客户端创建一个地图对象，否则将 mpMap1 设置为 nullptr。
    if(mNumOfClients > 1) mpMap1.reset(new Map(mNh,mNhPrivate,1,eSystemState::SERVER)); else mpMap1=nullptr;
    if(mNumOfClients > 2) mpMap2.reset(new Map(mNh,mNhPrivate,2,eSystemState::SERVER)); else mpMap2=nullptr;
    if(mNumOfClients > 3) mpMap3.reset(new Map(mNh,mNhPrivate,3,eSystemState::SERVER)); else mpMap3=nullptr;
}

//初始化关键帧数据库：该方法通过创建一个新的 KeyFrameDatabase 对象来初始化关键帧数据库，并将其与已经加载的词汇库（mpVoc）关联。
//这个词汇库包含了用于描述关键帧的视觉词汇，是进行关键帧比较和识别的基础。
void ServerSystem::InitializeKFDB()
{
    //函数来源于database.cpp
    mpKFDB.reset(new KeyFrameDatabase(mpVoc));
//使用 reset 方法重新初始化智能指针 mpKFDB，指向一个新创建的 KeyFrameDatabase 对象。
//在创建 KeyFrameDatabase 对象时，将 mpVoc 作为构造参数传递。这里的 mpVoc 指的是一个包含视觉词汇的对象，
//通常是在系统初始化阶段加载的ORB词汇库（或其他类型的词汇库），用于特征匹配和图像识别。
}


void ServerSystem::InitializeMapMatcher()
{
    //创建地图匹配器对象：使用 reset 方法初始化智能指针 mpMapMatcher，指向新创建的 MapMatcher 对象。
   //MapMatcher 的构造函数接收多个参数，包括两个节点句柄（mNh 和 mNhPrivate）、关键帧数据库（mpKFDB）、
   // 视觉词汇库（mpVoc）和四个地图对象（mpMap0 到 mpMap3）。这些参数为地图匹配提供了必要的数据和上下文环境。
   //函数来源于MapMatcher.cpp
    mpMapMatcher.reset(new MapMatcher(mNh,mNhPrivate,mpKFDB,mpVoc,mpMap0,mpMap1,mpMap2,mpMap3));

    //启动地图匹配线程：同样使用 reset 方法初始化另一个智能指针 mptMapMatching，这次指向一个新创建的线程，
    //该线程运行 MapMatcher 类的 Run 方法。这样做的目的是让地图匹配过程在后台独立运行，不会阻塞主程序的其他操作。
    mptMapMatching.reset(new thread(&MapMatcher::Run,mpMapMatcher));

    // 配置客户端使用地图匹配器, 代码中使用了条件判断来确认是否存在特定的客户端（mpClient0 到 mpClient3）。
    // 如果客户端存在，则调用其 SetMapMatcher 方法，将 mpMapMatcher 作为参数传递，以设置和更新客户端的地图匹配器。
    if(mpClient0) mpClient0->SetMapMatcher(mpMapMatcher);
    if(mpClient1) mpClient1->SetMapMatcher(mpMapMatcher);
    if(mpClient2) mpClient2->SetMapMatcher(mpMapMatcher);
    if(mpClient3) mpClient3->SetMapMatcher(mpMapMatcher);
}


void ServerSystem::InitializeViewer()
{
    //create a ccptr
    // 创建中央控制对象：这行代码通过智能指针 ccptr 创建了一个 CentralControl 对象实例。CentralControl 负责管理和协调SLAM系统的各个组件。
    // mNh 和 mNhPrivate：ROS节点的全局和私有句柄，用于处理ROS通信。
    // -1：可能表示这个控制中心的客户端ID，这里设为 -1 可能意味着它是为服务器配置或不特定于任何一个客户端。
   //  eSystemState::SERVER：系统状态，表明这个组件在服务器模式下运行。
   //  最后两个 nullptr 可能是可选的配置或依赖组件，这里没有提供，表明可能使用默认设置或不需要这些配置。
    ccptr pCC{new CentralControl(mNh,mNhPrivate,-1,eSystemState::SERVER,nullptr,nullptr)};

    //  create Viewer
    //  创建视图显示器：使用 reset 方法初始化智能指针 mpViewer，指向新创建的 Viewer 对象。
    //  Viewer 的构造函数接收两个参数：第一个 nullptr 可能表示没有直接关联的图形界面或渲染上下文，
    //  第二个参数是之前创建的 CentralControl 对象，用于视图显示器从中央控制组件获取必要的信息和指令。
    mpViewer.reset(new Viewer(nullptr,pCC));
    
 //启动视图显示器线程：再次使用 reset 方法初始化智能指针 mptViewer，这次指向一个新创建的线程，该线程运行 Viewer 类的 RunServer 方法。
//这样设计的目的是使视图显示器能够在后台线程中运行，从而不会干扰主程序的其他处理过程，同时确保实时的视图更新和用户交互。
    mptViewer.reset(new thread(&Viewer::RunServer,mpViewer));
}


//用于清理或初始化一个指定的文件。这通常在系统准备记录新的数据之前执行，以确保文件是空的，避免在新的数据写入时与旧数据混合。
void ServerSystem::CleanWriteOutFile(string sFileName)
{
    // Write out the keyframe data,   这行代码向控制台输出一个消息，表明正在清理的文件名。
    std::cout << "Cleaning file " << sFileName << std::endl;

    // 定义一个 std::ofstream 对象 keyframesFile，用于文件写入操作。
    std::ofstream keyframesFile;

     // 使用 open 方法打开指定的文件名 sFileName。
     // 打开模式设置为 std::ofstream::out | std::ofstream::trunc：
     // std::ofstream::out：指定文件用于写入操作。
     // std::ofstream::trunc：如果文件已存在，删除文件中的所有内容，即截断文件到长度为零。如果文件不存在，创建一个新文件。
    keyframesFile.open(sFileName, std::ofstream::out | std::ofstream::trunc);

    //关闭文件流。即使不显式调用 close，文件流的析构函数在 keyframesFile 对象生命周期结束时也会自动关闭文件.
    keyframesFile.close();
}

} //end namespace
