/**
* This file is part of CCM-SLAM.
*
* Copyright (C): Patrik Schmuck <pschmuck at ethz dot ch> (ETH Zurich)
* For more information see <https://github.com/patriksc/CCM-SLAM>
*
* CCM-SLAM is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* CCM-SLAM is based in the monocular version of ORB-SLAM2 by Raúl Mur-Artal.
* CCM-SLAM partially re-uses modules of ORB-SLAM2 in modified or unmodified condition.
* For more information see <https://github.com/raulmur/ORB_SLAM2>.
*
* CCM-SLAM is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CCM-SLAM. If not, see <http://www.gnu.org/licenses/>.
*/

#include <cslam/MapMatcher.h>

namespace cslam {

//MapMatcher 类的构造函数，它在机器人操作系统（ROS）环境中用于初始化地图匹配模块，具体涉及多个地图和关键帧数据库的管理。
//构造函数初始化了许多成员变量，并设置了ROS的发布者和消息。
//Nh 和 NhPrivate: 两个 ROS 节点句柄，用于与 ROS 网络通信。Nh 用于通用目的，而 NhPrivate 通常用于处理与该节点相关的私有命名空间。
//pDB: 指向关键帧数据库的指针，用于存取关键帧。
//pVoc: 指向词袋模型的指针，通常用于图像特征的快速匹配。
//pMap0 到 pMap3: 指向四个不同地图的指针，可能代表不同区域或在不同时间创建的地图。
//构造函数初始化列表设置了节点句柄、数据库和词袋模型的指针，四个地图指针，以及一些用于地图匹配逻辑的其他成员变量。
MapMatcher::MapMatcher(ros::NodeHandle Nh, ros::NodeHandle NhPrivate, dbptr pDB, vocptr pVoc, mapptr pMap0, mapptr pMap1, mapptr pMap2, mapptr pMap3)
    : mNh(Nh), mNhPrivate(NhPrivate),
      mpKFDB(pDB), mpVoc(pVoc), mpMap0(pMap0), mpMap1(pMap1), mpMap2(pMap2), mpMap3(pMap3),
      mLastLoopKFid(0),
      mbFixScale(false),
      mnCovisibilityConsistencyTh(params::placerec::miCovisibilityConsistencyTh)
{
//这些代码行检查每个地图指针是否非空，然后将它们插入到 mmpMaps 映射中，这个映射关联每个地图与其对应客户端的 ID，
    if(pMap0) mmpMaps[*(pMap0->msuAssClients.begin())]=pMap0;
    if(pMap1) mmpMaps[*(pMap1->msuAssClients.begin())]=pMap1;
    if(pMap2) mmpMaps[*(pMap2->msuAssClients.begin())]=pMap2;
    if(pMap3) mmpMaps[*(pMap3->msuAssClients.begin())]=pMap3;

//以及一个集合 mspMaps 中，后者包含所有有效的地图指针。
    if(pMap0) mspMaps.insert(pMap0);
    if(pMap1) mspMaps.insert(pMap1);
    if(pMap2) mspMaps.insert(pMap2);
    if(pMap3) mspMaps.insert(pMap3);

//设置一个 ROS 发布者 mPubMarker，用于发布地图匹配过程中生成的标记，如可视化线和点。
    mPubMarker = mNh.advertise<visualization_msgs::Marker>("MapMatcherMarkers",10);
//数字 10 表示发布者的队列大小。在ROS（Robot Operating System，机器人操作系统）中，
//队列大小是一个重要的配置参数，它指定了在发送到订阅者之前，消息可以在发布者端积累的最大数量。

//初始化一个 4x4 的矩阵，用于存储地图之间的匹配得分或其他相关度量。
    mMatchMatrix =  cv::Mat::zeros(4,4,2);

//可视化消息设置, 初始化一个用于可视化的消息 mMapMatchEdgeMsg，设置其框架 ID、时间戳、命名空间、类型、颜色、动作和尺度。
//这用于在 ROS 环境中可视化地图匹配的结果。
    mMapMatchEdgeMsg.header.frame_id = "world";   //设置参考框架:  指定了消息的坐标参考框架为 "world"，意味着所有的坐标都是相对于世界坐标系的。
    mMapMatchEdgeMsg.header.stamp = ros::Time::now();   //设置时间戳: 时间戳设置为当前时间，这对于确保数据的时效性和同步非常关键，特别是在动态环境中。
    mMapMatchEdgeMsg.ns = "MapMatchEdges_red";  //设置命名空间: 命名空间用于区分不同的标记集合，这里的 "MapMatchEdges_red" 表示这组标记是用于显示地图匹配边缘的红色线。
    mMapMatchEdgeMsg.type = visualization_msgs::Marker::LINE_LIST;  //设置标记类型:  标记类型设置为 LINE_LIST，意味着该标记将以线列表的形式绘制，其中每对点都被视为线段的两端。
    mMapMatchEdgeMsg.color = Colors::msgRed();  //设置颜色:  颜色设置为红色，这里使用了一个可能自定义的 Colors::msgRed() 函数来获取预定义的红色值。
    mMapMatchEdgeMsg.action = visualization_msgs::Marker::ADD;  //设置动作:  动作设置为 ADD，表示这个标记应该被添加到可视化中。
    mMapMatchEdgeMsg.scale.x = params::vis::mfLoopMarkerSize;  //设置标记尺寸:  具体是线的粗细。mfLoopMarkerSize 是一个参数，定义了线的宽度，通常以米为单位。
    mMapMatchEdgeMsg.id = 1;   //设置标记ID: 每个标记需要一个唯一的ID，这样才能在之后单独更新或删除它。这里ID设置为1，对于管理单个类型的标记通常足够
}


//使用于ServerSystem.cpp中
//定义了 MapMatcher 类的 Run 方法，它是一个在单独线程中持续运行的函数，主要用于检测环路闭合、
//执行相应的环路纠正和图优化。这个函数非常关键，因为它负责维护SLAM系统地图的一致性和准确性。
void MapMatcher::Run()
{
    //初始化和配置
    double CovGraphMarkerSize;
    //读取参数：从私有节点句柄 mNhPrivate 中获取一个参数，这里是标记大小（用于可视化的标记）。
    //如果没有找到，就使用默认值 0.001, 本程序设置为0.02
    mNhPrivate.param("MarkerSizeServer",CovGraphMarkerSize,0.001);
    //创建 MapMerger 实例：使用 shared_from_this() 将当前对象的共享指针传递给 MapMerger 的新实例。
    //这样，MapMerger 可以访问 MapMatcher 的资源和方法。
    mpMapMerger.reset(new MapMerger(shared_from_this()));

//   日志和系统管理: 日志和错误处理：如果定义了 LOGGING，代码会尝试获取第一个地图 mpMap0 中的第一个控制中心指针 pCC。
//  如果指针无效，输出错误并停止系统。
    #ifdef LOGGING
    KeyFrame::ccptr pCC = mpMap0->GetCCPtr(0);
    if(!pCC)
    {
        std::cout << COUTERROR << "pCC not valid" << std::endl;
        KILLSYS
    }
    #endif

//无限循环：该方法在一个无限循环中运行，反复检查是否有新的关键帧处理，并尝试检测和纠正环路。
    while(1)
    {
        #ifdef LOGGING
        pCC->mpLogger->SetMatch(__LINE__,0);
        #endif

        //检查关键帧队列：CheckKfQueue() 检查是否有待处理的关键帧。
        if(CheckKfQueue())
        {
            // cout << "!!!FENG YU XUAN !!! 111" << endl;
            bool bDetect = DetectLoop();    //环路检测：如果有关键帧待处理，DetectLoop() 检测是否存在环路
            if(bDetect)
            {
                 
                bool bSim3 = ComputeSim3();    //Sim3 计算：如果检测到环路，ComputeSim3() 计算闭环关键帧之间的相似变换。
                if(bSim3)
                {            
                      // === 新增：计算 Sim3 的不确定性（协方差/信息） ===
                            Eigen::MatrixXd Sigma;
                            Eigen::MatrixXd Omega;
                            if (ComputeSim3Uncertainty(Sigma, &Omega))
                            {
                                mSigma_Sim3 = Sigma;
                                mOmega_Sim3 = Omega; // 直接可作为边的信息矩阵
                                // 你也可以把它塞进后端：edgeSim3->setInformation(mOmega_Sim3);
                            }
                            else
                            {
                                // 失败时给一个温和的信息矩阵，避免数值崩溃
                                const int dim = mbFixScale ? 6 : 7;
                                mOmega_Sim3 = 1e-4 * Eigen::MatrixXd::Identity(dim, dim);
                                mSigma_Sim3 = 1e4  * Eigen::MatrixXd::Identity(dim, dim);
                            }

                     //cout << "!!!FENG YU XUAN !!! 333" << endl;      
                     // Perform loop fusion and pose graph optimization
                    //函数来自于本文件的下方
                    //环路纠正：如果成功计算了变换，CorrectLoop() 执行环路融合和姿态图优化。
                    CorrectLoop();   
                }
            }
        }

       //日志记录：再次记录状态。
        #ifdef LOGGING
        pCC->mpLogger->SetMatch(__LINE__,0);
        #endif

     //休眠：每次循环结束后，根据预设的频率休眠（miPlaceRecRateRate），以减少资源消耗。
        usleep(params::timings::server::miPlaceRecRateRate);
    }
}



//通过分析关键帧队列和相关的地图信息，检查是否存在可能的环路闭合情况。
bool MapMatcher::DetectLoop()
{
    {
 //锁定和获取关键帧：首先锁定关键帧队列的互斥锁，然后从队列中获取并移除第一个关键帧（mpCurrentKF）。
 //使用 unique_lock 可以在作用域结束时自动释放锁，确保线程安全。
  //防止关键帧被删除：在处理关键帧时调用 SetNotErase() 方法，以防止在分析过程中关键帧被意外删除。   
        unique_lock<mutex> lock(mMutexKfInQueue);
        mpCurrentKF = mlKfInQueue.front();    // 获取关键帧队列中的第一个关键帧

        mlKfInQueue.pop_front();    // 移除队列中的这个关键帧
        // Avoid that a keyframe can be erased while it is being process by this thread
        //// 避免在这个线程处理关键帧时关键帧被删除
        mpCurrentKF->SetNotErase();
    }

//检测环路的前提条件：如果当前关键帧的ID小于一个预设的阈值（表示地图中关键帧数量还不足以进行环路检测，
//  或者距离上次环路检测还不够长），则允许删除这个关键帧并返回 false，表示没有检测到环路。
    //If the map contains less than 10 KF or less than 10 KF have passed from last loop detection
    // 如果地图中的关键帧数量少于10个，或者从上次环路检测后还没有过去10个关键帧
    //// 在合并初期时，有些场景会从这里结束该函数！！！！
    if(mpCurrentKF->mId.first<params::placerec::miStartMapMatchingAfterKf)
    {
        mpCurrentKF->SetErase();  // 允许删除这个关键帧
        return false;   //// 没有检测到环路         
    }

     //函数来自于keyframe.cpp文件中
    mpCurrMap = mpCurrentKF->GetMapptr(); //get map of KF,  // 获取关键帧所在地图：从当前关键帧获取其所在的地图指针。
   
 //错误处理：如果没有获取到地图（mpCurrMap 为 nullptr），输出错误信息并抛出异常。
 //这表示关键帧没有被包含在任何地图中，这可能是一个严重的系统错误。
    if(!mpCurrMap)
    {
        cout << ": In \"MapMatcher::DetectLoop()\": mpCurrMap is nullptr -> KF not contained in any map" << endl;
        throw estd::infrastructure_ex();
    }

    // Compute reference BoW similarity score
    // This is the lowest score to a connected keyframe in the covisibility graph
    // We will impose loop candidates to have a higher similarity than this
    // 计算当前关键帧与其共视图中连接的关键帧之间的基于词袋模型的最小相似度分数。
    // 这个分数用来设置环路候选关键帧必须超过的相似度阈值。    
    const vector<kfptr> vpConnectedKeyFrames = mpCurrentKF->GetVectorCovisibleKeyFrames();

    const DBoW2::BowVector &CurrentBowVec = mpCurrentKF->mBowVec;
    
    float minScore = 1;
    for(size_t i=0; i<vpConnectedKeyFrames.size(); i++)
    {
        kfptr pKF = vpConnectedKeyFrames[i];
        if(pKF->isBad())
            continue;
        const DBoW2::BowVector &BowVec = pKF->mBowVec;

        float score = mpVoc->score(CurrentBowVec, BowVec);

        if(score<minScore)
            minScore = score;
    }

 // Query the database imposing the minimum score
 // 函数来自于database.cpp文件
 //这段代码展示了视觉SLAM系统中，局部映射线程如何处理候选关键帧以检测潜在的地图匹配。
//这一部分代码的主要目的是识别与当前关键帧可能存在映射关系的候选关键帧，并处理当未找到有效候选时的情况。
//这行代码调用关键帧数据库 mpKFDB 的方法 DetectMapMatchCandidates，传入当前处理的关键帧 mpCurrentKF，最小得分阈值 minScore，和当前地图 mpCurrMap。
//此方法的作用是在关键帧数据库中查找与当前关键帧有足够得分的候选关键帧，这些得分基于某种匹配算法（如BoW得分）来评估关键帧之间的相似度。
//返回的 vpCandidateKFs 是一个包含可能与当前关键帧匹配的候选关键帧的向量。
    vector<kfptr> vpCandidateKFs = mpKFDB->DetectMapMatchCandidates(mpCurrentKF, minScore, mpCurrMap);

    // If there are no loop candidates, just add new keyframe and return false
    // 在运行时，每次检测到闭环都是从这里就停止了！！！！
    if(vpCandidateKFs.empty())
    {
         //如果没有找到任何候选关键帧，这行代码将清空当前地图 mpCurrMap 中记录的一致性组。
        //这是为了移除可能已过时或无用的一致性数据，因为没有新的匹配关键帧支持这些数据的更新。
        mmvConsistentGroups[mpCurrMap].clear();
        //将当前关键帧标记为应该被删除。这通常发生在关键帧被认为对构建或维护地图没有贡献时。
        mpCurrentKF->SetErase();
        //cout << "!!!FENG YU XUAN !!! 222" << endl;
        return false;
    }

    // For each loop candidate check consistency with previous loop candidates
    // Each candidate expands a covisibility group (keyframes connected to the loop candidate in the covisibility graph)
    // A group is consistent with a previous group if they share at least a keyframe
    // We must detect a consistent loop in several consecutive keyframes to accept it
    mvpEnoughConsistentCandidates.clear();

    vector<ConsistentGroup> vCurrentConsistentGroups; //pair <set<KF*>,int> --> int counts consistent groups found for this group
    vector<bool> vbConsistentGroup(mmvConsistentGroups[mpCurrMap].size(),false);
    //mvConsistentGroups stores the last found consistent groups.


//用于检查新的候选关键帧与现有一致性组（Consistent Groups）之间的关系，并更新一致性组信息。
//遍历候选关键帧列表 vpCandidateKFs
    for(size_t i=0, iend=vpCandidateKFs.size(); i<iend; i++)
    {
        //对于每个候选关键帧 pCandidateKF
        kfptr pCandidateKF = vpCandidateKFs[i];
        //获取其连接的关键帧集合 spCandidateGroup，并将自身加入该集合。
        set<kfptr> spCandidateGroup = pCandidateKF->GetConnectedKeyFrames();
        spCandidateGroup.insert(pCandidateKF);
        //group with candidate and connected KFs

        //此变量用于标记当前正在检查的候选关键帧是否与足够多的先前存在的一致性组显示了一致性，达到了系统设定的阈值。
        //如果一个候选关键帧与一个或多个一致性组表现出足够的一致性，这个变量会被设置为 true。
        bool bEnoughConsistent = false;     
        //此变量用于指示当前候选关键帧是否至少与现有一致性组中的一个显示了一致性。
        //即，它检查是否至少有一个先前的组包含了与当前候选关键帧一致的关键帧。
        bool bConsistentForSomeGroup = false;   

        //确定候选关键帧与现有的一致性组是否具有共同的关键帧，从而评估候选关键帧的一致性
        //遍历现有的一致性组
        //这个循环遍历当前地图 mpCurrMap 中记录的所有一致性组。每个组包含一组关键帧和一个与它们相关的一致性计数器。
        for(size_t iG=0, iendG=mmvConsistentGroups[mpCurrMap].size(); iG<iendG; iG++)
        {
            //获取组内关键帧集合,  从一致性组中提取第一个元素，即组内的关键帧集合。
            set<kfptr> sPreviousGroup = mmvConsistentGroups[mpCurrMap][iG].first;

           //检查候选关键帧组与现有组的一致性,  初始化一个标志变量，用于指示候选关键帧组是否与当前遍历的一致性组具有一致性。
            bool bConsistent = false;
            //遍历候选关键帧组中的每一个关键帧。
            for(set<kfptr>::iterator sit=spCandidateGroup.begin(), send=spCandidateGroup.end(); sit!=send;sit++)
            {
                //检查当前关键帧是否存在于遍历的一致性组中。如果存在，说明候选关键帧组与此一致性组至少有一个共同的关键帧。
                if(sPreviousGroup.count(*sit))
                {
                    //KF found that is contained in candidate's group and comparison group
                    bConsistent=true;
                    bConsistentForSomeGroup=true;
                    break;
                }
            }

            //更新一致性状态和计数器,  如果发现候选组与现有组一致，进行以下操作：
            if(bConsistent)   
            {
                //获取该组当前的一致性计数。
                int nPreviousConsistency = mmvConsistentGroups[mpCurrMap][iG].second;
                //更新一致性计数，增加1。
                int nCurrentConsistency = nPreviousConsistency + 1;
                if(!vbConsistentGroup[iG])    //如果这个组之前没有被标记为一致（避免重复计算和添加），则标记为一致，并更新全局一致性组列表。
                {
                    //创建一个新的一致性组条目。
                    ConsistentGroup cg = make_pair(spCandidateGroup,nCurrentConsistency);
                    //将新的一致性组添加到当前一致性组列表中。
                    vCurrentConsistentGroups.push_back(cg);
                    vbConsistentGroup[iG]=true; //this avoid to include the same group more than once
                }
                //如果更新后的一致性计数达到或超过了系统设置的阈值，并且候选关键帧还没有被标记为足够一致：
                if(nCurrentConsistency>=mnCovisibilityConsistencyTh && !bEnoughConsistent)
                {
                    mvpEnoughConsistentCandidates.push_back(pCandidateKF);   //将候选关键帧添加到“足够一致的候选关键帧”列表中。
                    //标记候选关键帧为足够一致，避免重复添加。
                    bEnoughConsistent=true; //this avoid to insert the same candidate more than once
                }
            }
        }

        // If the group is not consistent with any previous group insert with consistency counter set to zero
        // 这个条件检查 bConsistentForSomeGroup 标志，该标志在前面的代码中会被设置为 true 如果候选关键帧组至少与一个现有的一致性组一致。
        //如果该变量为 false，说明当前候选组与已知的所有一致性组都不一致。
        if(!bConsistentForSomeGroup)
        {
            //创建新的一致性组,  创建一个新的一致性组 cg，包括候选关键帧组 spCandidateGroup 和一个初始化为0的一致性计数器。
            //这里的 0 表示这个新组刚被创建，还没有在之后的循环中被确认过一致性。
            ConsistentGroup cg = make_pair(spCandidateGroup,0); //For "ConsistentGroup" the "int" is initialized with 0
            //将新组添加到一致性组列表,  将新创建的一致性组 cg 添加到当前一致性组列表 vCurrentConsistentGroups 中。
            //这样做是为了在后续的处理中能够考虑这个新的候选组，特别是在接下来的循环或闭环检测过程中。
            vCurrentConsistentGroups.push_back(cg);
        }
    }

    // Update Covisibility Consistent Groups
    //在视觉SLAM系统中更新和管理关键帧的协同可见组，以及基于找到的候选关键帧决定程序的执行流程
    //这行代码将当前地图 mpCurrMap 对应的协同可见组更新为最新的一组协同可见的关键帧组 vCurrentConsistentGroups。
    //更新协同可见组,    是那些视角相近且共同观测到许多同一地图点的关键帧的集合，这些组被用来帮助确定潜在的闭环。
    mmvConsistentGroups[mpCurrMap] = vCurrentConsistentGroups;

//检查候选关键帧，这个条件检查 mvpEnoughConsistentCandidates 集合是否为空。
//这个集合包含了那些通过之前的一系列检测，被认为与当前关键帧协同一致的候选关键帧。
//如果此集合为空，说明没有找到足够的候选关键帧来支持闭环的可能性。
    if(mvpEnoughConsistentCandidates.empty())
    {
        //如果没有足够的候选关键帧，当前处理的关键帧（mpCurrentKF）被标记为删除或忽略。
        //这通常意味着当前关键帧在地图的构建或闭环检测中不足以提供有用信息。
        mpCurrentKF->SetErase();
        return false;     //函数返回 false 表示闭环检测失败，没有足够的证据支持闭环存在。
    }
    else
    {       
       //在初始地图合并时候，必须从这里返回true值
        return true;
    }

   //标记这个关键帧为应该被删除或忽略，通常是因为它未能满足某些条件，如在闭环检测或地图构建过程中没有足够的信息或匹配点。
   //如果没有在true处返回，那么这个当前关键帧一定是不能满足的，所以删除。
    mpCurrentKF->SetErase();
    return false;   
}





// 将 g2o::Sim3 作用到 3D 点（世界->当前相机）
inline Eigen::Vector3d TransformPointSim3(const g2o::Sim3& S, const Eigen::Vector3d& Pw) {
    return S.rotation().toRotationMatrix() * Pw * S.scale() + S.translation();
}

// 当前相机内参投影（假设已去畸变）
// 返回：u,v 与是否在前方（Z>0）
inline bool ProjectPoint(const Eigen::Vector3d& Pc,
                         const float fx, const float fy, const float cx, const float cy,
                         float& u, float& v) {
    const double Z = Pc.z();
    if (Z <= 1e-6) return false;
    const double invZ = 1.0 / Z;
    u = static_cast<float>(fx * Pc.x() * invZ + cx);
    v = static_cast<float>(fy * Pc.y() * invZ + cy);
    return true;
}

void MapMatcher::GetIntrinsics(float& fx, float& fy, float& cx, float& cy) const
{
    fx = mpCurrentKF->fx;
    fy = mpCurrentKF->fy;
    cx = mpCurrentKF->cx;
    cy = mpCurrentKF->cy;
}

bool MapMatcher::ComputeSim3Uncertainty(Eigen::MatrixXd& Sigma_out,
                                        Eigen::MatrixXd* Omega_out)
{
    // 1) 前置检查
    if (mvpCurrentMatchedPoints.empty()) return false;

    // 最终的 world->current Sim3（ComputeSim3 成功后应已设置）
    g2o::Sim3 S_cw = mg2oScw;

    // 只做 6 维（旋转3 + 平移3），不扰动尺度
    const int dim = 6;

    // 取内参（建议用 lambda，避免 kfptr 可见性问题）
    float fx, fy, cx, cy;
    {
        auto getIntrinsics = [&](float& ofx, float& ofy, float& ocx, float& ocy) {
            ofx = mpCurrentKF->fx; ofy = mpCurrentKF->fy; ocx = mpCurrentKF->cx; ocy = mpCurrentKF->cy;
        };
        getIntrinsics(fx, fy, cx, cy);
    }

    struct Meas {
        Eigen::Vector3d Pw;   // 世界点
        Eigen::Vector2d z;    // 观测像素
        double w;             // 等效权重（先置 1，如需可接入鲁棒核）
    };
    std::vector<Meas> meas;
    meas.reserve(mvpCurrentMatchedPoints.size());

    // 2) 收集有效量测
    for (size_t i = 0; i < mvpCurrentMatchedPoints.size(); ++i) {
        mpptr pMP = mvpCurrentMatchedPoints[i];
        if (!pMP || pMP->isBad()) continue;

        const cv::KeyPoint& kp = mpCurrentKF->mvKeysUn[i];
        Eigen::Vector2d pix(kp.pt.x, kp.pt.y);

        const cv::Mat Pw_cv = pMP->GetWorldPos();
        Eigen::Vector3d Pw(Pw_cv.at<float>(0), Pw_cv.at<float>(1), Pw_cv.at<float>(2));

        Eigen::Vector3d Pc = TransformPointSim3(S_cw, Pw);
        float u, v;
        if (!ProjectPoint(Pc, fx, fy, cx, cy, u, v)) continue;

        meas.push_back({Pw, pix, 1.0});
    }
    if (meas.size() < static_cast<size_t>(std::max(10, dim*2))) return false;

    // 3) 信息矩阵 H（6x6）
    Eigen::Matrix<double,6,6> H; H.setZero();

    // 像素噪声（按需接配置）
    const double sigma_pix = 1.0;
    const double inv_var   = 1.0 / (sigma_pix * sigma_pix);

    // 数值差分步长
    const double eps_rot = 1e-6;   // 对 so(3)
    const double eps_tra = 1e-4;   // 对 t

    // 左乘增量：使用 VertexSim3Expmap::oplus 实现 exp(delta) ⊞ S
    auto leftPlus = [](const g2o::Sim3& S_base, const Eigen::Matrix<double,7,1>& delta7) {
        g2o::VertexSim3Expmap vtx;
        vtx.setEstimate(S_base);
        Eigen::Matrix<double,7,1> d = delta7; // 拷贝以便 oplus 修改
        vtx.oplus(d.data());                  // 左乘更新
        return vtx.estimate();
    };

    // 残差函数：2x1 像素重投影误差
    auto residual_fn = [&](const g2o::Sim3& S, const Meas& m, Eigen::Matrix<double,2,1>& r_out) -> bool
    {
        Eigen::Vector3d Pc = TransformPointSim3(S, m.Pw);
        float u,v;
        if (!ProjectPoint(Pc, fx, fy, cx, cy, u, v)) return false;
        r_out[0] = m.z[0] - u;
        r_out[1] = m.z[1] - v;
        return true;
    };

    // 4) 累计 H = Σ Jᵀ W J
    for (const Meas& m : meas) {
        Eigen::Matrix<double,2,1> r0;
        if (!residual_fn(S_cw, m, r0)) continue;

        Eigen::Matrix<double,2,6> J; J.setZero();

        // 6 维增量 → 扩展成 7 维（最后一维尺度置 0，不扰动）
        for (int k = 0; k < 6; ++k) {
            Eigen::Matrix<double,7,1> d = Eigen::Matrix<double,7,1>::Zero();
            double step = (k < 3) ? eps_rot : eps_tra;
            d[k] =  step;  // +eps
            g2o::Sim3 S_plus  = leftPlus(S_cw, d);

            d[k] = -step;  // -eps
            g2o::Sim3 S_minus = leftPlus(S_cw, d);

            Eigen::Matrix<double,2,1> r_plus, r_minus;
            bool okp = residual_fn(S_plus,  m, r_plus);
            bool okm = residual_fn(S_minus, m, r_minus);
            if (!okp || !okm) { J.col(k).setZero(); continue; }

            J.col(k) = (r_plus - r_minus) / (2.0 * step);
        }

        const double w = m.w; // 如有鲁棒核，把等效权重写进来
        H.noalias() += (w * inv_var) * (J.transpose() * J);
    }

    // 5) 正则（单目场景 + 局部退化时更稳）
    H += 1e-6 * Eigen::Matrix<double,6,6>::Identity();

    if (Omega_out) *Omega_out = H;

    // 6) 协方差（6x6）
    Eigen::Matrix<double,6,6> I6 = Eigen::Matrix<double,6,6>::Identity();
    Eigen::LDLT<Eigen::Matrix<double,6,6>> ldlt(H);
    if (ldlt.info() != Eigen::Success) {
        // 再加一点正则后重来
        Eigen::Matrix<double,6,6> Hreg = H + 1e-6 * I6;
        Sigma_out = Hreg.ldlt().solve(I6);
    } else {
        Sigma_out = ldlt.solve(I6);
    }
    return true;
}










bool MapMatcher::ComputeSim3()
{
   //初始化变量和数据结构, 这里获取候选关键帧的数量，这些关键帧已经被预筛选为足够一致的候选者。
    const int nInitialCandidates = mvpEnoughConsistentCandidates.size();

    // We compute first ORB matches for each candidate
    // If enough matches are found, we setup a Sim3Solver
    //初始化一个ORB特征匹配器，匹配器的构造参数指示使用0.75的比率测试和启用旋转不变性。
    ORBmatcher matcher(0.75,true);

    //创建一个Sim3求解器的向量，用于存储每个候选关键帧的Sim3求解器实例。
    vector<Sim3Solver*> vpSim3Solvers;
    //这里，vpSim3Solvers 是一个类型为 vector<Sim3Solver*> 的向量，存储了指向 Sim3Solver 对象的指针。
   //resize() 函数调整向量的大小以匹配 nInitialCandidates 的值，即候选关键帧的数量。
//如果 nInitialCandidates 的值大于当前向量的大小，resize() 会增加向量的长度，并为新添加的元素分配默认值（指针的默认值是 nullptr）。
//如果 nInitialCandidates 的值小于当前向量的大小，resize() 则会减少向量的长度，移除多余的元素。
    vpSim3Solvers.resize(nInitialCandidates);

    //创建一个二维向量，用于存储与每个候选关键帧匹配的地图点。
    vector<vector<mpptr> > vvpMapPointMatches;
    vvpMapPointMatches.resize(nInitialCandidates);

   //创建一个布尔向量，用于标记哪些候选关键帧因不满足条件而被丢弃。
    vector<bool> vbDiscarded;
    vbDiscarded.resize(nInitialCandidates);

//评估和确认足够一致的候选关键帧是否可以与当前关键帧正确地进行Sim3变换
    int nCandidates=0; //candidates with enough matches
     
//关键帧处理循环, 遍历每一个候选关键帧进行处理。
    for(int i=0; i<nInitialCandidates; i++)
    {
        //候选关键帧
        kfptr pKF = mvpEnoughConsistentCandidates[i];

        // avoid that local mapping erase it while it is being processed in this thread
        //调用 SetNotErase() 以防止这个关键帧在处理过程中被局部地图线程删除。
        pKF->SetNotErase();

      //检查当前关键帧是否已经被标记为无效（bad）。如果是，则跳过此帧。
        if(pKF->isBad())
        {
            vbDiscarded[i] = true;
            continue;
        }

       //使用词袋模型（BoW）在当前关键帧 mpCurrentKF 和候选关键帧 pKF 之间搜索匹配。匹配结果存储在 vvpMapPointMatches[i] 中。
       //函数在orbmatcher文件中
        int nmatches = matcher.SearchByBoW(mpCurrentKF,pKF,vvpMapPointMatches[i]);

//评估匹配结果, 如果找到的匹配数少于预设的阈值 mMatchesThres，则将该候选关键帧标记为丢弃。
        if(nmatches<params::opt::mMatchesThres)
        {

            vbDiscarded[i] = true;
            continue;
        }
        else  //如果匹配数足够，为当前候选关键帧创建一个Sim3求解器，并设置其RANSAC参数。
        {
            //初始化一个Sim3求解器，传入当前关键帧、候选关键帧、匹配的地图点以及是否固定比例因子。
            Sim3Solver* pSolver = new Sim3Solver(mpCurrentKF,pKF,vvpMapPointMatches[i],mbFixScale);

             //设置RANSAC算法的参数，包括成功概率、最小内点数和最大迭代次数。
            pSolver->SetRansacParameters(params::opt::mProbability,params::opt::mMinInliers,params::opt::mMaxIterations);
            //将初始化的求解器存储在求解器向量中，以便后续处理。
            vpSim3Solvers[i] = pSolver;
        }
             //统计足够匹配的候选关键帧数量。
        nCandidates++;
    }

    bool bMatch = false;

    // Perform alternatively RANSAC iterations for each candidate
    // until one is succesful or all fail
    //循环继续的条件是还有候选关键帧未被处理完毕（nCandidates > 0），并且还没有找到成功的匹配（!bMatch）。

    while(nCandidates>0 && !bMatch)
    {
        //遍历候选关键帧, 遍历所有初始的候选关键帧。这些关键帧是之前通过一致性测试选出的，可能与当前关键帧存在空间上的重合或接近。
        for(int i=0; i<nInitialCandidates; i++)
        {
            //检查并跳过已丢弃的关键帧,  如果当前候选关键帧已经被标记为丢弃（vbDiscarded[i] == true），则跳过这次循环，不对其进行进一步处理。
            if(vbDiscarded[i])
                continue;                
           
            kfptr pKF = mvpEnoughConsistentCandidates[i];

            //执行RANSAC迭代
            // Perform 5 Ransac Iterations
            vector<bool> vbInliers;
            int nInliers;
            bool bNoMore;

           //为每个候选关键帧获取之前创建的Sim3求解器实例。
            Sim3Solver* pSolver = vpSim3Solvers[i];
            //执行Sim3求解器的迭代方法，尝试找到当前关键帧与候选关键帧之间的Sim3变换。
            //方法返回可能的Sim3变换矩阵 Scm，并更新是否有更多迭代的标志 bNoMore、内点标志向量 vbInliers 和内点数量 nInliers。
          //使用计算机视觉库OpenCV时，涉及到调用一个求解器方法来迭代求解某个问题的一个示例
          //cv::Mat Scm: 这是一个OpenCV的矩阵对象，用于存储 iterate 方法返回的结果。cv::Mat 是OpenCV中用于存储图像数据或其他数学数据（如变换矩阵）的通用数据结构。
          //  pSolver: 这是指向一个求解器对象的指针，该对象具有 iterate 方法。这个求解器可能是用于RANSAC、LM优化或其他算法的实现。
          //params::opt::mSolverIterations: 这是传递给 iterate 方法的第一个参数，指定了迭代的次数。这通常是一个预定义的常量或变量，指明求解器应该运行的迭代轮数。
         //bNoMore: 这是一个布尔引用，用作输出参数。求解器通过这个参数向调用者传达是否还有必要继续迭代的信息（例如，在RANSAC中，如果已经找到了一个足够好的模型，就可能不需要更多的迭代）。
         //vbInliers: 这通常是一个布尔向量，每个元素对应于数据点是否为内点的标志。这个向量在迭代过程中更新，以反映哪些数据点符合当前估计的模型。
          //nInliers: 这是一个整数引用，用于输出内点的数量。在迭代过程中，求解器将计算并更新符合当前模型的数据点数量。
          //函数来自于sim3solver.cpp中而不是pnpsolver.cpp文件中
            cv::Mat Scm  = pSolver->iterate(params::opt::mSolverIterations,bNoMore,vbInliers,nInliers);
           // cout << "!!!FENG YU XUAN !!! 222" << endl;   
            // If Ransac reachs max. iterations discard keyframe
            //如果RANSAC达到了最大迭代次数而没有找到足够的内点支持变换，即 bNoMore 为true
            if(bNoMore)
            {
                //将当前关键帧标记为丢弃，因为它未能在RANSAC过程中证明其与当前关键帧具有足够的一致性。
                vbDiscarded[i]=true;
                //减少未处理的候选关键帧计数，表示少了一个有效的候选。
                nCandidates--;
            }


            // If RANSAC returns a Sim3, perform a guided matching and optimize with all correspondences
            //处理关键帧之间的相似变换（Sim3）后的优化流程。它详细描述了在RANSAC算法成功计算出一个Sim3变换后所执行的步骤。 
            //Scm.empty(), 如果该矩阵没有包含任何元素（即其尺寸为0或数据指针为空），则此函数返回 true；否则返回 false。
            if(!Scm.empty())    //检查RANSAC结果, 如果RANSAC返回的变换矩阵 Scm 非空，表示RANSAC成功找到了一个可行的Sim3变换。
            {
                //初始化一个地图点匹配向量，大小与当前候选关键帧的匹配点向量相同，初始值为NULL。
                vector<mpptr> vpMapPointMatches(vvpMapPointMatches[i].size(), static_cast<mpptr>(NULL));

               //遍历所有内点标志（由RANSAC确定的内点集合）
                for(size_t j=0, jend=vbInliers.size(); j<jend; j++)
                {
                    if(vbInliers[j])  //如果当前索引对应的点是内点，则将其从原始匹配中添加到用于优化的匹配点向量中。
                       vpMapPointMatches[j]=vvpMapPointMatches[i][j];
                }

                //从Sim3求解器中获取估计的旋转（R）、平移（t）和尺度（s）。
                cv::Mat R = pSolver->GetEstimatedRotation();
                cv::Mat t = pSolver->GetEstimatedTranslation();
                const float s = pSolver->GetEstimatedScale();

                //使用计算得到的Sim3参数（s, R, t）在当前关键帧和候选关键帧之间进行引导匹配。
                matcher.SearchBySim3(mpCurrentKF,pKF,vpMapPointMatches,s,R,t,7.5);

                //将旋转、平移和尺度转换为g2o库使用的Sim3格式。
                g2o::Sim3 gScm(Converter::toMatrix3d(R),Converter::toVector3d(t),s);
                //使用g2o优化库进一步优化Sim3变换，尝试改进变换的准确性和增加内点数量。
                const int nInliers = Optimizer::OptimizeSim3(mpCurrentKF, pKF, vpMapPointMatches, gScm, 10, mbFixScale);

                // If optimization is succesful stop ransacs and continue
                //判断优化是否成功, 如果优化后的内点数量达到预设阈值，认为优化成功。
                   // 打印 nInliers 的值
                if(nInliers>=params::opt::mInliersThres)
                {
                    bMatch = true;   //设置匹配成功标志。
                    mpMatchedKF = pKF;  //将候选关键帧设置为匹配的关键帧。
                    g2o::Sim3 gSmw(Converter::toMatrix3d(pKF->GetRotation()),Converter::toVector3d(pKF->GetTranslation()),1.0);
                     //这里的值是闭环检测计算的相对位姿乘以机器人的位姿,  是在beta 坐标系下Tai的位姿 ！！！(Taibj*Tbj) = Tba *Tai 
                     //gScm 表示从当前帧到候选关键帧的变换
                     //gSmw 是描述从世界坐标系转换到关键帧坐标系的位姿，即表示候选关键帧在世界坐标系下的位姿                     
                    mg2oScw = gScm*gSmw;     
                    //将最终的Sim3变换转换为OpenCV矩阵格式，用于后续处理。
                    mScw = Converter::toCvMat(mg2oScw);

                    mvpCurrentMatchedPoints = vpMapPointMatches;
                    break;
                }
            }
        }
    }

    //这段代码是处理未找到有效相似变换（Sim3）的情况
    //检查变量 bMatch 是否为 false，表示在之前的迭代过程中没有成功找到符合要求的Sim3变换。
    if(!bMatch)
    {
        //循环删除候选关键帧：遍历所有候选关键帧的集合。
        for(int i=0; i<nInitialCandidates; i++)
              //对每一个候选关键帧调用 SetErase() 方法，这个方法通常标记关键帧为应该从进一步处理中排除或删除。
             mvpEnoughConsistentCandidates[i]->SetErase();
        //删除当前关键帧：将当前处理的关键帧也标记为删除。这表明当前关键帧在尝试找到与之匹配的候选关键帧时未能成功，
        //可能是由于它本身的数据不足以支持稳定的环境理解或位置估计。
        mpCurrentKF->SetErase();
        //cout << "!!!FENG YU XUAN !!! 222" << endl;   
        return false;   //函数返回 false，表示当前的闭环检测或关键帧匹配过程失败，没有足够的证据支持存在一个闭环或有效的Sim3变换。
    }


    // Retrieve MapPoints seen in Loop Keyframe and neighbours
    //检索与闭环相关的关键帧,  从匹配到的闭环关键帧 mpMatchedKF 获取其可视共现的关键帧列表。
    //这些关键帧视觉上与闭环关键帧有高度重合，很可能观察到许多相同的地图点。   
    vector<kfptr> vpLoopConnectedKFs = mpMatchedKF->GetVectorCovisibleKeyFrames();
     //将闭环关键帧自身也加入到列表中，确保其包含的地图点也被考虑在内。
    vpLoopConnectedKFs.push_back(mpMatchedKF);
     //初始化地图点容器, 清空用于存储闭环过程中所有相关地图点的容器，为新一轮的数据收集做准备。
    mvpLoopMapPoints.clear();

    //遍历关键帧和地图点, 使用迭代器遍历闭环关键帧及其相邻关键帧的集合。
    for(vector<kfptr>::iterator vit=vpLoopConnectedKFs.begin(); vit!=vpLoopConnectedKFs.end(); vit++)
    {
         //通过迭代器获取当前遍历到的关键帧指针
        kfptr pKF = *vit;
        //获取当前关键帧中所有匹配到的地图点。
        vector<mpptr> vpMapPoints = pKF->GetMapPointMatches();

        //筛选和标记地图点
        for(size_t i=0, iend=vpMapPoints.size(); i<iend; i++)
        {
            //遍历当前关键帧中的所有地图点。
            mpptr pMP = vpMapPoints[i];
            //确保地图点指针有效，非空。
            if(pMP)
            {
                //确保地图点不是坏的（有效的地图点）且没有被当前关键帧标记过。这里的标记是用来避免重复处理相同的地图点。
                if(!pMP->isBad() && pMP->mLoopPointForKF_MM!=mpCurrentKF->mId) //ID Tag
                {
                    //将有效的地图点加入到闭环地图点的列表中。
                    mvpLoopMapPoints.push_back(pMP);
                    //标记这个地图点，记录它已被当前关键帧处理过，以避免将来重复处理。
                    pMP->mLoopPointForKF_MM = mpCurrentKF->mId;
                }
            }
        }
    }

    //这段代码是视觉SLAM系统中闭环检测流程的最后部分，
    //主要涉及使用计算出的Sim3变换来寻找更多的地图点匹配，并基于匹配结果决定是否接受闭环。
    // Find more matches projecting with the computed Sim3
    matcher.SearchByProjection(mpCurrentKF, mScw, mvpLoopMapPoints, mvpCurrentMatchedPoints,10);
    //这行代码调用一个匹配器对象的 SearchByProjection 方法，用于在当前关键帧 mpCurrentKF 和其匹配到的闭环关键帧中的地图点之间寻找更多的匹配。
    //mScw 是通过Sim3变换计算得到的，将闭环关键帧的地图点投影到当前关键帧的视野中进行匹配。
    //mvpLoopMapPoints 是闭环关键帧及其邻居关键帧的地图点集合，而 mvpCurrentMatchedPoints 用于存储找到的匹配点。
    //10 是搜索半径，单位是像素，用于在图像中定位匹配点的搜索范围。


    // If enough matches accept Loop
    //计算总匹配数，初始化一个变量用于记录找到的有效匹配点总数。
    int nTotalMatches = 0;
    //遍历当前找到的匹配点。
    for(size_t i=0; i<mvpCurrentMatchedPoints.size(); i++)
    {
        //如果在索引 i 的位置有匹配点（非空），则增加匹配总数。
        if(mvpCurrentMatchedPoints[i])
            nTotalMatches++;
    }

     //检查总匹配数是否达到了预设的阈值 params::opt::mTotalMatchesThres。
     //这个阈值是系统设置的，用于判断找到的匹配点是否足够支持闭环假设。如果匹配点足够：则执行下面的内容。
    if(nTotalMatches>=params::opt::mTotalMatchesThres)
    {
        //检查总匹配数是否达到了预设的阈值 params::opt::mTotalMatchesThres。
        //这个阈值是系统设置的，用于判断找到的匹配点是否足够支持闭环假设。
        //遍历所有的初始候选关键帧。
        for(int i=0; i<nInitialCandidates; i++)
            //  //如果候选关键帧不是已匹配的闭环关键帧，则将其标记为删除，因为它们不再需要进一步考虑。
            if(mvpEnoughConsistentCandidates[i]!=mpMatchedKF)          
                mvpEnoughConsistentCandidates[i]->SetErase();
            //
        return true;  //返回 true 表示闭环检测成功，系统应该接受这个闭环。
    }
    else
    {
        //如果匹配不足，拒绝闭环
        //如果未达到匹配阈值,  同样遍历所有候选关键帧。
        for(int i=0; i<nInitialCandidates; i++)
            mvpEnoughConsistentCandidates[i]->SetErase();   //将所有候选关键帧标记为删除。
        mpCurrentKF->SetErase();  //将当前关键帧也标记为删除，因为它未能成功找到足够的匹配支持闭环。
   
        return false;   //返回 false 表示闭环检测失败。
    }
}


//多客户端环境中, 识别并纠正地图匹配时发现的环路闭合，
void MapMatcher::CorrectLoop()
{    
    //输出环路匹配信息：首先通过打印信息提示已找到地图匹配。
    // 两端客户端与关键帧信息
        const size_t client_curr  = mpCurrentKF->mId.second;   // 当前KF所属客户端
        const size_t client_match = mpMatchedKF->mId.second;   // 匹配KF所属客户端
        const size_t kf_curr_id   = mpCurrentKF->mId.first;    // 当前KF编号（若 mId.first 为KF id）
        const size_t kf_match_id  = mpMatchedKF->mId.first;    // 匹配KF编号

        std::ostringstream oss;
        oss << "\033[1;32m!!! MAP MATCH FOUND !!!\033[0m "
            << "[client " << client_curr << " ↔ client " << client_match << "] "
            << "(KF " << kf_curr_id << " ↔ KF " << kf_match_id << ")";
        std::cout << oss.str() << std::endl;

    //获取关联客户端信息：从当前关键帧和匹配到的关键帧中获取各自地图的关联客户端集合。
    set<size_t> suAssCLientsCurr = mpCurrentKF->GetMapptr()->msuAssClients;
    set<size_t> suAssCLientsMatch = mpMatchedKF->GetMapptr()->msuAssClients;

//检查并更新匹配矩阵：遍历两个客户端集合，更新它们之间的匹配计数，若存在相同客户端则输出错误信息。
    for(set<size_t>::iterator sit = suAssCLientsCurr.begin();sit!=suAssCLientsCurr.end();++sit)
    {
        size_t idc = *sit;
        for(set<size_t>::iterator sit2 = suAssCLientsMatch.begin();sit2!=suAssCLientsMatch.end();++sit2)
        {
            size_t idm = *sit2;

            if(idc == idm) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMatcher::CorrectLoop()\": Associated Clients of matched and current map intersect" << endl;

            mMatchMatrix.at<uint16_t>(idc,idm) = mMatchMatrix.at<uint16_t>(idc,idm) + 1;
            mMatchMatrix.at<uint16_t>(idm,idc) = mMatchMatrix.at<uint16_t>(idm,idc)  + 1;
        }
    }

//错误检查：检查是否有错误的环路闭合情况，例如两个匹配的关键帧属于同一客户端，或者关键帧不属于其所在地图。
    if(mpCurrentKF->mId.second == mpMatchedKF->mId.second) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMatcher::CorrectLoop()\": Matched KFs belong to same client" << endl;
    if(!mpCurrMap->msuAssClients.count(mpCurrentKF->mId.second)) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMatcher::CorrectLoop()\": Current KFs does not belong to current map" << endl;
    if(mpCurrMap->msuAssClients.count(mpMatchedKF->mId.second)) cout << "\033[1;31m!!! ERROR !!!\033[0m In \"MapMatcher::CorrectLoop()\": Matched KFs belongs to current map" << endl;

//发布环路边：如果启用了可视化，发布环路边信息。
    if(params::vis::mbActive)
        PublishLoopEdges();

//获取匹配关键帧的地图：从已匹配的关键帧 (mpMatchedKF) 获取其所属的地图 (pMatchedMap)。
    mapptr pMatchedMap = mpMatchedKF->GetMapptr();

//创建环路匹配记录：创建一个 MapMatchHit 对象，它包含当前关键帧 (mpCurrentKF)、匹配的关键帧 (mpMatchedKF)、两帧之间的Sim3变换 (mg2oScw) 以及相关的地图点匹配信息。
 //   MapMatchHit MMH(mpCurrentKF,mpMatchedKF,mg2oScw,mvpLoopMapPoints,mvpCurrentMatchedPoints);
 // 修改处!!!!!!!!!!!!!!:
        Eigen::MatrixXd Sigma6, Omega6;
        if (!ComputeSim3Uncertainty(Sigma6, &Omega6)) 
        {
            // 兜底：给个温和的信息，避免数值崩
            Omega6 = 1e-4 * Eigen::Matrix<double,6,6>::Identity();
            Sigma6 = 1e4  * Eigen::Matrix<double,6,6>::Identity();
        }

        // 创建环路匹配记录（把 Omega6 带进去）
         MapMatchHit MMH(mpCurrentKF, mpMatchedKF, mg2oScw,
                mvpLoopMapPoints, mvpCurrentMatchedPoints,
                Omega6.cast<double>()); // ★ 传入 6×6 信息矩阵


    //存储匹配信息：在匹配字典 mFoundMatches 中双向存储环路匹配，以便从任一地图到另一地图都能找到对应的匹配信息    
    //注意这里的mpCurrMap 和 pMatchedMap 仅代表当前帧和匹配帧，至于当前帧到底属于哪个机器人的，并不知晓！！！
    mFoundMatches[mpCurrMap][pMatchedMap].push_back(MMH);
    mFoundMatches[pMatchedMap][mpCurrMap].push_back(MMH);

//检查是否足够匹配并尝试合并地图：检查当前地图 (mpCurrMap) 与匹配地图 (pMatchedMap) 之间是否存在至少一个匹配，
//如果是，尝试使用 MapMerger 的 MergeMaps 方法合并这两个地图。合并过程中会利用所有找到的匹配来优化融合结果。
    if(mFoundMatches[mpCurrMap][pMatchedMap].size() >= 15)      
    {

        vector<MapMatchHit> vMatches = mFoundMatches[mpCurrMap][pMatchedMap];
     
     // 该函数来自于MapMerger.cpp文件中
     //输入是当前地图、匹配地图、向量，输出是融合的地图
        mapptr pMergedMap = mpMapMerger->MergeMaps(mpCurrMap,pMatchedMap,vMatches);
    }

    this->ClearLoopEdges();   //清除环路边; 清除所有暂存的环路边缘信息，这是维护环路检测状态的一部分，以确保下一次环路检测时环境是干净的。
}


// 在SLAM系统中发布环路边信息，以可视化当前关键帧和匹配关键帧之间的关系。
// PublishLoopEdges() 函数通过发布环路边来可视化地图中的关键帧位置和它们之间的连接。
// 这有助于理解和验证SLAM系统中环路闭合的正确性，是调试和监控SLAM系统的重要工具。
void MapMatcher::PublishLoopEdges()
{
     //清空环路边消息的点集：清空了之前存储在 mMapMatchEdgeMsg 消息中的所有点，准备重新填充新的环路边信息。
    mMapMatchEdgeMsg.points.clear();   

     // 定义变量
    tf::StampedTransform Tf_W_Curr,Tf_W_Matched;
    string FrameIdCurr,FrameIdMatched;

    //从关键帧获取odom帧ID：从当前关键帧和匹配关键帧的地图对象中获取odom参考帧的ID。这些帧ID将用于后续的变换查找。
    FrameIdCurr = mpCurrentKF->GetMapptr()->mOdomFrame;
    FrameIdMatched = mpMatchedKF->GetMapptr()->mOdomFrame;

     //从TF监听器中获取变换：使用TF监听器从世界坐标系到当前关键帧和匹配关键帧的参考帧坐标系的变换。它们尝试获取最新的可用变换。
    try
    {
        mTfListen.lookupTransform("world",FrameIdCurr, ros::Time(0), Tf_W_Curr);
        mTfListen.lookupTransform("world",FrameIdMatched, ros::Time(0), Tf_W_Matched);
    }
    //处理变换查找异常, 如果在查找变换时发生错误，如变换不可用，将捕获异常并打印错误消息。
    catch (tf::TransformException ex)
    {
        ROS_ERROR("%s",ex.what());
        return;
    }

    cv::Mat TCurr = mpCurrentKF->GetPoseInverse();
    cv::Mat TMatch = mpMatchedKF->GetPoseInverse();

//获取关键帧的世界坐标：这两行代码计算当前关键帧和匹配关键帧的位置，应用了缩放因子，并将位置转换为tf::Point类型。
    tf::Point PTfCurr{params::vis::mfScaleFactor*((double)(TCurr.at<float>(0,3))),params::vis::mfScaleFactor*((double)(TCurr.at<float>(1,3))),params::vis::mfScaleFactor*((double)(TCurr.at<float>(2,3)))};
    tf::Point PTfMatch{params::vis::mfScaleFactor*((double)(TMatch.at<float>(0,3))),params::vis::mfScaleFactor*((double)(TMatch.at<float>(1,3))),params::vis::mfScaleFactor*((double)(TMatch.at<float>(2,3)))};


//将关键帧位置转换到世界坐标系。这两行代码使用之前获取的变换将关键帧的位置转换到世界坐标系中。
    PTfCurr = Tf_W_Curr*PTfCurr;
    PTfMatch = Tf_W_Matched*PTfMatch;

    geometry_msgs::Point PCurr;
    geometry_msgs::Point PMatch;

//转换tf点到ROS消息点并发布：这些代码将tf点转换为ROS的geometry_msgs::Point消息，将它们添加到环路边消息中，并通过ROS发布器发布这个消息。
    tf::pointTFToMsg(PTfCurr,PCurr);
    tf::pointTFToMsg(PTfMatch,PMatch);

    mMapMatchEdgeMsg.points.push_back(PCurr);
    mMapMatchEdgeMsg.points.push_back(PMatch);

    mPubMarker.publish(mMapMatchEdgeMsg);
}


//这段代码是在视觉SLAM系统中用于处理地图匹配时的边界（或连接）信息的清除。
//该函数执行的是与ROS（中的可视化工具（如RViz）的交互，主要目的是清除或更新地图上显示的边界或标记。
void MapMatcher::ClearLoopEdges()
{
// 设置消息行为
 //将地图匹配边缘消息的 action 属性设置为 3。在ROS中，visualization_msgs::Marker 消息类型中，action 字段用于指定发布的标记应该执行的动作。
 //数字 3 通常代表 DELETEALL，即删除所有此前发布的标记。这是为了确保之前的所有边界或连接信息都被清除，以便开始新的匹配或显示新的数据。   
    mMapMatchEdgeMsg.action = 3;
 //发布消息
//在ROS中定义的发布者 mPubMarker 发布修改后的消息 mMapMatchEdgeMsg。
//这个发布操作实际上是将命令发送到ROS的消息传递系统中，通常目标是RViz或其他监听这些消息的可视化工具。
//通过这个步骤，已经设置好的消息（这里是删除所有标记的命令）会被实际执行，从而在可视化界面上清除所有相关的边界表示。
    mPubMarker.publish(mMapMatchEdgeMsg);

//重置消息动作, 在消息发布后，代码将 mMapMatchEdgeMsg 的 action 属性重置为 ADD。
//在 visualization_msgs::Marker 中，ADD（值为 0）是用来添加或修改标记的标准动作。
//这步操作是为了准备下一次需要添加或更新标记时，消息已经设置为正确的动作状态。
    mMapMatchEdgeMsg.action = visualization_msgs::Marker::ADD;
}


//这段代码属于视觉SLAM系统中的 MapMatcher 类，用于将关键帧（KeyFrame）加入到一个队列中。
void MapMatcher::InsertKF(kfptr pKF)
{
    //线程安全, 这行代码使用了 unique_lock 来锁定一个互斥量（mutex）。mMutexKfInQueue 是用于保护关键帧队列（mlKfInQueue）的互斥量。
    //通过锁定互斥量，该代码段保证了在多线程环境下对关键帧队列的修改是线程安全的。
    //unique_lock 提供了一个方便的RAII封装，确保在锁被创建时自动获取互斥量，并在锁的作用域结束时自动释放。
    unique_lock<mutex> lock(mMutexKfInQueue);

//添加关键帧到队列, 将传入的关键帧指针（pKF）添加到队列 mlKfInQueue 的末尾。
//此队列很可能用于存储待处理的关键帧，这些关键帧随后会被系统进一步分析和处理，如进行地图匹配和闭环检测等操作。
    mlKfInQueue.push_back(pKF);
}


//这段代码是视觉SLAM系统中的 MapMatcher 类的一部分，功能是从关键帧队列中删除指定的关键帧。
void MapMatcher::EraseKFs(vector<kfptr> vpKFs)
{
    //线程安全，这行代码使用 unique_lock 来锁定一个互斥量（mutex），确保对关键帧队列 mlKfInQueue 的修改操作是线程安全的。
    //锁定操作保证在这个函数执行期间，其他可能并行运行的线程不能同时修改队列，从而避免数据竞争和不一致的问题。
    unique_lock<mutex> lock(mMutexKfInQueue);

   //遍历和删除操作，这是一个循环，遍历所有需要删除的关键帧列表 vpKFs。每个元素都是一个指向关键帧的指针（kfptr）
   //这是一个循环，遍历所有需要删除的关键帧列表 vpKFs。每个元素都是一个指向关键帧的指针（kfptr）
    for(vector<kfptr>::iterator vit=vpKFs.begin();vit!=vpKFs.end();++vit)
    {
         //在每次循环中，通过解引用迭代器 vit 来获取当前需要处理的关键帧指针 pKF
        kfptr pKF = *vit;
         //使用 std::find 函数在关键帧队列 mlKfInQueue 中查找当前迭代的关键帧 pKF。
         //如果找到，find 函数将返回一个指向该关键帧的迭代器 lit；如果未找到，将返回 mlKfInQueue.end()。
        std::list<kfptr>::iterator lit = find(mlKfInQueue.begin(),mlKfInQueue.end(),pKF);

        //这个条件判断检查是否成功找到关键帧。
        //如果 lit 不等于 mlKfInQueue.end()，说明找到了相应的关键帧，然后使用 erase 方法将其从队列中删除。
        if(lit!=mlKfInQueue.end()) mlKfInQueue.erase(lit);
    }

}


//这段代码是视觉SLAM系统中 MapMatcher 类的一个方法，目的是获取队列中关键帧的数量。
int MapMatcher::GetNumKFsinQueue()
{
    //创建锁并尝试获取, 创建一个 unique_lock 对象 lock，并与互斥量 mMutexKfInQueue 关联。
    //此处使用了 defer_lock，意味着在 unique_lock 对象创建时不会立即锁定互斥量。
    unique_lock<mutex> lock(mMutexKfInQueue,defer_lock);

    //尝试锁定, 使用 try_lock 方法尝试锁定互斥量。与 lock() 方法不同，try_lock 不会阻塞调用线程；
    //如果互斥量当前被其他线程持有，try_lock 会立即返回 false，否则它会锁定互斥量并返回 true。
    if(lock.try_lock())
    {
        //获取队列长度, 如果成功获取锁（即互斥量未被其他线程持有），则返回队列 mlKfInQueue 中的元素数量。
        //这是线程安全的操作，因为在此操作执行时，该线程持有互斥锁。
        return mlKfInQueue.size();
    }
    else    //锁未获取时的返回
        return -1;    //如果 try_lock 未能成功锁定互斥量（即互斥量被另一个线程锁定），则函数返回 -1。
        //这可以被视为一个错误代码或一个信号，表明无法访问队列长度，因为队列正被其他线程修改。
}


//检查一个名为 mlKfInQueue 的队列是否为空
//MapMatcher 类的一个成员函数，返回类型是布尔值（bool），函数名为 CheckKfQueue，表明该函数用于检查某种“队列”
bool MapMatcher::CheckKfQueue()
{
    unique_lock<mutex> lock(mMutexKfInQueue);  //锁定了名为 mMutexKfInQueue 的互斥锁

    return (!mlKfInQueue.empty()); //检查名为 mlKfInQueue 的队列是否为空。
    //!mlKfInQueue.empty() 则是对 empty() 函数返回值的逻辑非操作。    
    //如果队列不为空，表达式结果为 true，函数返回 true；如果队列为空，结果为 false，函数返回 false。

    //这个函数的主要目的是用于多线程环境下，安全地检查一个关键数据结构（这里是队列 mlKfInQueue）是否包含元素，
    //常用于决定后续操作（如处理队列中的元素）。通过使用互斥锁确保了在并发访问时数据的一致性和安全性
}

}
