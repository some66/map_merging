/**
* This file is part of CCM-SLAM.
*
* Copyright (C): Patrik Schmuck <pschmuck at ethz dot ch> (ETH Zurich)
* For more information see <https://github.com/patriksc/CCM-SLAM>
*
* CCM-SLAM is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* CCM-SLAM is based in the monocular version of ORB-SLAM2 by Raúl Mur-Artal.
* CCM-SLAM partially re-uses modules of ORB-SLAM2 in modified or unmodified condition.
* For more information see <https://github.com/raulmur/ORB_SLAM2>.
*
* CCM-SLAM is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CCM-SLAM. If not, see <http://www.gnu.org/licenses/>.
*/

#include <cslam/ClientHandler.h>

namespace cslam {

//ros::NodeHandle Nh, ros::NodeHandle NhPrivate：这两个参数是 ROS 的节点句柄，通常用于管理 ROS 节点的通信。
//vocptr pVoc, dbptr pDB, mapptr pMap：这些智能指针分别指向词典、数据库和地图的对象，用于地图匹配和定位。
//size_t ClientId, uidptr pUID：客户端的唯一标识和用户标识。
//eSystemState SysState：系统的状态，可能是客户端或服务器。
//const string &strCamFile：相机配置文件的路径。
//viewptr pViewer：用于视觉显示的对象。
//bool bLoadMap：标志位，表示是否加载地图。
//初始化列表：
//成员变量如 mpVoc、mpKFDB 等被初始化为传入的参数值。
//特别地，mbReset 被显式设置为 false，表示没有重置请求。
//mbLoadedMap 根据 bLoadMap 参数设置。
ClientHandler::ClientHandler(ros::NodeHandle Nh, ros::NodeHandle NhPrivate, vocptr pVoc, dbptr pDB, mapptr pMap, size_t ClientId, uidptr pUID, eSystemState SysState, const string &strCamFile, viewptr pViewer, bool bLoadMap)
    : mpVoc(pVoc),mpKFDB(pDB),mpMap(pMap),
      mNh(Nh),mNhPrivate(NhPrivate),
      mClientId(ClientId), mpUID(pUID), mSysState(SysState),
      mstrCamFile(strCamFile),
      mpViewer(pViewer),mbReset(false),
      mbLoadedMap(bLoadMap)
{

//异常处理：在构造函数体的开始，通过一系列的判断确保关键的指针参数不为空。
//如果任何一个关键的指针为空（或者在服务器模式下用户标识为空），则输出错误信息并抛出异常
    if(mpVoc == nullptr || mpKFDB == nullptr || mpMap == nullptr || (mpUID == nullptr && mSysState == eSystemState::SERVER))
    {
        cout << ("In \" ClientHandler::ClientHandler(...)\": nullptr exception") << endl;
        throw estd::infrastructure_ex();
    }

//插入客户端ID： 将当前的客户端ID插入到地图的关联客户端集合中，用于后续处理。
    mpMap->msuAssClients.insert(mClientId);

//初始化为单位变换（恒等变换），这用于处理客户端地图与当前地图之间的坐标转换。
    mg2oS_wcurmap_wclientmap = g2o::Sim3(); //identity transformation

//如果系统状态为客户端 (eSystemState::CLIENT)，则从私有节点句柄读取相机订阅的主题名称，并订阅该主题。mSubCam 是用于接收来自该主题的图像消息的订阅者。
//boost::bind(&ClientHandler::CamImgCb,this,_1) 将图像回调函数与订阅者绑定，以处理接收到的图像数据。
    if(mSysState == eSystemState::CLIENT)
    {
        std::string TopicNameCamSub;

        mNhPrivate.param("TopicNameCamSub",TopicNameCamSub,string("nospec"));
        mSubCam = mNh.subscribe<sensor_msgs::Image>(TopicNameCamSub,10,boost::bind(&ClientHandler::CamImgCb,this,_1));

        cout << "Camera Input topic: " << TopicNameCamSub << endl;
    }    

}



//预处理器指令和函数签名
//#ifdef LOGGING 检查是否定义了 LOGGING 宏。如果定义了，编译器将包括和编译 LOGGING 相关的代码部分。
//如果定义了 LOGGING，函数 ClientHandler::InitializeThreads 接受一个指向日志记录器对象的智能指针（boost::shared_ptr<estd::mylog> pLogger）。
//如果没有定义 LOGGING，则 ClientHandler::InitializeThreads 函数不接受任何参数。

#ifdef LOGGING
void ClientHandler::InitializeThreads(boost::shared_ptr<estd::mylog> pLogger)
#else
void ClientHandler::InitializeThreads()
#endif
{
    //在函数体内，#ifdef LOGGING 同样用于检查 LOGGING 是否被定义。如果是，调用 InitializeCC 方法时会传递 pLogger 参数。
     //如果 LOGGING 未定义，调用 InitializeCC 时不带参数。
    #ifdef LOGGING
    this->InitializeCC(pLogger);
    #else
    //函数在本文件下方
    this->InitializeCC();
    #endif

//函数根据 mSysState 成员变量的值，决定是初始化客户端还是服务器。
//如果 mSysState 是 eSystemState::CLIENT，则调用 this->InitializeClient() 来初始化客户端。
//如果 mSysState 是 eSystemState::SERVER，则调用 this->InitializeServer(mbLoadedMap) 来初始化服务器，并传递 mbLoadedMap 参数。
    if(mSysState == eSystemState::CLIENT)
    {
        //函数在本文件下方
        this->InitializeClient();
    }
    else if(mSysState == eSystemState::SERVER)
    {
        //函数在本文件下方
        this->InitializeServer(mbLoadedMap);
    }
    else
    {
        // ANSI 转义序列 "\033[1;31m" 和 "\033[0m" 来改变终端中文本的颜色, 分别用于设置红色和重置颜色。
        cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m ClientHandler::InitializeThreads(): invalid systems state: " << mpCC->mSysState << endl;
        throw infrastructure_ex();
    }

}


//初始化中央控制单元（CentralControl），并根据不同的系统状态（客户端或服务器）进行相应的配置。
#ifdef LOGGING
void ClientHandler::InitializeCC(boost::shared_ptr<mylog> pLogger)
#else
void ClientHandler::InitializeCC()
#endif
{
    std::stringstream* ss;

//初始化 CentralControl 对象
//mpCC.reset(new CentralControl(mNh, mNhPrivate, mClientId, mSysState, shared_from_this(), mpUID));
//使用 reset 方法重置 mpCC 指针，指向新创建的 CentralControl 对象。
//构造函数的参数包括 ROS 节点句柄、客户端 ID、系统状态等，这些参数提供了必要的上下文信息给中央控制单元。
    mpCC.reset(new CentralControl(mNh,mNhPrivate,mClientId,mSysState,shared_from_this(),mpUID));

    if(mSysState == eSystemState::CLIENT)
    {
        //使用 std::stringstream 构建特定的参数名，用于从 ROS 的参数服务器中获取配置信息。
        //根据系统状态（客户端或服务器）使用不同的参数名格式：
       // 客户端：参数名格式为 "FrameId"。
         //服务器：参数名格式为 "FrameId" + mClientId，以区分不同客户端
        ss = new stringstream;
        *ss << "FrameId";

       // 这行代码尝试从参数服务器获取名为 ss->str() 的参数，如果不存在则使用默认值 "nospec"
        mNhPrivate.param(ss->str(),mpCC->mNativeOdomFrame,std::string("nospec"));
    }
    else if(mSysState == eSystemState::SERVER)
    {
        ss = new stringstream;
        *ss << "FrameId" << mClientId;

        mNhPrivate.param(ss->str(),mpCC->mNativeOdomFrame,std::string("nospec"));
    }
    else
    {
        cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m ClientHandler::InitializeThreads(): invalid systems state: " << mpCC->mSysState << endl;
        throw infrastructure_ex();
    }

//检查 mNativeOdomFrame 是否被正确设置。
//如果设置为默认值 "nospec"，表明没有从参数服务器中成功获取值，随后输出错误信息并抛出异常
    if(mpCC->mNativeOdomFrame=="nospec")
    {
        ROS_ERROR_STREAM("In \" ServerCommunicator::ServerCommunicator(...)\": bad parameters");
        throw estd::infrastructure_ex();
    }

//特定于客户端的额外配置
    {
//如果系统状态为客户端，则从相机配置文件（mstrCamFile）中读取变换矩阵（相机到传感器的变换矩阵）并设置到 mpCC 对象中。
//使用 OpenCV 的 cv::FileStorage 类从文件中读取变换矩阵的各个元素，这些元素被设置到一个 Eigen 类型的矩阵 mT_SC 中。
        if(mSysState==CLIENT)
        {
            cv::FileStorage fSettings(mstrCamFile, cv::FileStorage::READ);

            float c0t00 = fSettings["Cam0.T00"];
            float c0t01 = fSettings["Cam0.T01"];
            float c0t02 = fSettings["Cam0.T02"];
            float c0t03 = fSettings["Cam0.T03"];
            float c0t10 = fSettings["Cam0.T10"];
            float c0t11 = fSettings["Cam0.T11"];
            float c0t12 = fSettings["Cam0.T12"];
            float c0t13 = fSettings["Cam0.T13"];
            float c0t20 = fSettings["Cam0.T20"];
            float c0t21 = fSettings["Cam0.T21"];
            float c0t22 = fSettings["Cam0.T22"];
            float c0t23 = fSettings["Cam0.T23"];
            float c0t30 = fSettings["Cam0.T30"];
            float c0t31 = fSettings["Cam0.T31"];
            float c0t32 = fSettings["Cam0.T32"];
            float c0t33 = fSettings["Cam0.T33"];
            mpCC->mT_SC << c0t00,c0t01,c0t02,c0t03,c0t10,c0t11,c0t12,c0t13,c0t20,c0t21,c0t22,c0t23,c0t30,c0t31,c0t32,c0t33;
        }
        else
        {
            //no mstrCamFile on Server...
        }
    }
    //其他配置和清理
   //将 mpCC 中的 mNativeOdomFrame 更新到地图对象 mpMap 中。
   //将 mpCC 对象的指针添加到地图对象的相关集合中，可能用于后续的地图和位置更新操作。
   //如果启用了日志记录，则将日志对象 pLogger 分配给 mpCC 的 mpLogger 成员。
    mpMap->mOdomFrame = mpCC->mNativeOdomFrame;
    mpMap->AddCCPtr(mpCC);

    #ifdef LOGGING
    mpCC->mpLogger = pLogger;
    #endif

//内存清理,  使用 delete ss; 删除动态分配的 stringstream 对象，避免内存泄漏。
    delete ss;
}


//负责初始化客户端的各种子系统和线程，包括视图渲染、本地地图构建、通信和跟踪线程。
//这个方法通过构造多个对象和启动相应的处理线程，以确保客户端可以正确处理图像数据、进行地图更新和与服务器通信。
void ClientHandler::InitializeClient()
{
   // 这行代码输出客户端的初始化信息，包括客户端ID，有助于调试和监控初始化过程。
    cout << "Client " << mClientId << " --> Initialize Threads" << endl;

    //+++++ Create Drawers. These are used by the Viewer +++++
    //初始化视图渲染器 Viewer, 创建一个新的 Viewer 对象，并用智能指针 mpViewer 管理它。Viewer 负责渲染和显示地图信息。
    mpViewer.reset(new Viewer(mpMap,mpCC));
    usleep(10000);

    //+++++ Initialize the Local Mapping thread +++++
    // 初始化本地映射 LocalMapping, 创建一个本地映射线程对象，该对象用于处理关键帧和地图点的创建和优化。
    //函数在Mapping.cpp文件中
    mpMapping.reset(new LocalMapping(mpCC,mpMap,mpKFDB,mpViewer));
    usleep(10000);

//    +++++ Initialize the communication thread +++++
    //初始化通信线程 Communicator, 创建一个通信线程对象，负责处理客户端与服务器之间的数据交换。
    //函数在Communicator.cpp文件中
    mpComm.reset(new Communicator(mpCC,mpVoc,mpMap,mpKFDB));
    //设置本地映射线程，允许通信线程与本地映射线程交互。
    //函数在Communicator.cpp文件中
    mpComm->SetMapping(mpMapping);
    usleep(10000);
    //将通信器设置到地图对象中，使地图可以直接与通信器交互。
    //函数在Map.cpp文件中
    mpMap->SetCommunicator(mpComm);
    //让本地映射线程也可以直接与通信器交互。
      //函数在Mapping.cpp文件中
    mpMapping->SetCommunicator(mpComm);
    usleep(10000);

    //+++++ Initialize the tracking thread +++++
    //(it will live in the main thread of execution, the one that called this constructor)
    //初始化跟踪线程 Tracking,  创建跟踪线程对象，该线程负责从连续的图像帧中提取特征，并将它们与地图点匹配以估计相机的位姿。
    //函数在Tracking.cpp文件中
    mpTracking.reset(new Tracking(mpCC, mpVoc, mpViewer, mpMap, mpKFDB, mstrCamFile, mClientId));
    usleep(10000);
    //设置通信器，允许跟踪线程与通信器交互。
     //函数在Tracking.cpp文件中
    mpTracking->SetCommunicator(mpComm);
    //设置本地映射器，使跟踪线程可以访问本地映射线程的功能。
     //函数在Tracking.cpp文件中
    mpTracking->SetLocalMapper(mpMapping);
    //将跟踪器设置到视图渲染器中，使渲染的视图可以展示当前的跟踪状态。
     //函数在Viewer.cpp文件中
    mpViewer->SetTracker(mpTracking);
    usleep(10000);

    //Launch Threads
    //Should no do that before, a fast system might already use a pointe before it was set -> segfault
    //启动线程,  使用 std::thread 启动各个线程：这些线程分别用于本地映射、通信和视图渲染的并行处理。
    //  函数来自于Mapping.cpp
    mptMapping.reset(new thread(&LocalMapping::RunClient,mpMapping));
    //  函数来自于Communicator.cpp
    mptComm.reset(new thread(&Communicator::RunClient,mpComm));
    //  函数来自于viewer.cpp
    mptViewer.reset(new thread(&Viewer::RunClient,mpViewer));
    usleep(10000);

}


//负责初始化服务器端的核心功能和线程。这个方法配置了服务器端处理循环闭合、本地映射和通信等功能，并通过多线程方式提高处理效率。
void ClientHandler::InitializeServer(bool bLoadMap)
{
    cout << "Client " << mClientId << " --> Initialize Threads" << endl;

    //+++++ Initialize the Loop Finder thread and launch +++++
    //初始化循环查找器 LoopFinder, 创建循环查找器对象，负责检测和处理地图中的循环闭合，这对于修正漂移和增强地图精度非常关键。
    // 函数来自于LoopFinder.cpp
    mpLoopFinder.reset(new LoopFinder(mpCC,mpKFDB,mpVoc,mpMap));
        //在新线程中启动循环查找器的 Run 方法，使其并行处理循环闭合任务.
        // 函数来自于LoopFinder.cpp
    mptLoopClosure.reset(new thread(&LoopFinder::Run,mpLoopFinder));
    usleep(10000);

    //+++++ Initialize the Local Mapping thread +++++
    //初始化本地映射 LocalMapping, 创建一个本地映射线程对象，该对象用于管理和优化地图中的关键帧和地图点。
    // 函数来自于Mapping.cpp
    mpMapping.reset(new LocalMapping(mpCC,mpMap,mpKFDB,mpViewer));
    //设置循环查找器，使本地映射线程可以与循环查找器协同工作，整合循环闭合信息。
    // 函数来自于Mapping.cpp
    mpMapping->SetLoopFinder(mpLoopFinder); //tempout
    usleep(10000);

    //+++++ Initialize the communication thread +++++
    //初始化通信线程 Communicator,  创建通信线程对象，负责处理服务器与客户端之间的数据交换，bLoadMap 参数指定是否加载现有地图。
    // 函数来自于Communicator.cpp
    mpComm.reset(new Communicator(mpCC,mpVoc,mpMap,mpKFDB,bLoadMap));

    //设置本地映射线程，使通信线程能够直接与本地映射线程交互。
    //允许本地映射线程与通信线程交互。
    //在地图对象中设置通信器，使地图可以直接与通信器交互。
     // 函数来自于Communicator.cpp
    mpComm->SetMapping(mpMapping);
    usleep(10000);
     // 函数来自于Mapping.cpp
    mpMapping->SetCommunicator(mpComm);
     // 函数来自于Map.cpp
    mpMap->SetCommunicator(mpComm);
    usleep(10000);

    //Launch Threads
    //Should not do that before, a fast system might already use a pointer before it was set -> segfault
    //启动线程,  这些线程分别用于本地映射和通信的并行处理，提高服务器的处理效率。
    //注意这里并没有viewer的线程，也就是可视化是在客户端线程中进行的，而非server端。
    //函数来自于Mapping.cpp文件中
    mptMapping.reset(new thread(&LocalMapping::RunServer,mpMapping));
     //函数来自于Communicator.cpp文件中
    mptComm.reset(new thread(&Communicator::RunServer,mpComm));
    usleep(10000);

     //这是一个重要的安全检查，确保所有关键组件都已正确配置，防止在运行过程中访问空指针导致段错误。
    //错误检查和异常处理,    如果在中央控制单元 (mpCC) 中没有正确设置客户端处理器 (mpCH) 的指针，输出错误信息并抛出异常。
    if(mpCC->mpCH == nullptr)
    {
        ROS_ERROR_STREAM("ClientHandler::InitializeThreads()\": mpCC->mpCH is nullptr");
        throw estd::infrastructure_ex();
    }
}


//用于在客户端处理器中更换当前的地图，并更新相关的变换矩阵和组件配置。
//该方法涉及地图对象的更换、变换矩阵的更新、锁的检查，以及通知各个相关组件（如通信、映射和循环查找器）地图已更换。
void ClientHandler::ChangeMap(mapptr pMap, g2o::Sim3 g2oS_wnewmap_wcurmap)
{
         // #####################修改处！！！，显示转化的相对坐标系//
        Eigen::Matrix3d rotation = g2oS_wnewmap_wcurmap.rotation().toRotationMatrix();
        Eigen::Vector3d translation = g2oS_wnewmap_wcurmap.translation();
         double scale = g2oS_wnewmap_wcurmap.scale();
         
        // 打印旋转矩阵,  会打印出两次！！！
        std::cout << "LOCAL TO  GLOBAL Rotation Matrix:" << std::endl;
        std::cout << rotation << std::endl;
        // 打印平移向量
        std::cout << "LOCAL TO  GLOBAL Translation Vector:" << std::endl;
        std::cout << translation.transpose() << std::endl;
        // 打印缩放因子
        std::cout << "LOCAL TO  GLOBAL Scale:" << std::endl;
        std::cout << scale << std::endl;
        //#####################//

    //更新地图和变换矩阵,   将成员变量 mpMap 更新为新传入的地图指针 pMap。
    mpMap = pMap;

    //更新当前客户端地图到世界地图的变换矩阵，通过将新地图到当前地图的变换矩阵 
    //左乘 g2oS_wnewmap_wcurmap， 与原变换矩阵相乘。
    //(Taibj*Tbj) = Tba *Tai  , 是以beta为原坐标系
    mg2oS_wcurmap_wclientmap = g2oS_wnewmap_wcurmap*mg2oS_wcurmap_wclientmap;

    //将中央控制单元 mpCC 中的变换矩阵也更新为新的变换矩阵。
    mpCC->mg2oS_wcurmap_wclientmap = mg2oS_wcurmap_wclientmap;

    //检查和确认组件锁定状态,  尝试锁定通信和映射组件。这通常是为了在更换地图过程中防止其他操作干扰，确保数据一致性。
     // 这些方法应该返回 false，表示相关组件已被正确锁定。
    bool bLockedComm = mpCC->LockComm(); //should be locked and therefore return false
    bool bLockedMapping = mpCC->LockMapping(); //should be locked and therefore return false

   //错误检查,  如果任一组件未能锁定，输出错误信息并抛出异常。
   //这是为了确保在更换地图前所有必要的组件都处于安全状态，防止数据冲突或不一致。
    if(bLockedComm || bLockedMapping)
    {
        if(bLockedComm) cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m ClientHandler::ChangeMap(): Comm not locked: " << endl;
        if(bLockedMapping) cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m ClientHandler::ChangeMap(): Mapping not locked: " << endl;
        throw infrastructure_ex();
    }

    //更新相关组件的地图引用
      // // 函数在loopFinder.cpp文件中, 其他两个文件调用该函数
    mpComm->ChangeMap(mpMap);              //通知通信组件地图已更换，更新其内部地图引用。  
    mpMapping->ChangeMap(mpMap);          //通知本地映射组件地图已更换，更新其内部地图引用。      
    mpLoopFinder->ChangeMap(mpMap);    //通知循环查找器地图已更换，更新其内部地图引用。
}

void ClientHandler::SaveMap(const string &path_name) {
        std::cout << "--> Lock System" << std::endl;
        while(!mpCC->LockMapping()){usleep(params::timings::miLockSleep);}
        while(!mpCC->LockComm()){usleep(params::timings::miLockSleep);}
        while(!mpCC->LockPlaceRec()){usleep(params::timings::miLockSleep);}
        std::cout << "----> done" << std::endl;

        mpMap->SaveMap(path_name);

        std::cout << "--> Unlock System" << std::endl;
        mpCC->UnLockMapping();
        mpCC->UnLockComm();
        mpCC->UnLockPlaceRec();
        std::cout << "----> done" << std::endl;
}


//
void ClientHandler::SetMapMatcher(matchptr pMatch)
{
    mpMapMatcher = pMatch;
    mpComm->SetMapMatcher(mpMapMatcher);
    mpMapping->SetMapMatcher(mpMapMatcher);
}

void ClientHandler::CamImgCb(sensor_msgs::ImageConstPtr pMsg)
{
    // Copy the ros image message to cv::Mat.
    cv_bridge::CvImageConstPtr cv_ptr;

    try
    {
        cv_ptr = cv_bridge::toCvShare(pMsg);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }

    // Check reset
    {
        unique_lock<mutex> lock(mMutexReset);
        if(mbReset)
        {
            mpTracking->Reset();
            mbReset = false;
        }
    }

    mpTracking->GrabImageMonocular(cv_ptr->image,cv_ptr->header.stamp.toSec());
}

void ClientHandler::LoadMap(const std::string &path_name) {

    std::cout << "--> Load Map" << std::endl;
    mpMap->LoadMap(path_name,mpVoc,mpComm,mpKFDB,mpUID);
    std::cout << "----> Done" << std::endl;

    std::cout << "--> Register KFs to database" << std::endl;
    auto kfs = mpMap->GetAllKeyFrames();
    for(auto kf : kfs) {
        mpKFDB->add(kf);
    }
    std::cout << "----> Done" << std::endl;

    mpMap->msnFinishedAgents.insert(this->mClientId);

    std::cout << "--> Show map" << std::endl;
    if(params::vis::mbActive)
        mpViewer->DrawMap(mpMap);
    std::cout << "----> Done" << std::endl;

//    cout << "Trigger GBA" << endl;
//    mpMap->RequestBA(mpCC->mClientId);

//    std::cout << "--> Show map" << std::endl;
//    if(params::vis::mbActive)
//        mpViewer->DrawMap(mpMap);
//    std::cout << "----> Done" << std::endl;
}

void ClientHandler::Reset()
{
    unique_lock<mutex> lock(mMutexReset);
    mbReset = true;
}

ClientHandler::kfptr ClientHandler::GetCurrentRefKFfromTracking()
{
    if(mpTracking->mState < 2)
        return nullptr;
    else
        return mpTracking->GetReferenceKF();
}

int ClientHandler::GetNumKFsinLoopFinder()
{
    if(mpLoopFinder)
        return mpLoopFinder->GetNumKFsinQueue();
    else
        return -1;
}

int ClientHandler::GetNumKFsinMapMatcher()
{
    if(mpMapMatcher)
        return mpMapMatcher->GetNumKFsinQueue();
    else
        return -1;
}

void ClientHandler::ClearCovGraph(size_t MapId)
{
    mpMapping->ClearCovGraph(MapId);
}

//#ifdef LOGGING
//void ClientHandler::SetLogger(boost::shared_ptr<mylog> pLogger)
//{
//    mpCC->mpLogger = pLogger;
//}
//#endif

} //end ns
