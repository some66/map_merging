#include <cslam/Uncertainty.h>

#ifndef JCSAC_DEBUG
#define JCSAC_DEBUG 1
#endif

#define JCSAC_LOG(fmt, ...) do { \
  std::fprintf(stderr, "[JCSAC] " fmt "\n", ##__VA_ARGS__); \
  std::fflush(stderr); \
} while(0)

#define JCSAC_ERR(fmt, ...) do { \
  std::fprintf(stderr, "[JCSAC][ERROR] " fmt "  (%s:%d)\n", ##__VA_ARGS__, __FILE__, __LINE__); \
  std::fflush(stderr); \
} while(0)

#define JCSAC_CHECK(cond, fmt, ...) do { \
  if(!(cond)) { JCSAC_ERR("CHECK failed: " fmt, ##__VA_ARGS__); return false; } \
} while(0)

#define JCSAC_CHECK_THROW(cond, fmt, ...) do { \
  if(!(cond)) { char __buf[1024]; \
    std::snprintf(__buf, sizeof(__buf), "[JCSAC][FATAL] " fmt "  (%s:%d)", ##__VA_ARGS__, __FILE__, __LINE__); \
    throw std::runtime_error(__buf); } \
} while(0)

namespace cslam{

//输入一个 g2o::Sim3 对象，并返回相应的 4x4 齐次变换矩阵, 没有考虑缩放（Eigen::Matrix4d 类型）
Eigen::Matrix4d convertSim3ToHomogeneousMatrix(const g2o::Sim3& g2oScw) 
{
    // 获取旋转矩阵
    Eigen::Matrix3d R = g2oScw.rotation().toRotationMatrix();
    // 获取平移向量
    Eigen::Vector3d t = g2oScw.translation();
    // 构建齐次变换矩阵
    Eigen::Matrix4d T;
    T.topLeftCorner<3,3>() =  R; // 左上角3x3是缩放后的旋转矩阵
    T.topRightCorner<3,1>() = t;    // 右上角3x1是平移向量
    T.row(3) << 0, 0, 0, 1;         // 底部行设置为[0, 0, 0, 1]
    return T;
}


Eigen::Matrix<double, 6, 1> logSE3(const Eigen::Matrix4d& T) 
{
            Eigen::Matrix3d R = T.topLeftCorner<3, 3>();
            Eigen::Vector3d t = T.topRightCorner<3, 1>();

            double theta = acos((R.trace() - 1) / 2);
            Eigen::Vector3d w;
            if (theta > 0.0001) { // 避免除以0的问题
                w = (theta / (2 * sin(theta))) * Eigen::Vector3d(R(2, 1) - R(1, 2), R(0, 2) - R(2, 0), R(1, 0) - R(0, 1));
            } else {
                w = Eigen::Vector3d(0, 0, 0); // 当旋转非常小的时候
            }

            Eigen::Matrix3d J;
            if (theta > 0.0001) {
                J = Eigen::Matrix3d::Identity() - 0.5 * R + (1 - theta / (2 * tan(theta / 2))) / theta * R * R;
            } else {
                J = Eigen::Matrix3d::Identity(); // 当旋转非常小的时候，J近似为单位矩阵
            }
            Eigen::Vector3d u = J * t;

            Eigen::Matrix<double, 6, 1> xi;
            xi.tail<3>() = w * theta;
            xi.head<3>() = u;

            return xi;
}

//向量返回旋转矩阵
Eigen::Matrix3d rodrigues(const Eigen::Vector3d& omega) 
{
        double theta = omega.norm();  // 计算旋转向量的模长，即旋转角度
        Eigen::Matrix3d omega_hat;    // 创建一个3x3的反对称矩阵

        // 构建omega的反对称矩阵
        omega_hat << 0,        -omega.z(), omega.y(),
                    omega.z(), 0,          -omega.x(),
                    -omega.y(), omega.x(),  0;

        // 如果角度非常小，接近于0，直接返回单位矩阵以避免数值不稳定
        if (theta < std::numeric_limits<double>::epsilon()) 
        {
            return Eigen::Matrix3d::Identity();
        }

        // 使用罗德里格斯公式计算旋转矩阵
        Eigen::Matrix3d R = Eigen::Matrix3d::Identity()
                            + (sin(theta) / theta) * omega_hat
                            + ((1 - cos(theta)) / (theta * theta)) * omega_hat * omega_hat;

        return R;
}

Eigen::Matrix4d invertSE3(const Eigen::Matrix4d& T)
 {
            Eigen::Matrix3d R = T.block<3,3>(0, 0);  // 提取旋转矩阵R
            Eigen::Vector3d t = T.block<3,1>(0, 3);  // 提取平移向量t

            Eigen::Matrix3d Rt = R.transpose();  // 计算R的转置，即R的逆
            Eigen::Vector3d invT = -Rt * t;  // 计算逆平移向量

            Eigen::Matrix4d T_inv = Eigen::Matrix4d::Identity();  // 创建单位矩阵
            T_inv.block<3,3>(0, 0) = Rt;  // 将逆旋转矩阵填充到左上角
            T_inv.block<3,1>(0, 3) = invT;  // 将逆平移向量填充到右上角

            return T_inv;
}

  // 计算伴随矩阵的实现
   Eigen::MatrixXd compute_Ad(const Eigen::MatrixXd& rotation, const Eigen::VectorXd& translation) 
   {
        Eigen::MatrixXd Ad(6, 6);
        Eigen::MatrixXd skew_translation = vector_to_skew(translation);  // 需要实现skew_symmetric函数
        Ad.block(0, 0, 3, 3) = rotation;
        Ad.block(0, 3, 3, 3) = skew_translation * rotation;
        Ad.block(3, 3, 3, 3) = rotation;
        return Ad;
    }


// 定义函数：将3维向量转换为斜对称矩阵
Eigen::Matrix3d vector_to_skew(const Eigen::Vector3d& v) 
{
        Eigen::Matrix3d m;
        m <<  0,     -v.z(),  v.y(),
            v.z(),  0,     -v.x(),
            -v.y(),  v.x(),  0;
        return m;
}

inline bool isFiniteMatrix(const Eigen::MatrixXd& M) {
  return (M.array().allFinite());
}
inline bool isFiniteVec(const Eigen::VectorXd& v) {
  return (v.array().allFinite());
}

// ===================== E1(x) =====================
inline double E1_of(double x) {
  if (x <= 0.0) x = std::numeric_limits<double>::min();
#ifdef USE_BOOST_MATH
  return boost::math::expint(x);
#else
  if (x < 1.0) {
    static const double gamma = 0.57721566490153286060;
    double term = x, sum = 0.0;
    for (int k=1; k<=30; ++k) {
      double add = ((k&1)? -1.0 : +1.0) * term / (k * std::tgamma(k+1));
      sum += add;
      term *= x;
    }
    return -gamma - std::log(x) + sum;
  } else {
    const double ex = std::exp(-x);
    const double invx = 1.0/x;
    double s = 1.0 - invx + 2*invx*invx - 6*invx*invx*invx + 24*std::pow(invx,4);
    return ex * invx * s;
  }
#endif
}

inline KDEWeights jcsac_compute_weights(const Eigen::VectorXd& r,
                                        const JCSACConfig& cfg)
{
  KDEWeights out;
  const int N = (int)r.size();
  out.w_full  = Eigen::VectorXd::Constant(N, 1e-12);
  out.w_sqrt  = Eigen::VectorXd::Constant(N, 1e-6);
  out.valid_mask.assign(N, 0);
  if (N==0) return out;

  for (int i=0;i<N;++i)
    out.valid_mask[i] = (r[i] < cfg.hard_gate * cfg.sigma_max) ? 1 : 0;

  std::vector<int> idx; idx.reserve(N);
  for (int i=0;i<N;++i) if (out.valid_mask[i]) idx.push_back(i);
  const int n = (int)idx.size();
  if (n==0) return out;

  Eigen::VectorXd rv(n);
  for (int j=0;j<n;++j) rv[j] = r[idx[j]];

  Eigen::VectorXd wv = Eigen::VectorXd::Ones(n);
  if (n>=2) {
    const double C = 0.5 * std::pow(double(n), 1.0/5.0)
                   / (cfg.k * std::sqrt(2.0*M_PI) * cfg.sigma_max);
    const double c = std::pow(double(n), 2.0/5.0)
                   / (2.0 * cfg.k * cfg.k * cfg.sigma_max * cfg.sigma_max);
    for (int i=0;i<n;++i) {
      double acc=0.0;
      for (int j=0;j<n;++j) {
        if (i==j) continue;
        const double d2 = (rv[i]-rv[j])*(rv[i]-rv[j]);
        acc += E1_of(c*d2);
      }
      wv[i] = (C/double(n))*acc;
    }
    const double m = std::max(1e-12, wv.mean());
    wv = (wv.array()/m).matrix();
    wv = wv.cwiseMax(1e-12).cwiseMin(1e6);
  }
  for (int j=0;j<n;++j) {
    out.w_full[idx[j]] = wv[j];
    out.w_sqrt[idx[j]] = std::sqrt(wv[j]);
  }

#if JCSAC_DEBUG
  JCSAC_LOG("KDE weights: N=%d  valid=%d  w_mean=%.6g", N, n, out.w_full.mean());
#endif

  return out;
}

// ===================== Mat/Eigen 安全转换辅助 =====================
inline bool check_cv_pose_4x4(const cv::Mat& T, const char* tag) {
  if (T.empty()) { JCSAC_ERR("%s is empty", tag); return false; }
  if (!(T.rows==4 && T.cols==4)) { JCSAC_ERR("%s size %dx%d != 4x4", tag, T.rows, T.cols); return false; }
  if (!(T.type()==CV_32F || T.type()==CV_64F)) { JCSAC_ERR("%s type=%d not float/double", tag, T.type()); return false; }
  return true;
}

inline bool cv2eigen_safe(const cv::Mat& Tcv, Eigen::Matrix4d& Te, const char* tag) {
  if (!check_cv_pose_4x4(Tcv, tag)) return false;
  try { cv::cv2eigen(Tcv, Te); }
  catch (const std::exception& e) { JCSAC_ERR("cv2eigen(%s) threw: %s", tag, e.what()); return false; }
  if (!Te.allFinite()) { JCSAC_ERR("%s has NaN/Inf after conversion", tag); return false; }
  return true;
}

// ===================== 一次性固定白化 (6N)x6 =====================
inline bool jcsac_compute_whitening_once(
    const double* params, const std::vector<MapMatchHit>& hits, Eigen::MatrixXd& L_out)
{
  const int N = (int)hits.size();
  L_out.setZero();
  L_out.resize(N*6, 6);

  Eigen::Map<const Eigen::Vector3d> t(params);
  Eigen::Map<const Eigen::Vector3d> w(params+3);
  Eigen::Matrix4d Tba = Eigen::Matrix4d::Identity();
  Tba.topLeftCorner<3,3>() = rodrigues(w);
  Tba.topRightCorner<3,1>() = t;
  JCSAC_CHECK(isFiniteMatrix(Tba), "Tba not finite");

  const size_t ID0 = hits.empty()? 0 : hits[0].mpKFCurr->mId.second;

#if JCSAC_DEBUG
  JCSAC_LOG("Whitening: N=%d  ID0=%zu  params(t)=%.3g %.3g %.3g  w=%.3g %.3g %.3g",
            N, ID0, t[0], t[1], t[2], w[0], w[1], w[2]);
#endif

  for (int i=0;i<N;++i) {
    JCSAC_CHECK(hits[i].mpKFCurr && hits[i].mpKFMatch, "Null KeyFrame ptr at i=%d", i);

    // 基础几何准备（回退路径需要）
    g2o::Sim3 s = hits[i].mg2oScw;
    cv::Mat Tai, Tbj;
    if (hits[i].mpKFCurr->mId.second == ID0) {
      Tai = hits[i].mpKFCurr->GetPose();
      Tbj = hits[i].mpKFMatch->GetPose();
    } else {
      s = s.inverse();
      Tai = hits[i].mpKFCurr->GetPoseInverse();
      Tbj = hits[i].mpKFMatch->GetPoseInverse();
    }

    Eigen::Matrix4d Tab = convertSim3ToHomogeneousMatrix(s);
    JCSAC_CHECK(isFiniteMatrix(Tab), "convertSim3 returned NaN/Inf at i=%d", i);

    Eigen::Matrix4d Tai_e, Tbj_e;
    JCSAC_CHECK(cv2eigen_safe(Tai, Tai_e, "Tai"), "Tai bad at i=%d", i);
    JCSAC_CHECK(cv2eigen_safe(Tbj, Tbj_e, "Tbj"), "Tbj bad at i=%d", i);

    // ====== 1) 优先使用命中自带的不确定性（推荐路径） ======
    bool used_frontend_unc = false;
    Eigen::Matrix<double,6,6> Omega_i;

    if (hits[i].HasOmega6()) {
      Omega_i = hits[i].mOmega6;
      used_frontend_unc = true;
    } else if (hits[i].HasSigma6()) {
      // 由协方差反求信息，带轻微正则
      Eigen::Matrix<double,6,6> Sigma_i = hits[i].mSigma6;
      Sigma_i = 0.5*(Sigma_i + Sigma_i.transpose());
      Sigma_i += 1e-9 * Eigen::Matrix<double,6,6>::Identity();
      Eigen::LDLT<Eigen::Matrix<double,6,6>> ldlt(Sigma_i);
      if (ldlt.info() == Eigen::Success) {
        Omega_i = ldlt.solve(Eigen::Matrix<double,6,6>::Identity());
        used_frontend_unc = true;
      } // 否则 fall back
    }

    // ====== 2) 回退：按你原来的 A+B+C 推导出 Sigma_e，再取信息 ======
    if (!used_frontend_unc) {
      Eigen::Matrix4d E = invertSE3(Tab) * (Tba * Tai_e);
      JCSAC_CHECK(isFiniteMatrix(E), "E not finite at i=%d", i);
      Eigen::Matrix<double,6,1> e = logSE3(E);
      JCSAC_CHECK(isFiniteVec(e), "logSE3(E) NaN at i=%d", i);

      const Eigen::Vector3d rho = e.head<3>(), phi = e.tail<3>();
      const Eigen::Matrix3d rho_hat = vector_to_skew(rho);
      const Eigen::Matrix3d phi_hat = vector_to_skew(phi);

      Eigen::Matrix<double,6,6> Jr_inv = Eigen::Matrix<double,6,6>::Identity();
      Jr_inv.block<3,3>(0,0) += 0.5*phi_hat;
      Jr_inv.block<3,3>(0,3) += 0.5*rho_hat;
      Jr_inv.block<3,3>(3,3) += 0.5*phi_hat;

      // β
      Eigen::Matrix4d T_inv = invertSE3(Tai_e);
      Eigen::Matrix3d R_inv = T_inv.topLeftCorner<3,3>();
      Eigen::Vector3d p_inv = T_inv.topRightCorner<3,1>();
      Eigen::Matrix<double,6,6> Ad = Eigen::Matrix<double,6,6>::Zero();
      Ad.block<3,3>(0,0) = R_inv;
      Ad.block<3,3>(0,3) = vector_to_skew(p_inv) * R_inv;
      Ad.block<3,3>(3,3) = R_inv;

      Eigen::Matrix<double,6,1> jb = logSE3(Tai_e);
      Eigen::Matrix3d phi_b = vector_to_skew(jb.tail<3>());
      Eigen::Matrix3d rho_b = vector_to_skew(jb.head<3>());
      Eigen::Matrix<double,6,6> Jl = Eigen::Matrix<double,6,6>::Identity();
      Jl.block<3,3>(0,0) += 0.5*phi_b;
      Jl.block<3,3>(0,3) += 0.5*rho_b;
      Jl.block<3,3>(3,3) += 0.5*phi_b;

      Eigen::Matrix<double,6,6> Jb = Jr_inv * Ad * Jl;

      Eigen::Matrix<double,6,6> Sig_b = Eigen::Matrix<double,6,6>::Identity();
      Sig_b.topLeftCorner<3,3>() *= 0.1;
      Eigen::Matrix<double,6,6> A = Jb.transpose() * Sig_b * Jb;

      // α
      Eigen::Matrix4d Tb = Tba * Tai_e;
      T_inv = invertSE3(Tb);
      R_inv = T_inv.topLeftCorner<3,3>();
      p_inv = T_inv.topRightCorner<3,1>();
      Ad.setZero();
      Ad.block<3,3>(0,0) = R_inv;
      Ad.block<3,3>(0,3) = vector_to_skew(p_inv) * R_inv;
      Ad.block<3,3>(3,3) = R_inv;

      Eigen::Matrix<double,6,1> ja = logSE3(Tbj_e);
      Eigen::Matrix3d phi_a = vector_to_skew(ja.tail<3>());
      Eigen::Matrix3d rho_a = vector_to_skew(ja.head<3>());
      Jl.setIdentity();
      Jl.block<3,3>(0,0) += 0.5*phi_a;
      Jl.block<3,3>(0,3) += 0.5*rho_a;
      Jl.block<3,3>(3,3) += 0.5*phi_a;
      Eigen::Matrix<double,6,6> Ja = -Jr_inv * Ad * Jl;

      Eigen::Matrix<double,6,6> Sig_a = Eigen::Matrix<double,6,6>::Identity();
      Sig_a.topLeftCorner<3,3>() *= 0.1;
      Eigen::Matrix<double,6,6> B = Ja.transpose() * Sig_a * Ja;

      // 闭环
      Eigen::Matrix4d kk = invertSE3(Tbj_e) * (Tba * Tai_e);
      T_inv = invertSE3(kk);
      R_inv = T_inv.topLeftCorner<3,3>();
      p_inv = T_inv.topRightCorner<3,1>();
      Ad.setZero();
      Ad.block<3,3>(0,0) = R_inv;
      Ad.block<3,3>(0,3) = vector_to_skew(p_inv) * R_inv;
      Ad.block<3,3>(3,3) = R_inv;

      Eigen::Matrix4d Taibj = Tab * Tbj_e.inverse();
      Eigen::Matrix<double,6,1> jc = logSE3(Taibj);
      Eigen::Matrix3d phi_c = vector_to_skew(jc.tail<3>());
      Eigen::Matrix3d rho_c = vector_to_skew(jc.head<3>());
      Jl.setIdentity();
      Jl.block<3,3>(0,0) += 0.5*phi_c;
      Jl.block<3,3>(0,3) += 0.5*rho_c;
      Jl.block<3,3>(3,3) += 0.5*phi_c;
      Eigen::Matrix<double,6,6> Jc = -Jr_inv * Ad * Jl;

      Eigen::Matrix<double,6,6> Sig_c = Eigen::Matrix<double,6,6>::Identity();
      Eigen::Matrix<double,6,6> C = Jc.transpose() * Sig_c * Jc;

      Eigen::Matrix<double,6,6> Sigma_e = A + B + C;
      if (!Sigma_e.allFinite()) {
        JCSAC_ERR("Sigma_e not finite at i=%d", i);
        return false;
      }
      // 信息矩阵
      Eigen::Matrix<double,6,6> Id = Eigen::Matrix<double,6,6>::Identity();
      Sigma_e = 0.5*(Sigma_e + Sigma_e.transpose()) + 1e-9*Id;           // SPD 修正
      Eigen::LDLT<Eigen::Matrix<double,6,6>> ldlt(Sigma_e);
      if (ldlt.info() != Eigen::Success) {
        JCSAC_ERR("LDLT(Sigma_e) failed at i=%d", i);
        return false;
      }
      Omega_i = ldlt.solve(Id);
    }

    // ====== 3) 最终白化矩阵 L_i（Omega = L L^T） ======
    // 数值对称 + 正则
    Omega_i = 0.5*(Omega_i + Omega_i.transpose()) + 1e-12*Eigen::Matrix<double,6,6>::Identity();

    Eigen::LLT<Eigen::Matrix<double,6,6>> llt(Omega_i);
    if (llt.info() != Eigen::Success) {
      // 进一步正则再尝试
      Omega_i += 1e-8*Eigen::Matrix<double,6,6>::Identity();
      llt.compute(Omega_i);
    }
    if (llt.info() != Eigen::Success) {
      JCSAC_ERR("LLT(Omega_i) failed at i=%d", i);
      return false;
    }

    const Eigen::Matrix<double,6,6> Li = llt.matrixL(); // 下三角，使 ||Li e||^2 = e^T Omega e
    L_out.block<6,6>(i*6, 0) = Li;
  }

  JCSAC_CHECK(isFiniteMatrix(L_out), "Whitening L has NaN/Inf");
#if JCSAC_DEBUG
  JCSAC_LOG("Whitening OK: rows=%d cols=%d  norm(L)=%.6g", (int)L_out.rows(), (int)L_out.cols(), L_out.norm());
#endif
  return true;
}


// ===================== Ceres 代价函数（值语义存 L 和 √w） =====================
class MapMatchCostFunctionJCSAC : public ceres::DynamicCostFunction {
public:
  MapMatchCostFunctionJCSAC(std::vector<MapMatchHit> const& hits,
                            Eigen::MatrixXd L_blocks,
                            Eigen::VectorXd w_sqrt)
  : hits_(hits), L_(std::move(L_blocks)), wsqrt_(std::move(w_sqrt))
  {
    set_num_residuals((int)hits_.size()*6);
    mutable_parameter_block_sizes()->push_back(6);
#if JCSAC_DEBUG
    JCSAC_LOG("Cost ctor: N=%zu  L[%d x %d]  wsqrt[%d]", hits_.size(), (int)L_.rows(), (int)L_.cols(), (int)wsqrt_.size());
#endif
  }

 bool Evaluate(double const* const* parameters, double* residuals, double** jacobians) const override
{
  const int N = (int)hits_.size();
  if (N==0) return true;

  // 1) 安全映射 residuals：整块 6N×1 行主序向量
  Eigen::Map<Eigen::Matrix<double, Eigen::Dynamic, 1, Eigen::ColMajor>>  // 列向量即可
      res(residuals, 6*N);

  // 2) 若需要 Jacobian，则把 ceres 提供的内存映射成  (6N × 6) 的 RowMajor 矩阵
  Eigen::Map<Eigen::Matrix<double, Eigen::Dynamic, 6, Eigen::RowMajor>> Jall(
      jacobians && jacobians[0] ? jacobians[0] : nullptr,  // data ptr
      jacobians && jacobians[0] ? 6*N : 0,                 // rows
      jacobians && jacobians[0] ? 6   : 0                  // cols
  );

  Eigen::Map<const Eigen::Vector3d> t(parameters[0]);
  Eigen::Map<const Eigen::Vector3d> w(parameters[0] + 3);
  Eigen::Matrix4d Tba = Eigen::Matrix4d::Identity();
  Tba.topLeftCorner<3,3>() = rodrigues(w);
  Tba.topRightCorner<3,1>() = t;

  const size_t ID0 = hits_.empty()? 0 : hits_[0].mpKFCurr->mId.second;

  for (int i=0;i<N;++i) {
    g2o::Sim3 s = hits_[i].mg2oScw;
    cv::Mat Tai;
    if (hits_[i].mpKFCurr->mId.second == ID0) Tai = hits_[i].mpKFCurr->GetPose();
    else { s = s.inverse(); Tai = hits_[i].mpKFCurr->GetPoseInverse(); }

    Eigen::Matrix4d Tab = convertSim3ToHomogeneousMatrix(s);
    Eigen::Matrix4d T_ai; cv::cv2eigen(Tai, T_ai);

    Eigen::Matrix4d E = invertSE3(Tab) * (Tba * T_ai);
    Eigen::Matrix<double,6,1> e = logSE3(E);

    const Eigen::Matrix<double,6,6> Li = L_.block<6,6>(i*6, 0);
    Eigen::Matrix<double,6,1> rw = wsqrt_[i] * (Li * e);

    // ---- 安全写 residuals：把第 i 个 6×1 区块整体赋值 ----
    res.segment<6>(i*6) = rw;

    if (jacobians && jacobians[0]) {
      // 计算 J_i （6×6）
      const Eigen::Matrix4d T_inv = invertSE3(Tba * T_ai);
      const Eigen::Matrix3d R_inv = T_inv.topLeftCorner<3,3>();
      const Eigen::Vector3d p_inv = T_inv.topRightCorner<3,1>();
      Eigen::Matrix<double,6,6> Ad = Eigen::Matrix<double,6,6>::Zero();
      Ad.block<3,3>(0,0) = R_inv;
      Ad.block<3,3>(0,3) = vector_to_skew(p_inv) * R_inv;
      Ad.block<3,3>(3,3) = R_inv;

      const Eigen::Matrix3d phi_hat = vector_to_skew(e.tail<3>());
      const Eigen::Matrix3d rho_hat = vector_to_skew(e.head<3>());
      Eigen::Matrix<double,6,6> Jr_inv = Eigen::Matrix<double,6,6>::Identity();
      Jr_inv.block<3,3>(0,0) += 0.5*phi_hat;
      Jr_inv.block<3,3>(0,3) += 0.5*rho_hat;
      Jr_inv.block<3,3>(3,3) += 0.5*phi_hat;

      Eigen::Matrix<double,6,6> Ji = wsqrt_[i] * (Li * (Jr_inv * Ad));

      // ---- 安全写 Jacobian：把 (i*6 .. i*6+5) 行的 6×6 区块整体赋值 ----
      Jall.block<6,6>(i*6, 0) = Ji;
    }
  }
  return true;
}

private:
  std::vector<MapMatchHit> const& hits_;
  Eigen::MatrixXd L_;
  Eigen::VectorXd wsqrt_;
};

// ===================== IRLS 控制器 =====================
inline g2o::Sim3 ExportSim3FromJCSAC(const std::vector<MapMatchHit>& hits,
                                     const JCSACResult& res)
{
  Eigen::Map<const Eigen::Vector3d> t(res.params);
  Eigen::Map<const Eigen::Vector3d> w(res.params + 3);
  Eigen::Matrix3d R = rodrigues(w);

  double ssum = 1.0;
  if (!hits.empty()) {
    const size_t ID0 = hits[0].mpKFCurr->mId.second;
    ssum = 0.0;
    for (const auto& h : hits) {
      g2o::Sim3 s = h.mg2oScw;
      double sc = (h.mpKFCurr->mId.second == ID0) ? s.scale() : 1.0 / s.scale();
      ssum += sc;
    }
    ssum /= double(hits.size());
  } else {
    JCSAC_ERR("hits empty in ExportSim3, use scale=1");
  }

  g2o::Sim3 Tba(R, t, ssum);
  return Tba.inverse(); // Tab
}


// ====== 主优化：JCSAC IRLS（修正后的“new CostFunction”版本） ======
JCSACResult OptimizeTransformsJCSAC(const std::vector<MapMatchHit>& hits,
                                   const JCSACConfig& cfg)
{
  std::cerr << "[JCSAC] >>> JCSAC Robust Map Merging <<<  hits=" << hits.size() << "\n";

  JCSACResult best;
  const int N = static_cast<int>(hits.size());
  double params[6] = {0,0,0, 0,0,0};  // 初值：t(0)、w(0)

  // 基础检查
  if (N == 0) {
    std::cerr << "[JCSAC][ERROR] No matches\n";
    return best;
  }
  for (int i = 0; i < N; ++i) {
    if (!hits[i].mpKFCurr || !hits[i].mpKFMatch) {
      std::cerr << "[JCSAC][ERROR] Null KeyFrame ptr at i=" << i << "\n";
      return best;
    }
  }

  // 一次性固定白化矩阵 L: (6N x 6)，块 L.block<6,6>(i*6, 0)
  Eigen::MatrixXd L;
  if (!jcsac_compute_whitening_once(params, hits, L)) {
    std::cerr << "[JCSAC][ERROR] Whitening failed\n";
    return best;
  }

  Eigen::VectorXd wsqrt = Eigen::VectorXd::Ones(N);          // 当前迭代的 √w
  double last_J = std::numeric_limits<double>::infinity();   // 可比目标

  for (int it = 0; it < cfg.n_irls; ++it) {
    std::cerr << "[JCSAC] IRLS iter=" << it << "\n";

    // === 1) 在固定 L 下评估“未加权白化残差”，仅用于算权重（不加入 Problem，安全用栈对象）===
    {
      MapMatchCostFunctionJCSAC cost_eval(hits, L, Eigen::VectorXd::Ones(N)); // 栈对象
      std::vector<const double*> par(1, params);
      std::vector<double*> jac(1, nullptr);
      std::vector<double> res(6 * N, 0.0);

      // 只 Evaluate，不进 Problem
      if (!cost_eval.Evaluate(par.data(), res.data(), jac.data())) {
        std::cerr << "[JCSAC][ERROR] Evaluate (unweighted) failed\n";
        return best;
      }

      // 逐条测量的 ||L_i e_i|| 范数
      Eigen::Map<const Eigen::Matrix<double, Eigen::Dynamic, 6, Eigen::RowMajor>>
          Y(res.data(), N, 6);
      const Eigen::VectorXd y2 = Y.rowwise().squaredNorm();
      const Eigen::VectorXd r  = y2.array().sqrt();

      // KDE + σ-consensus 计算权重（返回 √w）
      const auto W = jcsac_compute_weights(r, cfg);
      wsqrt = W.w_sqrt;
      // （可加调试输出）
      // std::cerr << "[JCSAC] r_mean=" << r.mean() << " w_mean=" << W.w_full.mean() << "\n";
    }

    // === 2) 在相同 L 下，带 √w 做一次加权最小二乘（加入 Problem，必须 new）===
    {
      auto* cost = new MapMatchCostFunctionJCSAC(hits, L, wsqrt); // 关键：堆分配交给 Ceres
      ceres::Problem problem;
      problem.AddResidualBlock(cost, nullptr, params);            // Ceres 会在 problem 析构时 delete

      ceres::Solver::Options options;
      options.max_num_iterations = cfg.inner_nfev;
      options.linear_solver_type = ceres::DENSE_QR;
      options.minimizer_type = ceres::TRUST_REGION;
      options.trust_region_strategy_type = ceres::DOGLEG;
      options.minimizer_progress_to_stdout = true; // 打开逐迭代日志便于排查
      // （可选）梯度检查
      // options.check_gradients = true;
      // options.gradient_check_relative_precision = 1e-6;

      ceres::Solver::Summary summary;
      ceres::Solve(options, &problem, &summary);
      best.cost = summary.final_cost;

      const std::string brief = summary.BriefReport(); // 避免临时 c_str() 生命周期问题
      std::cerr << "[JCSAC] Ceres: " << brief << "  cost=" << best.cost << "\n";
    }

    // === 3) 用“同一组 √w”评估可比目标 J_post（仍然不把 cost 加入 Problem）===
    double J_post = 0.0;
    {
      MapMatchCostFunctionJCSAC cost_eval(hits, L, wsqrt); // 栈对象，仅 Evaluate
      std::vector<const double*> par(1, params);
      std::vector<double*> jac(1, nullptr);
      std::vector<double> res(6 * N, 0.0);

      if (!cost_eval.Evaluate(par.data(), res.data(), jac.data())) {
        std::cerr << "[JCSAC][ERROR] Evaluate (post) failed\n";
        return best;
      }

      // 由于 residual = √w_i * L_i e_i，因此 y2 = w_i * ||L_i e_i||^2，直接取均值即可
      Eigen::Map<const Eigen::Matrix<double, Eigen::Dynamic, 6, Eigen::RowMajor>>
          Y(res.data(), N, 6);
      const Eigen::VectorXd y2 = Y.rowwise().squaredNorm();
      J_post = y2.mean();
    }

    if (J_post > last_J) {
      std::cerr << "[JCSAC][warn] J increased by " << (J_post - last_J) << "\n";
    }
    const double rel_drop = (last_J - J_post) / std::max(last_J, 1.0);
    std::cerr << "[JCSAC] iter " << it << "  J=" << J_post << "  rel_drop=" << rel_drop << "\n";
    last_J = J_post;

    if (rel_drop < cfg.rel_drop_tol) {
      std::cerr << "[JCSAC] Converged at iter " << it << "\n";
      break;
    }

    // 记录便于调试（可选）
    best.last_wsqrt = wsqrt;
    {
      MapMatchCostFunctionJCSAC cost_eval(hits, L, Eigen::VectorXd::Ones(N));
      std::vector<const double*> par(1, params);
      std::vector<double*> jac(1, nullptr);
      std::vector<double> res(6 * N, 0.0);
      cost_eval.Evaluate(par.data(), res.data(), jac.data());
      Eigen::Map<const Eigen::Matrix<double, Eigen::Dynamic, 6, Eigen::RowMajor>>
          Y(res.data(), N, 6);
      best.last_residual_norms = Y.rowwise().norm();
    }
  }

  // 写回输出参数
  for (int i = 0; i < 6; ++i) best.params[i] = params[i];

  std::cerr << "[JCSAC] Done. params t=["
            << best.params[0] << " " << best.params[1] << " " << best.params[2]
            << "]  w=[" << best.params[3] << " " << best.params[4] << " " << best.params[5]
            << "]\n";

  return best;
}


// ====== 薄包装：对外保持原 OptimizeTransforms 接口（返回 g2o::Sim3） ======

g2o::Sim3 OptimizeTransforms(const std::vector<MapMatchHit>& vMatchHits)
{
    JCSACConfig cfg; // 可按需调整超参

    // 仅计时 OptimizeTransformsJCSAC 这一行
    using clock = std::chrono::steady_clock;
    const auto t0 = clock::now();
    const JCSACResult r = OptimizeTransformsJCSAC(vMatchHits, cfg);
    const auto t1 = clock::now();

    const double t_opt_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    std::cout << "[OptimizeTransformsJCSAC] time = " << t_opt_ms << " ms"  << ")\n";

    return ExportSim3FromJCSAC(vMatchHits, r); // T_ba^{-1} = T_ab
}

} 
