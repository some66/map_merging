/**
* This file is part of CCM-SLAM.
*
* Copyright (C): Patrik Schmuck <pschmuck at ethz dot ch> (ETH Zurich)
* For more information see <https://github.com/patriksc/CCM-SLAM>
*
* CCM-SLAM is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* CCM-SLAM is based in the monocular version of ORB-SLAM2 by Raúl Mur-Artal.
* CCM-SLAM partially re-uses modules of ORB-SLAM2 in modified or unmodified condition.
* For more information see <https://github.com/raulmur/ORB_SLAM2>.
*
* CCM-SLAM is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CCM-SLAM. If not, see <http://www.gnu.org/licenses/>.
*/

#include <cslam/Optimizer.h>

#include <chrono>
#include <ctime>

namespace cslam {

//定义了视觉 SLAM 系统中的 全局捆绑调整（Global Bundle Adjustment, GBA）函数 Optimizer::GlobalBundleAdjustemntClient()，
//用于在分布式或多客户端 SLAM 环境中执行全局优化，最小化相机位姿和地图点的重投影误差。
//该函数的主要任务是：
//从地图中提取所有关键帧和地图点，用于全局优化。调用核心捆绑调整函数 BundleAdjustmentClient() 执行优化。
//支持分布式 SLAM 环境中的跨客户端优化，通过客户端 ID 标识不同客户端数据。
//提供可选的鲁棒优化模式，用于处理异常数据（如外点或噪声）。
//vpKFs: 当前地图中的所有关键帧。
//vpMP: 当前地图中的所有地图点。
//ClientId: 客户端 ID，标识不同客户端在分布式 SLAM 环境中的数据来源。
//nIterations: 最大迭代次数，控制优化过程的计算复杂度。
//pbStopFlag: 停止标志指针，用于终止长时间运行的优化过程（例如用户中断或资源不足时）。
//nLoopKF: 回环关键帧的 ID，用于回环检测后的优化（可选参数）。
//bRobust: 是否使用鲁棒优化（如 Huber 损失函数），减少外点或误差较大观测的影响。
void Optimizer::GlobalBundleAdjustemntClient(mapptr pMap, size_t ClientId, int nIterations, bool* pbStopFlag, const idpair nLoopKF, const bool bRobust)
{
    //从地图对象 pMap 中提取所有关键帧和地图点：
    //关键帧 (vpKFs): 包含相机位姿和观测信息，用于计算重投影误差。
    //地图点 (vpMP): 包含三维坐标和观测关联，用于优化空间位置。
    vector<kfptr> vpKFs = pMap->GetAllKeyFrames();
    vector<mpptr> vpMP = pMap->GetAllMapPoints();

    //调用核心BA调整函数
    BundleAdjustmentClient(vpKFs,vpMP,ClientId,nIterations,pbStopFlag, nLoopKF, bRobust);
}


//定义了视觉 SLAM 系统中的 捆绑调整优化函数 Optimizer::BundleAdjustmentClient()，用于在多客户端或分布式 SLAM 环境中执行位姿和地图点的联合优化。
//该函数的主要任务是：
//创建优化器，并将关键帧和地图点作为顶点添加到图优化结构中。
//将关键帧与地图点之间的观测关系设置为边，定义约束条件。
//执行捆绑调整（Bundle Adjustment, BA），最小化重投影误差，提高位姿和地图点的精度。
//根据是否包含回环检测，更新优化后的位姿和地图点坐标。

void Optimizer::BundleAdjustmentClient(const vector<kfptr> &vpKFs, const vector<mpptr> &vpMP, size_t ClientId,
                                 int nIterations, bool* pbStopFlag, const idpair nLoopKF, const bool bRobust)
{
   //初始化变量和优化器, zeropair: 标记客户端 ID，指定参考帧（ID 为 0 的关键帧）固定不变，用于定义优化基准。
   //vbNotIncludedMP: 标记未包含在优化中的地图点，用于后续恢复操作。
    const idpair zeropair = make_pair(0,ClientId);
    vector<bool> vbNotIncludedMP;
    vbNotIncludedMP.resize(vpMP.size());

   //   构建优化器, 使用 g2o 优化器 定义稀疏图优化：基于线性求解器 (Eigen) 构建块求解器。
   // 使用 Levenberg-Marquardt 算法求解非线性最小二乘问题。设置优化器算法，将其用于全局优化过程。
   //鲁棒性分析：支持鲁棒核函数（Huber 损失），减少外点对优化的影响。
    g2o::SparseOptimizer optimizer;
    g2o::BlockSolver_6_3::LinearSolverType * linearSolver;
    linearSolver = new g2o::LinearSolverEigen<g2o::BlockSolver_6_3::PoseMatrixType>();
    g2o::BlockSolver_6_3 * solver_ptr = new g2o::BlockSolver_6_3(linearSolver);
    g2o::OptimizationAlgorithmLevenberg* solver = new g2o::OptimizationAlgorithmLevenberg(solver_ptr);
    optimizer.setAlgorithm(solver);


    if(pbStopFlag)
        optimizer.setForceStopFlag(pbStopFlag);

    // Set KeyFrame vertices
    //设置关键帧顶点, 遍历所有关键帧，将其作为位姿顶点添加到优化器：从关键帧中获取位姿，并转换为 g2o 格式。
   //设置 ID 标识关键帧，并根据 zeropair 固定第一个关键帧不变，作为优化基准。添加顶点到优化图中。
       for(size_t i=0; i<vpKFs.size(); i++)
    {
        kfptr pKF = vpKFs[i];
        if(pKF->isBad())
            continue;
         ////如果关键帧标记为无效 (isBad())，则跳过。
        if(pKF->mId.first >= IDRANGE)
        {
            cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m #1: In \"Optimizer::LocalBundleAdjustment(...)\": KF index out of bounds" << endl;
            throw infrastructure_ex();
        }

        g2o::VertexSE3Expmap * vSE3 = new g2o::VertexSE3Expmap();
        vSE3->setEstimate(Converter::toSE3Quat(pKF->GetPose()));
        vSE3->setId(Optimizer::GetID(pKF->mId,true));
        //保证至少一个关键帧固定不变，避免优化过程发生漂移。
        vSE3->setFixed(pKF->mId == zeropair);
        optimizer.addVertex(vSE3);
    }


    const float thHuber2D = sqrt(5.99);
    // Set MapPoint vertices
    //设置地图点顶点,  遍历所有地图点，将其作为优化顶点：
   //将三维坐标转换为优化格式，并设置为可边缘化顶点（减少计算复杂度）。建立地图点与关键帧之间的观测边，定义约束关系。
    for(size_t i=0; i<vpMP.size(); i++)
    {
        mpptr pMP = vpMP[i];
        if(pMP->isBad())
            continue;

        if(pMP->mId.first >= IDRANGE)
        {
            cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m #1: In \"Optimizer::LocalBundleAdjustment(...)\": MP index out of bounds" << endl;
            throw infrastructure_ex();
        }

        g2o::VertexSBAPointXYZ* vPoint = new g2o::VertexSBAPointXYZ();
        vPoint->setEstimate(Converter::toVector3d(pMP->GetWorldPos()));
        const int id = Optimizer::GetID(pMP->mId,false);
        vPoint->setId(id);
        vPoint->setMarginalized(true);
        optimizer.addVertex(vPoint);

        const map<kfptr,size_t> observations = pMP->GetObservations();

        int nEdges = 0;
        //SET EDGES
        for(map<kfptr,size_t>::const_iterator mit=observations.begin(); mit!=observations.end(); mit++)
        {

            kfptr pKF = mit->first;
            if(pKF->isBad())
                continue;

            if(pKF->mId.first >= IDRANGE)
            {
                cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m #1: In \"Optimizer::LocalBundleAdjustment(...)\": KF index out of bounds" << endl;
                throw infrastructure_ex();
            }

            nEdges++;

            const cv::KeyPoint &kpUn = pKF->mvKeysUn[mit->second];

            Eigen::Matrix<double,2,1> obs;
            obs << kpUn.pt.x, kpUn.pt.y;

           //添加观测边,  每个地图点与所有观测到它的关键帧建立边，形成优化约束：将地图点和关键帧关联为边的两个顶点。
         //设置测量值为图像坐标，并定义误差权重矩阵。添加鲁棒核函数（Huber 损失），减少异常观测影响。
            g2o::EdgeSE3ProjectXYZ* e = new g2o::EdgeSE3ProjectXYZ();
            e->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(id)));
            e->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(Optimizer::GetID(pKF->mId,true))));            
            e->setMeasurement(obs);
            const float &invSigma2 = pKF->mvInvLevelSigma2[kpUn.octave];
            e->setInformation(Eigen::Matrix2d::Identity()*invSigma2);

            if(bRobust)
            {
                g2o::RobustKernelHuber* rk = new g2o::RobustKernelHuber;
                e->setRobustKernel(rk);
                rk->setDelta(thHuber2D);
            }

            e->fx = pKF->fx;
            e->fy = pKF->fy;
            e->cx = pKF->cx;
            e->cy = pKF->cy;

            optimizer.addEdge(e);
        }

        if(nEdges==0)
        {
            optimizer.removeVertex(vPoint);
            vbNotIncludedMP[i]=true;
        }
        else
        {
            vbNotIncludedMP[i]=false;
        }
    }


    // Optimize!
    //执行优化，初始化优化器，并运行迭代优化过程。优化变量包括关键帧位姿和地图点坐标，目标是最小化重投影误差。
    optimizer.initializeOptimization();
    optimizer.optimize(nIterations);


    // Recover optimized data
    //Keyframes
     //更新关键帧位姿, 将优化后的位姿从 g2o 格式转换回 OpenCV 格式，并更新关键帧信息。
    for(size_t i=0; i<vpKFs.size(); i++)
    {
        kfptr pKF = vpKFs[i];
        if(pKF->isBad())
            continue;
        g2o::VertexSE3Expmap* vSE3 = static_cast<g2o::VertexSE3Expmap*>(optimizer.vertex(Optimizer::GetID(pKF->mId,true)));
        g2o::SE3Quat SE3quat = vSE3->estimate();
        if(nLoopKF==zeropair)
        {
            pKF->SetPose(Converter::toCvMat(SE3quat),false);
        }
        else
        {
            pKF->mTcwGBA.create(4,4,CV_32F);
            Converter::toCvMat(SE3quat).copyTo(pKF->mTcwGBA);
            pKF->mBAGlobalForKF = nLoopKF;
        }
    }

    //Points
    //更新地图点坐标， 更新地图点三维坐标，并重新计算法向量和深度信息，确保一致性。
    for(size_t i=0; i<vpMP.size(); i++)
    {
        if(vbNotIncludedMP[i])
            continue;

        mpptr pMP = vpMP[i];

        if(pMP->isBad())
            continue;
        g2o::VertexSBAPointXYZ* vPoint = static_cast<g2o::VertexSBAPointXYZ*>(optimizer.vertex(Optimizer::GetID(pMP->mId,false)));

        if(nLoopKF==zeropair)
        {
            pMP->SetWorldPos(Converter::toCvMat(vPoint->estimate()),false);
            pMP->UpdateNormalAndDepth();
        }
        else
        {
            pMP->mPosGBA.create(3,1,CV_32F);
            Converter::toCvMat(vPoint->estimate()).copyTo(pMP->mPosGBA);
            pMP->mBAGlobalForKF = nLoopKF;
        }
    }
}

//定义了视觉 SLAM 系统中的 位姿优化函数 Optimizer::PoseOptimizationClient()，用于在多机SLAM 环境下对当前帧的位姿进行局部优化
// 该函数的主要任务是：构建稀疏图优化器，并将当前帧位姿和地图点观测关系添加到优化图中。
//使用 Levenberg-Marquardt (LM) 算法 对当前帧位姿进行最小二乘优化。
//基于优化结果筛选内点和外点，迭代更新优化过程，提高鲁棒性。
//返回优化后的位姿，并统计内点数量，以评估优化质量。

int Optimizer::PoseOptimizationClient(Frame &Frame)
{
    //定义优化器及其求解器
    //构建 g2o 稀疏优化器，用于图优化计算。使用密集线性求解器 (LinearSolverDense) 解决小规模问题，提高计算效率。配置 Levenberg-Marquardt (LM) 算法处理非线性最小二乘优化问题。
    g2o::SparseOptimizer optimizer;
    g2o::BlockSolver_6_3::LinearSolverType * linearSolver;
    linearSolver = new g2o::LinearSolverDense<g2o::BlockSolver_6_3::PoseMatrixType>();
    g2o::BlockSolver_6_3 * solver_ptr = new g2o::BlockSolver_6_3(linearSolver);
    g2o::OptimizationAlgorithmLevenberg* solver = new g2o::OptimizationAlgorithmLevenberg(solver_ptr);
    optimizer.setAlgorithm(solver);

    int nInitialCorrespondences=0;

    // Set Frame vertex
    //添加当前帧位姿顶点, 将当前帧位姿 𝑇𝑐𝑤  添加为优化图中的顶点：使用 Converter 将 OpenCV 矩阵格式转换为 g2o SE3Quat 格式。
     //设置 ID 为 0，表示这是优化图的主顶点。设置顶点为可变动（setFixed(false)），允许优化调整位姿。
    g2o::VertexSE3Expmap * vSE3 = new g2o::VertexSE3Expmap();
    vSE3->setEstimate(Converter::toSE3Quat(Frame.mTcw));
    vSE3->setId(0);
    vSE3->setFixed(false);
    optimizer.addVertex(vSE3);


    // Set MapPoint vertices
    //添加观测边和误差模型
    //初始化变量：vpEdgesMono 和 vnIndexEdgeMono: 存储优化图中的边和其对应的地图点索引。
    //deltaMono: 设置鲁棒核函数的阈值 (95% 置信区间)，减少外点影响。
    const int N = Frame.N;
    vector<g2o::EdgeSE3ProjectXYZOnlyPose*> vpEdgesMono;
    vector<size_t> vnIndexEdgeMono;
    vpEdgesMono.reserve(N);
    vnIndexEdgeMono.reserve(N);
    const float deltaMono = sqrt(5.991);

    {
        unique_lock<mutex> lock(MapPoint::mGlobalMutex);
     // 遍历地图点并添加边, 遍历当前帧的地图点，设置其观测边：获取地图点的观测坐标 obs 和对应误差信息。
    //  构建边 EdgeSE3ProjectXYZOnlyPose，仅优化位姿 (固定地图点)。设置误差权重矩阵和鲁棒核函数 (Huber)。
        for(int i=0; i<N; i++)
        {
            mpptr pMP = Frame.mvpMapPoints[i];
            if(pMP)
            {
                nInitialCorrespondences++;
                Frame.mvbOutlier[i] = false;

                Eigen::Matrix<double,2,1> obs;
                const cv::KeyPoint &kpUn = Frame.mvKeysUn[i];
                obs << kpUn.pt.x, kpUn.pt.y;

                g2o::EdgeSE3ProjectXYZOnlyPose* e = new g2o::EdgeSE3ProjectXYZOnlyPose();

                e->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(0)));
                e->setMeasurement(obs);
                const float invSigma2 = Frame.mvInvLevelSigma2[kpUn.octave];
                e->setInformation(Eigen::Matrix2d::Identity()*invSigma2);

                g2o::RobustKernelHuber* rk = new g2o::RobustKernelHuber;
                e->setRobustKernel(rk);
                rk->setDelta(deltaMono);

                e->fx = Frame.fx;
                e->fy = Frame.fy;
                e->cx = Frame.cx;
                e->cy = Frame.cy;
                cv::Mat Xw = pMP->GetWorldPos();
                e->Xw[0] = Xw.at<float>(0);
                e->Xw[1] = Xw.at<float>(1);
                e->Xw[2] = Xw.at<float>(2);

                optimizer.addEdge(e);

                vpEdgesMono.push_back(e);
                vnIndexEdgeMono.push_back(i);
            }
        }
    }


    if(nInitialCorrespondences<3)
        return 0;

    // We perform 4 optimizations, after each optimization we classify observation as inlier/outlier
    // At the next optimization, outliers are not included, but at the end they can be classified as inliers again.
    //执行优化,  进行 4 次迭代优化，每次迭代后重新分类内点和外点：根据误差阈值筛选外点，将其排除在下一次优化之外。
    // 在最后一次迭代中移除鲁棒核，进一步调整内点。
    const float chi2Mono[4]={5.991,5.991,5.991,5.991};
    const int its[4]={10,10,10,10};

    int nBad=0;
    for(size_t it=0; it<4; it++)
    {

        vSE3->setEstimate(Converter::toSE3Quat(Frame.mTcw));
        optimizer.initializeOptimization(0);
        optimizer.optimize(its[it]);

        nBad=0;
        for(size_t i=0, iend=vpEdgesMono.size(); i<iend; i++)
        {
            g2o::EdgeSE3ProjectXYZOnlyPose* e = vpEdgesMono[i];

            const size_t idx = vnIndexEdgeMono[i];

            if(Frame.mvbOutlier[idx])
            {
                e->computeError();
            }

            const float chi2 = e->chi2();

            if(chi2>chi2Mono[it])
            {
                Frame.mvbOutlier[idx]=true;
                e->setLevel(1);
                nBad++;
            }
            else
            {
                Frame.mvbOutlier[idx]=false;
                e->setLevel(0);
            }

            if(it==2)
                e->setRobustKernel(0);
        }

        if(optimizer.edges().size()<10)
            break;
    }

    // Recover optimized pose and return number of inliers
    //更新位姿和输出结果， 提取优化后的位姿
    g2o::VertexSE3Expmap* vSE3_recov = static_cast<g2o::VertexSE3Expmap*>(optimizer.vertex(0));
    g2o::SE3Quat SE3quat_recov = vSE3_recov->estimate();
    cv::Mat pose = Converter::toCvMat(SE3quat_recov);
    Frame.SetPose(pose);

   // 返回最终内点数量（有效匹配点），用于评估优化效果：内点数量较多表明优化效果良好，跟踪稳定。若内点较少，说明当前帧可能存在跟踪失败或初始化错误。
    return nInitialCorrespondences-nBad;
}



//定义了视觉 SLAM 系统中的 Local Bundle Adjustment, LBA）函数 Optimizer::LocalBundleAdjustmentClient()，用于优化当前关键帧及其邻域内的位姿和地图点
//该函数的主要任务是：
//提取局部子图： 从当前关键帧出发，确定邻域关键帧及其关联的地图点。
//构建优化图： 将局部关键帧和地图点作为顶点，设置观测关系作为边约束。
//执行优化： 最小化重投影误差，调整位姿和地图点坐标。
//更新优化结果： 将优化后的数据写回关键帧和地图点，同时剔除异常点和观测。
void Optimizer::LocalBundleAdjustmentClient(kfptr pKF, bool* pbStopFlag, mapptr pMap, size_t ClientId, eSystemState SysState)
{
    // Local KeyFrames: Breath First Search from Current Keyframe
    //提取局部关键帧和地图点, 搜索邻域关键帧, 从当前关键帧出发，通过共视关键帧确定局部区域。
    list<kfptr> lLocalKeyFrames;

    lLocalKeyFrames.push_back(pKF);
    pKF->mBALocalForKF = pKF->mId;

    const vector<kfptr> vNeighKFs = pKF->GetVectorCovisibleKeyFrames();
    for(int i=0, iend=vNeighKFs.size(); i<iend; i++)
    {
        kfptr pKFi = vNeighKFs[i];
        pKFi->mBALocalForKF = pKF->mId;
        if(!pKFi->isBad())
        {
            lLocalKeyFrames.push_back(pKFi);
        }
    }

    // Local MapPoints seen in Local KeyFrames
    //提取局部地图点，
    list<mpptr> lLocalMapPoints;
    for(list<kfptr>::iterator lit=lLocalKeyFrames.begin() , lend=lLocalKeyFrames.end(); lit!=lend; lit++)
    {
        vector<mpptr> vpMPs = (*lit)->GetMapPointMatches();
        for(vector<mpptr>::iterator vit=vpMPs.begin(), vend=vpMPs.end(); vit!=vend; vit++)
        {
            mpptr pMP = *vit;
            if(pMP)
                if(!pMP->isBad())
                    if(pMP->mBALocalForKF!=pKF->mId)
                    {
                        lLocalMapPoints.push_back(pMP);
                        pMP->mBALocalForKF=pKF->mId;
                    }
        }
    }

    // Fixed Keyframes. Keyframes that see Local MapPoints but that are not Local Keyframes
    //确定固定关键帧， 包含观察局部地图点但未被纳入局部关键帧的关键帧，用作边界条件。
    list<kfptr> lFixedCameras;
    for(list<mpptr>::iterator lit=lLocalMapPoints.begin(), lend=lLocalMapPoints.end(); lit!=lend; lit++)
    {
        map<kfptr,size_t> observations = (*lit)->GetObservations();
        for(map<kfptr,size_t>::iterator mit=observations.begin(), mend=observations.end(); mit!=mend; mit++)
        {
            kfptr pKFi = mit->first;

            if(pKFi->mBALocalForKF!=pKF->mId && pKFi->mBAFixedForKF!=pKF->mId)
            {
                pKFi->mBAFixedForKF=pKF->mId;
                if(!pKFi->isBad())
                {
                    lFixedCameras.push_back(pKFi);
                }
            }
        }
    }

    // Setup optimizer
    // 构建优化器，设置关键帧顶点
    g2o::SparseOptimizer optimizer;
    g2o::BlockSolver_6_3::LinearSolverType * linearSolver;
    linearSolver = new g2o::LinearSolverEigen<g2o::BlockSolver_6_3::PoseMatrixType>();
    g2o::BlockSolver_6_3 * solver_ptr = new g2o::BlockSolver_6_3(linearSolver);
    g2o::OptimizationAlgorithmLevenberg* solver = new g2o::OptimizationAlgorithmLevenberg(solver_ptr);
    optimizer.setAlgorithm(solver);

    if(pbStopFlag)
        optimizer.setForceStopFlag(pbStopFlag);

    // Set Local KeyFrame vertices
    for(list<kfptr>::iterator lit=lLocalKeyFrames.begin(), lend=lLocalKeyFrames.end(); lit!=lend; lit++)
    {
        kfptr pKFi = *lit;

        if(pKFi->mId.first >= IDRANGE)
        {
            cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m #1: In \"Optimizer::LocalBundleAdjustment(...)\": KF index out of bounds" << endl;
            throw infrastructure_ex();
        }

        g2o::VertexSE3Expmap * vSE3 = new g2o::VertexSE3Expmap();
        vSE3->setEstimate(Converter::toSE3Quat(pKFi->GetPose()));
        vSE3->setId(Optimizer::GetID(pKFi->mId,true));
        vSE3->setFixed(pKFi->mId.first == 0 && pKFi->mId.second == ClientId);
        optimizer.addVertex(vSE3);
    }

    // Set Fixed KeyFrame vertices
    for(list<kfptr>::iterator lit=lFixedCameras.begin(), lend=lFixedCameras.end(); lit!=lend; lit++)
    {
        kfptr pKFi = *lit;

        if(pKFi->mId.first >= IDRANGE)
        {
            cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m #1: In \"Optimizer::LocalBundleAdjustment(...)\": KF index out of bounds" << endl;
            throw infrastructure_ex();
        }

        g2o::VertexSE3Expmap * vSE3 = new g2o::VertexSE3Expmap();
        vSE3->setEstimate(Converter::toSE3Quat(pKFi->GetPose()));
        vSE3->setId(Optimizer::GetID(pKFi->mId,true));
        vSE3->setFixed(true);
        optimizer.addVertex(vSE3);
    }

    // Set MapPoint vertices
    const int nExpectedSize = (lLocalKeyFrames.size()+lFixedCameras.size())*lLocalMapPoints.size();

    vector<g2o::EdgeSE3ProjectXYZ*> vpEdgesMono;
    vpEdgesMono.reserve(nExpectedSize);

    vector<kfptr> vpEdgeKFMono;
    vpEdgeKFMono.reserve(nExpectedSize);

    vector<mpptr> vpMapPointEdgeMono;
    vpMapPointEdgeMono.reserve(nExpectedSize);

    const float thHuberMono = sqrt(5.991);

    for(list<mpptr>::iterator lit=lLocalMapPoints.begin(), lend=lLocalMapPoints.end(); lit!=lend; lit++)
    {
        mpptr pMP = *lit;

        if(pMP->mId.first >= IDRANGE)
        {
            cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m #1: In \"Optimizer::LocalBundleAdjustment(...)\": MP index out of bounds" << endl;
            throw infrastructure_ex();
        }

        g2o::VertexSBAPointXYZ* vPoint = new g2o::VertexSBAPointXYZ();
        vPoint->setEstimate(Converter::toVector3d(pMP->GetWorldPos()));
        const int id = Optimizer::GetID(pMP->mId,false);
        vPoint->setId(id);
        vPoint->setMarginalized(true);
        optimizer.addVertex(vPoint);

        const map<kfptr,size_t> observations = pMP->GetObservations();

        //Set edges
        for(map<kfptr,size_t>::const_iterator mit=observations.begin(), mend=observations.end(); mit!=mend; mit++)
        {
            kfptr pKFi = mit->first;

            if(pKFi->mId.first >= IDRANGE)
            {
                cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m #1: In \"Optimizer::LocalBundleAdjustment(...)\": KF index out of bounds" << endl;
                throw infrastructure_ex();
            }

            if(!pKFi->isBad())
            {
                const cv::KeyPoint &kpUn = pKFi->mvKeysUn[mit->second];

                Eigen::Matrix<double,2,1> obs;
                obs << kpUn.pt.x, kpUn.pt.y;

                g2o::EdgeSE3ProjectXYZ* e = new g2o::EdgeSE3ProjectXYZ();

                e->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(id)));
                e->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(Optimizer::GetID(pKFi->mId,true))));
                e->setMeasurement(obs);
                const float &invSigma2 = pKFi->mvInvLevelSigma2[kpUn.octave];
                e->setInformation(Eigen::Matrix2d::Identity()*invSigma2);

                g2o::RobustKernelHuber* rk = new g2o::RobustKernelHuber;
                e->setRobustKernel(rk);
                rk->setDelta(thHuberMono);

                e->fx = pKFi->fx;
                e->fy = pKFi->fy;
                e->cx = pKFi->cx;
                e->cy = pKFi->cy;

                optimizer.addEdge(e);
                vpEdgesMono.push_back(e);
                vpEdgeKFMono.push_back(pKFi);
                vpMapPointEdgeMono.push_back(pMP);
            }
        }
    }

    if(pbStopFlag)
        if(*pbStopFlag)
            return;

    optimizer.initializeOptimization();
    optimizer.optimize(5);

    bool bDoMore= true;

    if(pbStopFlag)
        if(*pbStopFlag)
            bDoMore = false;

    if(bDoMore)
    {
        // Check inlier observations
        for(size_t i=0, iend=vpEdgesMono.size(); i<iend;i++)
        {
            g2o::EdgeSE3ProjectXYZ* e = vpEdgesMono[i];
            mpptr pMP = vpMapPointEdgeMono[i];

            if(pMP->isBad())
                continue;

            if(e->chi2()>5.991 || !e->isDepthPositive())
            {
                e->setLevel(1);
            }

            e->setRobustKernel(0);
        }

        // Optimize again without the outliers

        optimizer.initializeOptimization(0);
        optimizer.optimize(10);
    }

    vector<pair<kfptr,mpptr> > vToErase;
    vToErase.reserve(vpEdgesMono.size());

    // Check inlier observations
    for(size_t i=0, iend=vpEdgesMono.size(); i<iend;i++)
    {
        g2o::EdgeSE3ProjectXYZ* e = vpEdgesMono[i];
        mpptr pMP = vpMapPointEdgeMono[i];

        if(pMP->isBad())
            continue;

        if(e->chi2()>5.991 || !e->isDepthPositive())
        {
            kfptr pKFi = vpEdgeKFMono[i];
            vToErase.push_back(make_pair(pKFi,pMP));
        }
    }

    // Get Map Mutex
    if(SysState != eSystemState::SERVER)
        while(!pMap->LockMapUpdate()){usleep(params::timings::miLockSleep);}

    if(!vToErase.empty())
    {
        for(size_t i=0;i<vToErase.size();i++)
        {
            kfptr pKFi = vToErase[i].first;
            mpptr pMPi = vToErase[i].second;
            pKFi->EraseMapPointMatch(pMPi);
            pMPi->EraseObservation(pKFi);
        }
    }

    // Recover optimized data

    //Keyframes
    for(list<kfptr>::iterator lit=lLocalKeyFrames.begin(), lend=lLocalKeyFrames.end(); lit!=lend; lit++)
    {
        kfptr pKF = *lit;
        g2o::VertexSE3Expmap* vSE3 = static_cast<g2o::VertexSE3Expmap*>(optimizer.vertex(Optimizer::GetID(pKF->mId,true)));
        g2o::SE3Quat SE3quat = vSE3->estimate();

        pKF->SetPose(Converter::toCvMat(SE3quat),false);

        pKF->mbUpdatedByServer = false;
    }

    //Points
    for(list<mpptr>::iterator lit=lLocalMapPoints.begin(), lend=lLocalMapPoints.end(); lit!=lend; lit++)
    {
        mpptr pMP = *lit;
        if(pMP->isBad())
        {
            //maybe observations were erased by BA, and now MP has become bad
            mpptr pMPcheck = pMap->GetMpPtr(pMP->mId);
            if(pMPcheck)
            {
                cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m " << __func__ << ":" << __LINE__ << " MP bad but not erased from map" << endl;
                throw estd::infrastructure_ex();
            }
        }
        else
        {
            g2o::VertexSBAPointXYZ* vPoint = static_cast<g2o::VertexSBAPointXYZ*>(optimizer.vertex(Optimizer::GetID(pMP->mId,false)));
            pMP->SetWorldPos(Converter::toCvMat(vPoint->estimate()),false);
            pMP->UpdateNormalAndDepth();
        }
    }

    if(SysState != eSystemState::SERVER)
    {
        pMap->UnLockMapUpdate();
    }
}


//该函数的主要任务是：
//地图准备阶段： 收集所有关键帧和地图点，检查数据一致性，并设置固定参考帧。
//构建优化图： 将关键帧和地图点作为顶点，设置观测约束为边，定义优化目标。
//执行全局捆绑调整： 使用非线性最小二乘优化（基于 g2o），最小化重投影误差，调整位姿和地图点坐标。
//结果恢复阶段： 更新优化后的关键帧和地图点，同时考虑回环检测后的特定处理。

void Optimizer::MapFusionGBA(mapptr pMap, size_t ClientId, int nIterations, bool* pbStopFlag, idpair nLoopKF, const bool bRobust)
{
    stringstream* ss;
    ss = new stringstream;
    //日志输出： 打印当前优化地图 ID 和参与客户端（机器人）ID。
    for(set<size_t>::iterator sit = pMap->msuAssClients.begin();sit != pMap->msuAssClients.end();++sit)
        *ss << *sit << ";";
    cout << "--> Optimizing Map " << pMap->mMapId << " -- Contains Agents " << ss->str() << endl;
    cout << "----> Loop KF: " << nLoopKF.first << "|" << nLoopKF.second << endl;
    delete ss;


    //prepare structures
   // 获取关键帧和地图点, 从地图对象中提取所有关键帧和地图点，为后续优化准备数据集。
    vector<kfptr> vpKFs = pMap->GetAllKeyFrames();
    vector<mpptr> vpMP = pMap->GetAllMapPoints();

    const idpair zeropair = make_pair(0,pMap->mMapId);

    if(pMap->mvpKeyFrameOrigins.empty())
    {
        cout << "\033[1;31m!!!!! ERROR !!!!!\033[0m " << __func__ << __LINE__ << " pMap->mvpKeyFrameOrigins.empty()" << endl;
        throw infrastructure_ex();
    }

  //设置固定关键帧, 选择第一个关键帧作为固定帧（不可调整位姿），提供全局优化的基准约束，防止整体漂移。
    idpair FixedId = (*(pMap->mvpKeyFrameOrigins.begin()))->mId;

    //GBA

    vector<bool> vbNotIncludedMP;
    vbNotIncludedMP.resize(vpMP.size(),false);

    g2o::SparseOptimizer optimizer;
    g2o::BlockSolver_6_3::LinearSolverType * linearSolver;
    linearSolver = new g2o::LinearSolverEigen<g2o::BlockSolver_6_3::PoseMatrixType>();
    g2o::BlockSolver_6_3 * solver_ptr = new g2o::BlockSolver_6_3(linearSolver);
    g2o::OptimizationAlgorithmLevenberg* solver = new g2o::OptimizationAlgorithmLevenberg(solver_ptr);
    optimizer.setAlgorithm(solver);

    if(pbStopFlag)
        optimizer.setForceStopFlag(pbStopFlag);

    size_t maxKFid = 0;
    size_t vertices = 0;
    size_t edges = 0;

    // Set KeyFrame vertices
    cout << "----- Add KFs" << endl;
    for(size_t i=0; i<vpKFs.size(); i++)
    {
        kfptr pKF = vpKFs[i];
        if(pKF->isBad())
            continue;
        g2o::VertexSE3Expmap * vSE3 = new g2o::VertexSE3Expmap();
        vSE3->setEstimate(Converter::toSE3Quat(pKF->GetPose()));
        vSE3->setId(pKF->mUniqueId);

        vSE3->setFixed(pKF->mId==FixedId);
        optimizer.addVertex(vSE3);
        vertices++;;
        if(pKF->mUniqueId>maxKFid)
            maxKFid=pKF->mUniqueId;
    }

    const float thHuber2D = sqrt(5.99);

    // Set MapPoint vertices
    cout << "----- Add MPs" << endl;
    for(size_t i=0; i<vpMP.size(); i++)
    {
        mpptr pMP = vpMP[i];
        if(pMP->isBad())
            continue;

        const map<kfptr,size_t> observations = pMP->GetObservations();
        if (observations.size() < 2) {
          vbNotIncludedMP[i] = true;
          continue;
        }
        int nEdges = 0;
        const size_t id = pMP->mUniqueId;

        // Do a pre-check to ensure at least 2 proper observations
        for(map<kfptr,size_t>::const_iterator mit = observations.begin(); mit != observations.end(); ++mit) {
          kfptr pKF = mit->first;
          if(!pKF || pKF->isBad() || pKF->mUniqueId>maxKFid) continue;
          nEdges++;
        }

        if (nEdges < 2) {
          vbNotIncludedMP[i] = true;
          continue;
        }

        g2o::VertexSBAPointXYZ* vPoint = new g2o::VertexSBAPointXYZ();
        vPoint->setEstimate(Converter::toVector3d(pMP->GetWorldPos()));

        vPoint->setId(id);

        vPoint->setMarginalized(true);
        optimizer.addVertex(vPoint);

        //SET EDGES
        for(map<kfptr,size_t>::const_iterator mit=observations.begin(); mit!=observations.end(); mit++)
        {

            kfptr pKF = mit->first;
            if(!pKF || pKF->isBad() || pKF->mUniqueId>maxKFid)
                continue;

            const cv::KeyPoint &kpUn = pKF->mvKeysUn[mit->second];


            Eigen::Matrix<double,2,1> obs;
            obs << kpUn.pt.x, kpUn.pt.y;

            g2o::EdgeSE3ProjectXYZ* e = new g2o::EdgeSE3ProjectXYZ();

            e->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(id)));
            e->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(pKF->mUniqueId)));
            e->setMeasurement(obs);
            const float &invSigma2 = pKF->mvInvLevelSigma2[kpUn.octave];
            e->setInformation(Eigen::Matrix2d::Identity()*invSigma2);

            if(bRobust)
            {
                g2o::RobustKernelHuber* rk = new g2o::RobustKernelHuber;
                e->setRobustKernel(rk);
                rk->setDelta(thHuber2D);
            }

            e->fx = pKF->fx;
            e->fy = pKF->fy;
            e->cx = pKF->cx;
            e->cy = pKF->cy;

            optimizer.addEdge(e);
            edges++;
        }
    }

    // Optimize!
    cout << "----- Optimize" << endl;
    optimizer.initializeOptimization();
    optimizer.initMultiThreading();
    std::cout << "------> max Iterations: " << nIterations << std::endl;
    std::cout << "------> vertices|edges: " << vertices << "|" << edges << std::endl;

    auto start = std::chrono::system_clock::now();
    optimizer.optimize(nIterations);
    auto end = std::chrono::system_clock::now();

    std::chrono::duration<double> elapsed_seconds = end-start;
    std::cout << "------> Optimization Time: " << elapsed_seconds.count() << " [s]" << std::endl;

    // Recover optimized data

    //Keyframes
    cout << "----- Recover KFs" << endl;
    for(size_t i=0; i<vpKFs.size(); i++)
    {
        kfptr pKF = vpKFs[i];
        if(pKF->isBad())
            continue;

        g2o::VertexSE3Expmap* vSE3 = static_cast<g2o::VertexSE3Expmap*>(optimizer.vertex(pKF->mUniqueId));
        g2o::SE3Quat SE3quat = vSE3->estimate();

        if(nLoopKF==zeropair)
        {
            pKF->SetPose(Converter::toCvMat(SE3quat),true);
        }
        else
        {
            pKF->mTcwGBA.create(4,4,CV_32F);
            Converter::toCvMat(SE3quat).copyTo(pKF->mTcwGBA);
            pKF->mBAGlobalForKF = nLoopKF;
        }
    }

    //Points
    cout << "----- Recover MPs" << endl;
    for(size_t i=0; i<vpMP.size(); i++)
    {
        if(vbNotIncludedMP[i])
            continue;

        mpptr pMP = vpMP[i];

        if(pMP->isBad())
            continue;

        g2o::VertexSBAPointXYZ* vPoint = static_cast<g2o::VertexSBAPointXYZ*>(optimizer.vertex(pMP->mUniqueId));

        if(nLoopKF==zeropair)
        {
            pMP->SetWorldPos(Converter::toCvMat(vPoint->estimate()),true);
            pMP->UpdateNormalAndDepth();
        }
        else
        {
            pMP->mPosGBA.create(3,1,CV_32F);
            if(vPoint->estimate().rows() != 3 || vPoint->estimate().cols() != 1) {
                std::cout << COUTWARN << "vPoint->estimate().rows() != 3 || vPoint->estimate().cols() != 1" << std::endl;
                continue;
            }
            Converter::toCvMat(vPoint->estimate()).copyTo(pMP->mPosGBA);
            pMP->mBAGlobalForKF = nLoopKF;
        }
    }
    cout << "----- done." << endl;
}


//实现了 Sim3 优化函数 Optimizer::OptimizeSim3()，用于估计两关键帧之间的 Sim3 变换（相似变换），以处理尺度变化和位姿调整。
//优化两关键帧之间的 Sim3（包含旋转、平移和尺度）的变换关系，并移除异常匹配点，提高相对位姿估计的精度和鲁棒性。
//适用场景：地图合并： 多机器人或分布式 SLAM 中需要对齐两张地图时。回环检测： 使用 Sim3 变换纠正位姿和尺度偏差。
int Optimizer::OptimizeSim3(kfptr pKF1, kfptr pKF2, std::vector<mpptr> &vpMatches1, g2o::Sim3 &g2oS12, const float th2, bool bFixScale)
{
    g2o::SparseOptimizer optimizer;
    g2o::BlockSolverX::LinearSolverType * linearSolver;

    linearSolver = new g2o::LinearSolverDense<g2o::BlockSolverX::PoseMatrixType>();

    g2o::BlockSolverX * solver_ptr = new g2o::BlockSolverX(linearSolver);

    g2o::OptimizationAlgorithmLevenberg* solver = new g2o::OptimizationAlgorithmLevenberg(solver_ptr);
    optimizer.setAlgorithm(solver);

    // Calibration
    const cv::Mat &K1 = pKF1->mK;
    const cv::Mat &K2 = pKF2->mK;

    // Camera poses
    const cv::Mat R1w = pKF1->GetRotation();
    const cv::Mat t1w = pKF1->GetTranslation();
    const cv::Mat R2w = pKF2->GetRotation();
    const cv::Mat t2w = pKF2->GetTranslation();

    // Set Sim3 vertex
    // 设置 Sim3 顶点
    g2o::VertexSim3Expmap * vSim3 = new g2o::VertexSim3Expmap();
    vSim3->_fix_scale=bFixScale;
    vSim3->setEstimate(g2oS12);
    vSim3->setId(0);
    vSim3->setFixed(false);
    //设置相机参数, 读取两帧的内参矩阵，设置焦距和主点坐标，确保投影计算精确。
    vSim3->_principle_point1[0] = K1.at<float>(0,2);
    vSim3->_principle_point1[1] = K1.at<float>(1,2);
    vSim3->_focal_length1[0] = K1.at<float>(0,0);
    vSim3->_focal_length1[1] = K1.at<float>(1,1);
    vSim3->_principle_point2[0] = K2.at<float>(0,2);
    vSim3->_principle_point2[1] = K2.at<float>(1,2);
    vSim3->_focal_length2[0] = K2.at<float>(0,0);
    vSim3->_focal_length2[1] = K2.at<float>(1,1);
    optimizer.addVertex(vSim3);

    // Set MapPoint vertices
    const int N = vpMatches1.size();
    const vector<mpptr> vpMapPoints1 = pKF1->GetMapPointMatches();
    //设置地图点顶点及边约束,将两帧中对应的地图点添加为顶点：将地图点坐标从世界坐标系转换到相机坐标系，并设置为固定顶点。
    vector<g2o::EdgeSim3ProjectXYZ*> vpEdges12;
    vector<g2o::EdgeInverseSim3ProjectXYZ*> vpEdges21;
    vector<size_t> vnIndexEdge;

    vnIndexEdge.reserve(2*N);
    vpEdges12.reserve(2*N);
    vpEdges21.reserve(2*N);

    const float deltaHuber = sqrt(th2);

    int nCorrespondences = 0;

    for(int i=0; i<N; i++)
    {
        if(!vpMatches1[i])
            continue;

        mpptr pMP1 = vpMapPoints1[i];
        mpptr pMP2 = vpMatches1[i];

        const int id1 = 2*i+1;
        const int id2 = 2*(i+1);

        const int i2 = pMP2->GetIndexInKeyFrame(pKF2);

        if(pMP1 && pMP2)
        {
            if(!pMP1->isBad() && !pMP2->isBad() && i2>=0)
            {
                g2o::VertexSBAPointXYZ* vPoint1 = new g2o::VertexSBAPointXYZ();
                cv::Mat P3D1w = pMP1->GetWorldPos();
                cv::Mat P3D1c = R1w*P3D1w + t1w;
                vPoint1->setEstimate(Converter::toVector3d(P3D1c));
                vPoint1->setId(id1);
                vPoint1->setFixed(true);
                optimizer.addVertex(vPoint1);

                g2o::VertexSBAPointXYZ* vPoint2 = new g2o::VertexSBAPointXYZ();
                cv::Mat P3D2w = pMP2->GetWorldPos();
                cv::Mat P3D2c = R2w*P3D2w + t2w;
                vPoint2->setEstimate(Converter::toVector3d(P3D2c));
                vPoint2->setId(id2);
                vPoint2->setFixed(true);
                optimizer.addVertex(vPoint2);
            }
            else
                continue;
        }
        else
            continue;

        nCorrespondences++;

        // Set edge x1 = S12*X2
        Eigen::Matrix<double,2,1> obs1;
        const cv::KeyPoint &kpUn1 = pKF1->mvKeysUn[i];
        obs1 << kpUn1.pt.x, kpUn1.pt.y;

        //添加边约束, 添加边约束：定义地图点与投影观测之间的误差函数：
        //前向边 (EdgeSim3ProjectXYZ): 将关键帧 2 中的地图点投影到关键帧 1 的坐标系。
        //反向边 (EdgeInverseSim3ProjectXYZ): 将关键帧 1 中的地图点投影到关键帧 2 的坐标系。
        g2o::EdgeSim3ProjectXYZ* e12 = new g2o::EdgeSim3ProjectXYZ();
        e12->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(id2)));
        e12->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(0)));
        e12->setMeasurement(obs1);
        const float &invSigmaSquare1 = pKF1->mvInvLevelSigma2[kpUn1.octave];
        e12->setInformation(Eigen::Matrix2d::Identity()*invSigmaSquare1);

       //使用 Huber 损失函数 处理异常值，减少误匹配点对优化的影响。
        g2o::RobustKernelHuber* rk1 = new g2o::RobustKernelHuber;
        e12->setRobustKernel(rk1);
        rk1->setDelta(deltaHuber);
        optimizer.addEdge(e12);

        // Set edge x2 = S21*X1
        Eigen::Matrix<double,2,1> obs2;
        const cv::KeyPoint &kpUn2 = pKF2->mvKeysUn[i2];
        obs2 << kpUn2.pt.x, kpUn2.pt.y;

        g2o::EdgeInverseSim3ProjectXYZ* e21 = new g2o::EdgeInverseSim3ProjectXYZ();

        e21->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(id1)));
        e21->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(0)));
        e21->setMeasurement(obs2);
        float invSigmaSquare2 = pKF2->mvInvLevelSigma2[kpUn2.octave];
        e21->setInformation(Eigen::Matrix2d::Identity()*invSigmaSquare2);

        g2o::RobustKernelHuber* rk2 = new g2o::RobustKernelHuber;
        e21->setRobustKernel(rk2);
        rk2->setDelta(deltaHuber);
        optimizer.addEdge(e21);

        vpEdges12.push_back(e12);
        vpEdges21.push_back(e21);
        vnIndexEdge.push_back(i);
    }

    // Optimize!
    //执行 5 次初步优化，调整 Sim3 变换及位姿误差。
    optimizer.initializeOptimization();
    optimizer.optimize(5);

    // Check inliers
    //剔除外点, 根据误差阈值 (th2) 检测并移除外点，同时从优化图中删除对应边。
    int nBad=0;
    for(size_t i=0; i<vpEdges12.size();i++)
    {
        g2o::EdgeSim3ProjectXYZ* e12 = vpEdges12[i];
        g2o::EdgeInverseSim3ProjectXYZ* e21 = vpEdges21[i];
        if(!e12 || !e21)
            continue;
        
        if(e12->chi2()>th2 || e21->chi2()>th2)
        {
            size_t idx = vnIndexEdge[i];
            vpMatches1[idx]=static_cast<mpptr>(NULL);
            optimizer.removeEdge(e12);
            optimizer.removeEdge(e21);
            vpEdges12[i]=static_cast<g2o::EdgeSim3ProjectXYZ*>(NULL);
            vpEdges21[i]=static_cast<g2o::EdgeInverseSim3ProjectXYZ*>(NULL);
            nBad++;
        }
    }

    int nMoreIterations;
    if(nBad>0)
        nMoreIterations=10;
    else
        nMoreIterations=5;

    if(nCorrespondences-nBad<10)
        return 0;

    // Optimize again only with inliers
    //根据外点数量，进一步优化 5–10 次，确保最终结果更加稳定。
    optimizer.initializeOptimization();
    optimizer.optimize(nMoreIterations);

    int nIn = 0;
    for(size_t i=0; i<vpEdges12.size();i++)
    {
        g2o::EdgeSim3ProjectXYZ* e12 = vpEdges12[i];
        g2o::EdgeInverseSim3ProjectXYZ* e21 = vpEdges21[i];
        if(!e12 || !e21)
            continue;

        if(e12->chi2()>th2 || e21->chi2()>th2)
        {
            size_t idx = vnIndexEdge[i];
            vpMatches1[idx]=static_cast<mpptr>(NULL);
        }
        else
            nIn++;
    }

    // Recover optimized Sim3
    // 恢复优化结果， 提取优化后的 Sim3 变换 g2oS12 并返回内点数量，用于评估优化质量。
    g2o::VertexSim3Expmap* vSim3_recov = static_cast<g2o::VertexSim3Expmap*>(optimizer.vertex(0));
    g2oS12= vSim3_recov->estimate();

    return nIn;
}


//  基于回环检测的本质图优化 (Essential Graph Optimization with Loop Closure)，用于通过回环检测来优化关键帧和地图点的全局一致性，减少累积误差。
//核心任务：优化位姿和尺度： 使用 Sim3 变换对回环检测中的关键帧和地图点进行对齐和优化，确保全局一致性。
//消除漂移： 通过最小化关键帧之间的 Sim3 变换误差，减少长时间运行或大规模 SLAM 中的漂移现象。
//地图点更新： 根据优化后的关键帧位置调整地图点的位置，提高建图精度。
//通过回环检测优化所有关键帧和地图点的 全局一致性。
void Optimizer::OptimizeEssentialGraphLoopClosure(mapptr pMap, kfptr pLoopKF, kfptr pCurKF,
                                       const KeyFrameAndPose &NonCorrectedSim3,
                                       const KeyFrameAndPose &CorrectedSim3,
                                       const map<kfptr, set<kfptr> > &LoopConnections, const bool &bFixScale)
{
    // Setup optimizer
    g2o::SparseOptimizer optimizer;
    optimizer.setVerbose(false);
    g2o::BlockSolver_7_3::LinearSolverType * linearSolver =
           new g2o::LinearSolverEigen<g2o::BlockSolver_7_3::PoseMatrixType>();
    g2o::BlockSolver_7_3 * solver_ptr= new g2o::BlockSolver_7_3(linearSolver);
    g2o::OptimizationAlgorithmLevenberg* solver = new g2o::OptimizationAlgorithmLevenberg(solver_ptr);

    solver->setUserLambdaInit(1e-16);
    optimizer.setAlgorithm(solver);

    const vector<kfptr> vpKFs = pMap->GetAllKeyFrames();
    const vector<mpptr> vpMPs = pMap->GetAllMapPoints();

    const unsigned int nMaxKFid = pMap->GetMaxKFidUnique(); //vpKFs.size();

    vector<g2o::Sim3,Eigen::aligned_allocator<g2o::Sim3> > vScw(nMaxKFid+1);
    vector<g2o::Sim3,Eigen::aligned_allocator<g2o::Sim3> > vCorrectedSwc(nMaxKFid+1);
    vector<g2o::VertexSim3Expmap*> vpVertices(nMaxKFid+1);

    const int minFeat = params::opt::miEssGraphMinFeats;

    // Set KeyFrame vertices
    for(size_t i=0, iend=vpKFs.size(); i<iend;i++)
    {
        kfptr pKF = vpKFs[i];
        if(pKF->isBad())
            continue;
        g2o::VertexSim3Expmap* VSim3 = new g2o::VertexSim3Expmap();

        const size_t nIDi = pKF->mUniqueId;

        KeyFrameAndPose::const_iterator it = CorrectedSim3.find(pKF);

        if(it!=CorrectedSim3.end())
        {
            vScw[nIDi] = it->second;
            VSim3->setEstimate(it->second);
        }
        else
        {
            Eigen::Matrix<double,3,3> Rcw = Converter::toMatrix3d(pKF->GetRotation());
            Eigen::Matrix<double,3,1> tcw = Converter::toVector3d(pKF->GetTranslation());
            g2o::Sim3 Siw(Rcw,tcw,1.0);
            vScw[nIDi] = Siw;
            VSim3->setEstimate(Siw);
        }

        if(pKF==pLoopKF)
            VSim3->setFixed(true);

        VSim3->setId(nIDi);
        VSim3->setMarginalized(false);
        VSim3->_fix_scale = bFixScale;

        optimizer.addVertex(VSim3);

        vpVertices[nIDi]=VSim3;
    }

    set<pair<long unsigned int,long unsigned int> > sInsertedEdges;

    const Eigen::Matrix<double,7,7> matLambda = Eigen::Matrix<double,7,7>::Identity();

    // Set Loop edges
    for(map<kfptr , set<kfptr > >::const_iterator mit = LoopConnections.begin(), mend=LoopConnections.end(); mit!=mend; mit++)
    {
        kfptr pKF = mit->first;

        if(pKF->isBad()) continue;

        const size_t nIDi = pKF->mUniqueId;

        const set<kfptr> &spConnections = mit->second;
        const g2o::Sim3 Siw = vScw[nIDi];
        const g2o::Sim3 Swi = Siw.inverse();

        for(set<kfptr>::const_iterator sit=spConnections.begin(), send=spConnections.end(); sit!=send; sit++)
        {
            if((*sit)->isBad()) continue;
            const size_t nIDj = (*sit)->mUniqueId;

            if((nIDi!=pCurKF->mUniqueId || nIDj!=pLoopKF->mUniqueId) && pKF->GetWeight(*sit)<minFeat)
                continue;

            const g2o::Sim3 Sjw = vScw[nIDj];
            const g2o::Sim3 Sji = Sjw * Swi;

            g2o::EdgeSim3* e = new g2o::EdgeSim3();
            e->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDj)));
            e->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDi)));
            e->setMeasurement(Sji);

            e->information() = matLambda;

            optimizer.addEdge(e);

            sInsertedEdges.insert(make_pair(min(nIDi,nIDj),max(nIDi,nIDj)));
        }
    }

    // Set normal edges
    for(size_t i=0, iend=vpKFs.size(); i<iend; i++)
    {
        kfptr pKF = vpKFs[i];

        const size_t nIDi = pKF->mUniqueId;

        g2o::Sim3 Swi;

        KeyFrameAndPose::const_iterator iti = NonCorrectedSim3.find(pKF);

        if(iti!=NonCorrectedSim3.end())
            Swi = (iti->second).inverse();
        else
            Swi = vScw[nIDi].inverse();

        kfptr pParentKF = pKF->GetParent();

        // Spanning tree edge
        if(pParentKF)
        {
            const size_t nIDj = pParentKF->mUniqueId;

            g2o::Sim3 Sjw;

            KeyFrameAndPose::const_iterator itj = NonCorrectedSim3.find(pParentKF);

            if(itj!=NonCorrectedSim3.end())
                Sjw = itj->second;
            else
                Sjw = vScw[nIDj];

            g2o::Sim3 Sji = Sjw * Swi;

            g2o::EdgeSim3* e = new g2o::EdgeSim3();
            e->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDj)));
            e->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDi)));
            e->setMeasurement(Sji);

            e->information() = matLambda;
            optimizer.addEdge(e);
        }

        // Loop edges
        const set<kfptr> sLoopEdges = pKF->GetLoopEdges();
        for(set<kfptr>::const_iterator sit=sLoopEdges.begin(), send=sLoopEdges.end(); sit!=send; sit++)
        {
            kfptr pLKF = *sit;

            const size_t nIDj = pLKF->mUniqueId;

            if(nIDj<nIDi)
            {
                g2o::Sim3 Slw;

                KeyFrameAndPose::const_iterator itl = NonCorrectedSim3.find(pLKF);

                if(itl!=NonCorrectedSim3.end())
                    Slw = itl->second;
                else
                    Slw = vScw[nIDj];

                g2o::Sim3 Sli = Slw * Swi;
                g2o::EdgeSim3* el = new g2o::EdgeSim3();
                el->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDj)));
                el->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDi)));
                el->setMeasurement(Sli);
                el->information() = matLambda;
                optimizer.addEdge(el);
            }
        }

        // Covisibility graph edges
        const vector<kfptr> vpConnectedKFs = pKF->GetCovisiblesByWeight(minFeat);
        for(vector<kfptr>::const_iterator vit=vpConnectedKFs.begin(); vit!=vpConnectedKFs.end(); vit++)
        {
            kfptr pKFn = *vit;

            if((*vit)->isBad()) continue;

            if(pKFn && pKFn!=pParentKF && !pKF->hasChild(pKFn) && !sLoopEdges.count(pKFn))
            {
                const size_t nIDj = pKFn->mUniqueId;

                if(!pKFn->isBad() && nIDj<nIDi)
                {
                    if(sInsertedEdges.count(make_pair(min(nIDi,nIDj),max(nIDi,nIDj))))
                        continue;

                    g2o::Sim3 Snw;

                    KeyFrameAndPose::const_iterator itn = NonCorrectedSim3.find(pKFn);

                    if(itn!=NonCorrectedSim3.end())
                        Snw = itn->second;
                    else
                        Snw = vScw[nIDj];

                    g2o::Sim3 Sni = Snw * Swi;

                    g2o::EdgeSim3* en = new g2o::EdgeSim3();
                    en->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDj)));
                    en->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDi)));
                    en->setMeasurement(Sni);
                    en->information() = matLambda;
                    optimizer.addEdge(en);
                }
            }
        }
    }

    // Optimize!
    optimizer.initializeOptimization();
    optimizer.optimize(20);

    // SE3 Pose Recovering. Sim3:[sR t;0 1] -> SE3:[R t/s;0 1]
    for(size_t i=0;i<vpKFs.size();i++)
    {
        kfptr pKFi = vpKFs[i];

        const size_t nIDi = pKFi->mUniqueId;

        g2o::VertexSim3Expmap* VSim3 = static_cast<g2o::VertexSim3Expmap*>(optimizer.vertex(pKFi->mUniqueId));
        g2o::Sim3 CorrectedSiw =  VSim3->estimate();
        vCorrectedSwc[nIDi]=CorrectedSiw.inverse();
        Eigen::Matrix3d eigR = CorrectedSiw.rotation().toRotationMatrix();
        Eigen::Vector3d eigt = CorrectedSiw.translation();
        double s = CorrectedSiw.scale();

        eigt *=(1./s); //[R t/s;0 1]  // 对一个变量 eigt 进行缩放操作。将 eigt 的每个元素乘以 1/s，其中 s 是一个非零的数值。

        cv::Mat Tiw = Converter::toCvSE3(eigR,eigt);

        pKFi->SetPose(Tiw,true);
    }

    // Correct points. Transform to "non-optimized" reference keyframe pose and transform back with optimized pose
    for(size_t i=0, iend=vpMPs.size(); i<iend; i++)
    {
        mpptr pMP = vpMPs[i];

        if(pMP->isBad())
            continue;

        size_t nIDr;
        if(pMP->mCorrectedByKF_LC==pCurKF->mId)
        {
            nIDr = pMP->mCorrectedReference_LC;
        }
        else
        {
            kfptr pRefKF = pMP->GetReferenceKeyFrame();
            nIDr = pRefKF->mUniqueId;
        }

        g2o::Sim3 Srw = vScw[nIDr];
        g2o::Sim3 correctedSwr = vCorrectedSwc[nIDr];

        cv::Mat P3Dw = pMP->GetWorldPos();
        Eigen::Matrix<double,3,1> eigP3Dw = Converter::toVector3d(P3Dw);
        Eigen::Matrix<double,3,1> eigCorrectedP3Dw = correctedSwr.map(Srw.map(eigP3Dw));

        cv::Mat cvCorrectedP3Dw = Converter::toCvMat(eigCorrectedP3Dw);
        pMP->SetWorldPos(cvCorrectedP3Dw,true);

        pMP->UpdateNormalAndDepth();
    }
}


//实现了 基于本质图的地图融合优化 (Essential Graph Optimization for Map Fusion)。
//主要任务：在多地图合并或回环检测后，通过 Sim(3) 优化关键帧之间的全局一致性。
//同时优化关键帧和地图点的位姿与位置，确保地图整体一致性。支持尺度不固定 (bFixScale = false) 或固定尺度 (bFixScale = true) 的场景，适应不同应用需求。

void Optimizer::OptimizeEssentialGraphMapFusion(mapptr pMap, kfptr pLoopKF, kfptr pCurKF,
                                                  const map<kfptr, set<kfptr> > &LoopConnections, const bool &bFixScale)
{
    // Setup optimizer
    g2o::SparseOptimizer optimizer;
    optimizer.setVerbose(false);
    g2o::BlockSolver_7_3::LinearSolverType * linearSolver =
           new g2o::LinearSolverEigen<g2o::BlockSolver_7_3::PoseMatrixType>();
    g2o::BlockSolver_7_3 * solver_ptr= new g2o::BlockSolver_7_3(linearSolver);
    g2o::OptimizationAlgorithmLevenberg* solver = new g2o::OptimizationAlgorithmLevenberg(solver_ptr);

    solver->setUserLambdaInit(1e-16);
    optimizer.setAlgorithm(solver);

    const vector<kfptr> vpKFs = pMap->GetAllKeyFrames();
    const vector<mpptr> vpMPs = pMap->GetAllMapPoints();

    const unsigned int nMaxKFid = pMap->GetMaxKFidUnique();

    vector<g2o::Sim3,Eigen::aligned_allocator<g2o::Sim3> > vScw(nMaxKFid+1);
    vector<g2o::Sim3,Eigen::aligned_allocator<g2o::Sim3> > vCorrectedSwc(nMaxKFid+1);
    vector<g2o::VertexSim3Expmap*> vpVertices(nMaxKFid+1);

    const int minFeat = params::opt::miEssGraphMinFeats;

    // Set KeyFrame vertices
    for(size_t i=0, iend=vpKFs.size(); i<iend;i++)
    {
        kfptr pKF = vpKFs[i];
        if(pKF->isBad())
            continue;
        g2o::VertexSim3Expmap* VSim3 = new g2o::VertexSim3Expmap();

        const size_t nIDi = pKF->mUniqueId;

        Eigen::Matrix<double,3,3> Rcw = Converter::toMatrix3d(pKF->GetRotation());
        Eigen::Matrix<double,3,1> tcw = Converter::toVector3d(pKF->GetTranslation());
        g2o::Sim3 Siw(Rcw,tcw,1.0);
        vScw[nIDi] = Siw;
        VSim3->setEstimate(Siw);

        if(pKF==pLoopKF)
            VSim3->setFixed(true);

        VSim3->setId(nIDi);
        VSim3->setMarginalized(false);
        VSim3->_fix_scale = bFixScale;

        optimizer.addVertex(VSim3);

        vpVertices[nIDi]=VSim3;
    }

    set<pair<long unsigned int,long unsigned int> > sInsertedEdges;

    const Eigen::Matrix<double,7,7> matLambda = Eigen::Matrix<double,7,7>::Identity();

    // Set Loop edges
    //设置边约束, 回环边： 将回环检测中关联的关键帧通过 Sim(3) 变换建立边约束。测量信息： 计算两帧之间的相对位姿变换 Sji，用于误差最小化。
    // 目的： 确保回环关系带来的约束在优化中发挥作用，减少累积误差。
    for(map<kfptr , set<kfptr > >::const_iterator mit = LoopConnections.begin(), mend=LoopConnections.end(); mit!=mend; mit++)
    {
        kfptr pKF = mit->first;

        if(pKF->isBad()) continue;

        const size_t nIDi = pKF->mUniqueId;

        const set<kfptr> &spConnections = mit->second;
        const g2o::Sim3 Siw = vScw[nIDi];
        const g2o::Sim3 Swi = Siw.inverse();

        for(set<kfptr>::const_iterator sit=spConnections.begin(), send=spConnections.end(); sit!=send; sit++)
        {
            if((*sit)->isBad()) continue;

            const size_t nIDj = (*sit)->mUniqueId;

            if((nIDi!=pCurKF->mUniqueId || nIDj!=pLoopKF->mUniqueId) && pKF->GetWeight(*sit)<minFeat)
                continue;

            const g2o::Sim3 Sjw = vScw[nIDj];
            const g2o::Sim3 Sji = Sjw * Swi;

            g2o::EdgeSim3* e = new g2o::EdgeSim3();
            e->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDj)));
            e->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDi)));
            e->setMeasurement(Sji);

            e->information() = matLambda;

            optimizer.addEdge(e);

            sInsertedEdges.insert(make_pair(min(nIDi,nIDj),max(nIDi,nIDj)));
        }
    }

    // Set normal edges
    for(size_t i=0, iend=vpKFs.size(); i<iend; i++)
    {
        kfptr pKF = vpKFs[i];

        const size_t nIDi = pKF->mUniqueId;

        g2o::Sim3 Swi = vScw[nIDi].inverse();

        kfptr pParentKF = pKF->GetParent();

        // Spanning tree edge
        if(pParentKF)
        {
            const size_t nIDj = pParentKF->mUniqueId;

            g2o::Sim3 Sjw = vScw[nIDj];

            g2o::Sim3 Sji = Sjw * Swi;

            g2o::EdgeSim3* e = new g2o::EdgeSim3();
            e->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDj)));
            e->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDi)));
            e->setMeasurement(Sji);

            e->information() = matLambda;
            optimizer.addEdge(e);
        }

        // Loop edges
        const set<kfptr> sLoopEdges = pKF->GetLoopEdges();
        for(set<kfptr>::const_iterator sit=sLoopEdges.begin(), send=sLoopEdges.end(); sit!=send; sit++)
        {
            kfptr pLKF = *sit;

            const size_t nIDj = pLKF->mUniqueId;

            if(nIDj<nIDi)
            {
                g2o::Sim3 Slw = vScw[nIDj];

                g2o::Sim3 Sli = Slw * Swi;
                g2o::EdgeSim3* el = new g2o::EdgeSim3();
                el->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDj)));
                el->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDi)));
                el->setMeasurement(Sli);
                el->information() = matLambda;
                optimizer.addEdge(el);
            }
        }

        // Covisibility graph edges
        //共视边 (Covisibility Edges), 共视边： 根据共视关系连接邻近关键帧，确保局部一致性。作用： 稳定局部结构，同时与回环边配合实现全局一致性。
        const vector<kfptr> vpConnectedKFs = pKF->GetCovisiblesByWeight(minFeat);
        for(vector<kfptr>::const_iterator vit=vpConnectedKFs.begin(); vit!=vpConnectedKFs.end(); vit++)
        {
            kfptr pKFn = *vit;

            if((*vit)->isBad()) continue;

            if(pKFn && pKFn!=pParentKF && !pKF->hasChild(pKFn) && !sLoopEdges.count(pKFn))
            {
                const size_t nIDj = pKFn->mUniqueId;

                if(!pKFn->isBad() && nIDj<nIDi)
                {
                    if(sInsertedEdges.count(make_pair(min(nIDi,nIDj),max(nIDi,nIDj))))
                        continue;

                    g2o::Sim3 Snw = vScw[nIDj];

                    g2o::Sim3 Sni = Snw * Swi;

                    g2o::EdgeSim3* en = new g2o::EdgeSim3();
                    en->setVertex(1, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDj)));
                    en->setVertex(0, dynamic_cast<g2o::OptimizableGraph::Vertex*>(optimizer.vertex(nIDi)));
                    en->setMeasurement(Sni);
                    en->information() = matLambda;
                    optimizer.addEdge(en);
                }
            }
        }
    }

    // Optimize!
    optimizer.initializeOptimization();
    optimizer.optimize(20);

    // SE3 Pose Recovering. Sim3:[sR t;0 1] -> SE3:[R t/s;0 1]
    for(size_t i=0;i<vpKFs.size();i++)
    {
        kfptr pKFi = vpKFs[i];
        const size_t nIDi = pKFi->mUniqueId;

        g2o::VertexSim3Expmap* VSim3 = static_cast<g2o::VertexSim3Expmap*>(optimizer.vertex(pKFi->mUniqueId));
        g2o::Sim3 CorrectedSiw =  VSim3->estimate();
        vCorrectedSwc[nIDi]=CorrectedSiw.inverse();
        Eigen::Matrix3d eigR = CorrectedSiw.rotation().toRotationMatrix();
        Eigen::Vector3d eigt = CorrectedSiw.translation();
        double s = CorrectedSiw.scale();

        eigt *=(1./s); //[R t/s;0 1]

        cv::Mat Tiw = Converter::toCvSE3(eigR,eigt);

        pKFi->SetPose(Tiw,true);
    }

    // Correct points. Transform to "non-optimized" reference keyframe pose and transform back with optimized pose
    for(size_t i=0, iend=vpMPs.size(); i<iend; i++)
    {
        mpptr pMP = vpMPs[i];

        if(pMP->isBad())
            continue;

        int nIDr;
        if(pMP->mCorrectedByKF_MM==pCurKF->mId)
        {
            nIDr = pMP->mCorrectedReference_MM;
        }
        else
        {
            kfptr pRefKF = pMP->GetReferenceKeyFrame();
            nIDr = pRefKF->mUniqueId;
        }

        g2o::Sim3 Srw = vScw[nIDr];
        g2o::Sim3 correctedSwr = vCorrectedSwc[nIDr];

        cv::Mat P3Dw = pMP->GetWorldPos();
        Eigen::Matrix<double,3,1> eigP3Dw = Converter::toVector3d(P3Dw);
        Eigen::Matrix<double,3,1> eigCorrectedP3Dw = correctedSwr.map(Srw.map(eigP3Dw));

        cv::Mat cvCorrectedP3Dw = Converter::toCvMat(eigCorrectedP3Dw);
        pMP->SetWorldPos(cvCorrectedP3Dw,true);

        pMP->UpdateNormalAndDepth();
    }
}

} // end ns
