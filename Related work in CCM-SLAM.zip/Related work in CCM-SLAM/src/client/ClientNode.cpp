/**
* This file is part of CCM-SLAM.
*
* Copyright (C): Patrik Schmuck <pschmuck at ethz dot ch> (ETH Zurich)
* For more information see <https://github.com/patriksc/CCM-SLAM>
*
* CCM-SLAM is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* CCM-SLAM is based in the monocular version of ORB-SLAM2 by Raúl Mur-Artal.
* CCM-SLAM partially re-uses modules of ORB-SLAM2 in modified or unmodified condition.
* For more information see <https://github.com/raulmur/ORB_SLAM2>.
*
* CCM-SLAM is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CCM-SLAM. If not, see <http://www.gnu.org/licenses/>.
*/


#include <cslam/client/ClientSystem.h>

#include <cslam/config.h>

int main(int argc, char **argv) {

    ros::init(argc, argv, "CSLAM client node");    //初始化ROS系统，设置节点名称为 "CSLAM client node"。

    if(argc != 3)      //检查命令行参数数量。如果不是三个参数（程序本身，词汇表路径，摄像头参数路径），则打印用法信息并关闭ROS节点。
    {
        cerr << endl << "Usage: rosrun cslam clientnode path_to_vocabulary path_to_cam_params" << endl;
        ros::shutdown();
        return 1;
    }

    ros::NodeHandle Nh;           // 创建一个全局节点句柄。
    ros::NodeHandle NhPrivate("~");       //创建一个私有节点句柄，用于处理私有命名空间下的参数。

   //该函数在clientsystem.cpp文件中
    boost::shared_ptr<cslam::ClientSystem> pCSys{new cslam::ClientSystem(Nh,NhPrivate,argv[1],argv[2])};
     //使用词汇表路径 argv[1] 和摄像头参数路径 argv[2] 初始化 cslam::ClientSystem 对象。
     //这个对象可能负责处理与SLAM相关的数据和任务。

    ROS_INFO("Started CSLAM client node...");

    ros::Rate r(params::timings::client::miRosRate);   // 设置节点的运行频率，这个频率定义了节点循环的速度。
    while(ros::ok())    //在ROS运行正常的情况下，循环执行
    {
        ros::spinOnce();     //处理一次回调函数，用于处理例如订阅消息的回调。
        r.sleep();                   //在循环的每次迭代后睡眠一定时间，以控制循环频率。
    }

    return 0;
}
