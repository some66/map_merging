/**
* This file is part of CCM-SLAM.
*
* Copyright (C): Patrik Schmuck <pschmuck at ethz dot ch> (ETH Zurich)
* For more information see <https://github.com/patriksc/CCM-SLAM>
*
* CCM-SLAM is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* CCM-SLAM is based in the monocular version of ORB-SLAM2 by Raúl Mur-Artal.
* CCM-SLAM partially re-uses modules of ORB-SLAM2 in modified or unmodified condition.
* For more information see <https://github.com/raulmur/ORB_SLAM2>.
*
* CCM-SLAM is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CCM-SLAM. If not, see <http://www.gnu.org/licenses/>.
*/

#include <cslam/Database.h>

namespace cslam {

KeyFrameDatabase::KeyFrameDatabase(const vocptr pVoc):
    mpVoc(pVoc)
{
    mvInvertedFile.resize((*pVoc).size());

    cout << "+++++ KeyFrame Database Initialized +++++" << endl;
}

void KeyFrameDatabase::add(kfptr pKF)
{
    unique_lock<mutex> lock(mMutex);

    for(DBoW2::BowVector::const_iterator vit= pKF->mBowVec.begin(), vend=pKF->mBowVec.end(); vit!=vend; vit++)
        mvInvertedFile[vit->first].push_back(pKF);
}

void KeyFrameDatabase::erase(kfptr pKF)
{
    unique_lock<mutex> lock(mMutex);

    // Erase elements in the Inverse File for the entry
    for(DBoW2::BowVector::const_iterator vit=pKF->mBowVec.begin(), vend=pKF->mBowVec.end(); vit!=vend; vit++)
    {
        // List of keyframes that share the word
        list<kfptr> &lKFs =   mvInvertedFile[vit->first];

        for(list<kfptr>::iterator lit=lKFs.begin(), lend= lKFs.end(); lit!=lend; lit++)
        {
            if(pKF==*lit)
            {
                lKFs.erase(lit);
                break;
            }
        }
    }
}

void KeyFrameDatabase::clear()
{
    mvInvertedFile.clear();
    mvInvertedFile.resize(mpVoc->size());
}

vector<KeyFrameDatabase::kfptr> KeyFrameDatabase::DetectLoopCandidates(kfptr pKF, float minScore)
{
    set<kfptr> spConnectedKeyFrames = pKF->GetConnectedKeyFrames();
    list<kfptr> lKFsSharingWords;

    std::map<idpair,kfptr> mpAllKfsInMap = pKF->GetMapptr()->GetMmpKeyFrames();

    // Search all keyframes that share a word with current keyframes
    // Discard keyframes connected to the query keyframe
    {
        unique_lock<mutex> lock(mMutex);

        for(DBoW2::BowVector::const_iterator vit=pKF->mBowVec.begin(), vend=pKF->mBowVec.end(); vit != vend; vit++)
        {
            list<kfptr> &lKFs =   mvInvertedFile[vit->first];

            for(list<kfptr>::iterator lit=lKFs.begin(), lend= lKFs.end(); lit!=lend; lit++)
            {
                kfptr pKFi=*lit;

                if(pKFi->mId == pKF->mId) continue;

                std::map<idpair,kfptr>::iterator mit = mpAllKfsInMap.find(pKFi->mId);
                if(mit == mpAllKfsInMap.end()) continue; //Only consider KFs that belong to the same map

                if(!(pKFi->mLoopQuery==pKF->mId))
                {
                    pKFi->mnLoopWords=0;
                    if(!spConnectedKeyFrames.count(pKFi))
                    {
                        pKFi->mLoopQuery=pKF->mId;
                        lKFsSharingWords.push_back(pKFi);
                    }
                }
                pKFi->mnLoopWords++;
            }
        }
    }

    if(lKFsSharingWords.empty())
        return vector<kfptr>();

    list<pair<float,kfptr> > lScoreAndMatch;

    // Only compare against those keyframes that share enough words
    int maxCommonWords=0;
    for(list<kfptr>::iterator lit=lKFsSharingWords.begin(), lend= lKFsSharingWords.end(); lit!=lend; lit++)
    {
        if((*lit)->mnLoopWords>maxCommonWords)
            maxCommonWords=(*lit)->mnLoopWords;
    }

    int minCommonWords = maxCommonWords*0.8f;

    int nscores=0;

    // Compute similarity score. Retain the matches whose score is higher than minScore
    for(list<kfptr>::iterator lit=lKFsSharingWords.begin(), lend= lKFsSharingWords.end(); lit!=lend; lit++)
    {
        kfptr pKFi = *lit;

        if(pKFi->mnLoopWords>minCommonWords)
        {
            nscores++;

            float si = mpVoc->score(pKF->mBowVec,pKFi->mBowVec);

            pKFi->mLoopScore = si;
            if(si>=minScore)
                lScoreAndMatch.push_back(make_pair(si,pKFi));
        }
    }

    if(lScoreAndMatch.empty())
        return vector<kfptr>();

    list<pair<float,kfptr> > lAccScoreAndMatch;
    float bestAccScore = minScore;

    // Lets now accumulate score by covisibility
    for(list<pair<float,kfptr> >::iterator it=lScoreAndMatch.begin(), itend=lScoreAndMatch.end(); it!=itend; it++)
    {
        kfptr pKFi = it->second;
        vector<kfptr> vpNeighs = pKFi->GetBestCovisibilityKeyFrames(10);

        float bestScore = it->first;
        float accScore = it->first;
        kfptr pBestKF = pKFi;
        for(vector<kfptr>::iterator vit=vpNeighs.begin(), vend=vpNeighs.end(); vit!=vend; vit++)
        {
            kfptr pKF2 = *vit;

            if(pKF2->mLoopQuery==pKF->mId && pKF2->mnLoopWords>minCommonWords)
            {
                accScore+=pKF2->mLoopScore;
                if(pKF2->mLoopScore>bestScore)
                {
                    pBestKF=pKF2;
                    bestScore = pKF2->mLoopScore;
                }
            }
        }

        lAccScoreAndMatch.push_back(make_pair(accScore,pBestKF));
        if(accScore>bestAccScore)
            bestAccScore=accScore;
    }

    // Return all those keyframes with a score higher than 0.75*bestScore
    float minScoreToRetain = 0.75f*bestAccScore;

    set<kfptr> spAlreadyAddedKF;
    vector<kfptr> vpLoopCandidates;
    vpLoopCandidates.reserve(lAccScoreAndMatch.size());

    for(list<pair<float,kfptr> >::iterator it=lAccScoreAndMatch.begin(), itend=lAccScoreAndMatch.end(); it!=itend; it++)
    {
        if(it->first>minScoreToRetain)
        {
            kfptr pKFi = it->second;
            if(!spAlreadyAddedKF.count(pKFi))
            {
                vpLoopCandidates.push_back(pKFi);
                spAlreadyAddedKF.insert(pKFi);
            }
        }
    }


    return vpLoopCandidates;
}


//在视觉SLAM系统中关键帧数据库 (KeyFrameDatabase) 的 DetectMapMatchCandidates 方法，用于检测与给定关键帧可能匹配的其他关键帧。
//该方法使用词袋模型（Bag of Words, BoW）进行快速检索和匹配得分计算。
//传入当前关键帧 (mpCurrentKF)、最小得分阈值 (minScore) 和当前地图 (mpCurrMap)，以检索可能的匹配候选关键帧。
vector<KeyFrameDatabase::kfptr> KeyFrameDatabase::DetectMapMatchCandidates(kfptr pKF, float minScore, mapptr pMap)
{

    //声明了一个名为 lKFsSharingWords 的 list 容器，用于存储类型为 kfptr 的元素。这里，kfptr 很可能是一个指针类型，指向关键帧对象。
    list<kfptr> lKFsSharingWords;

    // 输出当前关键帧的客户端标识符
    //std::cout << "当前关键帧的客户端标识符: " << pKF->mId.second << std::endl;
    // 检查并输出所有关联的客户端标识符
   // std::cout << "关联的客户端标识符: ";
   // for (const auto& clientId : pMap->msuAssClients) {
    //    std::cout << clientId << " ";
   // }

    // Search all keyframes that share a word with current keyframes
    // Discard keyframes that belong to KF's map
    //搜索共享单词的关键帧, 使用互斥锁保护关键帧数据库，遍历当前关键帧的 BoW 向量，寻找在倒排索引中共享至少一个单词的关键帧。
    //对于每一个找到的关键帧，如果它尚未被当前关键帧查询过，重置它的循环词汇计数并添加到共享单词的关键帧列表中。
    {
        unique_lock<mutex> lock(mMutex);

      //通过词袋模型快速识别可能与当前关键帧相关的其他关键帧
      // 遍历当前关键帧的BoW向量, pKF->mBowVec 表示当前关键帧的BoW向量。
      // 这个循环遍历该向量的每个元素，其中 vit 是一个迭代器，指向当前的视觉单词及其权重。
        for(DBoW2::BowVector::const_iterator vit=pKF->mBowVec.begin(), vend=pKF->mBowVec.end(); vit != vend; vit++)
        {
            // 访问倒排索引,  mvInvertedFile 是一个倒排索引，它映射视觉单词到包含该单词的关键帧列表。
            // vit->first 是当前视觉单词的ID，通过这个ID访问包含此单词的所有关键帧的列表。
            list<kfptr> &lKFs =   mvInvertedFile[vit->first];

           //检查每个关键帧, 这个内层循环遍历包含当前视觉单词的每个关键帧。pKFi 是当前正在检查的关键帧。
            for(list<kfptr>::iterator lit=lKFs.begin(), lend= lKFs.end(); lit!=lend; lit++)
            {
                kfptr pKFi=*lit;

              //更新关键帧信息, 如果当前关键帧 pKFi 未被当前关键帧 pKF 查询过（通过匹配查询ID判断），则重置其循环单词计数 mnLoopWords。
                if(!(pKFi->mMatchQuery==pKF->mId))
                {
                    pKFi->mnLoopWords=0;

                 //检查关键帧是否属于当前地图, 如果 pKFi 不属于当前地图（pMap 没有包含 pKFi 的客户端ID），则设置其匹配查询ID为当前关键帧ID，
                 //它检查并确定哪些关键帧与当前处理的关键帧（pKF）不属于同一个地图实例，并据此更新匹配查询信息和共享单词关键帧列表。
                 //条件检查,  这行代码检查 pKFi 的 mId.second（通常是关键帧所属客户端或地图的唯一标识符）
                 //是否存在于当前地图 pMap 的关联客户端集合 msuAssClients 中。
                 //如果当前关键帧 pKFi 不属于地图 pMap 的关联客户端集合，即 msuAssClients 中不包含 pKFi 的标识符，说明 pKFi 属于不同的地图或数据集。
                 //count: 是 set 容器提供的一个方法，用来计算集合中等于指定值的元素个数。
                 //在 set 中，由于元素具有唯一性，count 方法的返回值只能是 0 或 1，即该元素不存在或存在。
                 //如果这个ID不在集合中，说明该关键帧来自于一个与当前地图不直接相关的客户端。
                 //  修改部分！！！！！！
                 //  if (pMap->msuAssClients.size()==1)
                 //  {
                                if(!pMap->msuAssClients.count(pKFi->mId.second))
                                {
                                    //cout << "!!!FENG YU XUAN !!! 222" << endl;  
                                    //将 pKFi 的 mMatchQuery 属性设置为当前处理关键帧 pKF 的ID。mMatchQuery 通常用来标记一个关键帧已经被另一个关键帧用于某种匹配查询，
                                    //以防止在后续处理中重复使用同一关键帧，确保数据的处理不会出现循环或重复。    
                                     pKFi->mMatchQuery=pKF->mId;
                                    //并将其添加到共享单词的关键帧列表 lKFsSharingWords。                             
                                    //此列表存储所有与当前关键帧 pKF 共享视觉单词的关键帧，用于后续的处理和分析。
                                    //在这种情况下，pKFi 被认为是一个有用的数据点，即使它来自不同的客户端或数据源。
                                    lKFsSharingWords.push_back(pKFi);
                                }
                   // }
                   // else
                  //  {
                              //  cout << "!!!FENG YU XUAN !!! 222" << endl;      
                  //              pKFi->mMatchQuery=pKF->mId;
                   //             lKFsSharingWords.push_back(pKFi);
                   // }
                }
            //无论是否已查询过，都增加 pKFi 的循环单词计数 mnLoopWords，这用于后续计算关键帧之间的共享单词数量。 
                pKFi->mnLoopWords++;
            }
        }
    }

//检查 lKFsSharingWords 列表是否为空。lKFsSharingWords 是一个列表，用于存储与当前关键帧共享视觉单词的所有其他关键帧。
//如果这个列表为空，意味着没有找到任何共享相同视觉单词的关键帧。
    if(lKFsSharingWords.empty())
    {
        // 如果上述条件为真，即没有找到共享视觉单词的关键帧，函数将返回一个空的 vector<kfptr>。
        //这里 vector<kfptr>() 是一个新创建的空向量，kfptr 是关键帧指针的类型。
        // 在运行时，每次检测到闭环都是从这里就停止了！！！！! 
        //  cout << "!!!FENG YU XUAN !!! 222" << endl;            
         return vector<kfptr>();
    }       

//声明了一个名为 lScoreAndMatch 的列表，用来存储 pair<float, kfptr> 类型的元素。
//在这里，kfptr 很可能是一个指针类型，指向关键帧（KeyFrame）对象，而 float 类型的数据则用来存储与这些关键帧相关的分数。
    list<pair<float,kfptr> > lScoreAndMatch;

//计算相似度得分, 这部分代码首先计算共享最多单词的数量，然后设定最小共享单词阈值为最多单词的80%。
    // Only compare against those keyframes that share enough words

    //初始化变量 maxCommonWords，用于记录与当前关键帧共享最多视觉单词的数量。
    int maxCommonWords=0;
    //遍历存储共享单词关键帧的列表 lKFsSharingWords,  寻找最大共有单词数,
    for(list<kfptr>::iterator lit=lKFsSharingWords.begin(), lend= lKFsSharingWords.end(); lit!=lend; lit++)
    {
        //检查当前关键帧的 mnLoopWords 属性（表示与当前关键帧共享的单词数量）是否大于目前记录的最大值 maxCommonWords。
        if((*lit)->mnLoopWords>maxCommonWords)
        // 如果当前关键帧的共享单词数量更多，更新 maxCommonWords
            maxCommonWords=(*lit)->mnLoopWords;
    }

  //设置最小共有单词数阈值, 计算最小共有单词数的阈值，设置为最大共有单词数的80%。
  //这一阈值用于后续筛选具有足够高共享单词数的关键帧，确保只考虑与当前关键帧高度相关的关键帧进行进一步的匹配评分。
    int minCommonWords = maxCommonWords*0.8f;

   //初始化评分次数计数器, 用于记录实际进行相似度评分的关键帧数量。这个计数器在后续的评分过程中更新，帮助跟踪评分操作的执行次数。
    int nscores=0;

   // 在关键帧数据库搜索过程中用于评估和筛选候选关键帧的部分。
  //它基于共享视觉单词的数量和词袋模型的得分来评估每个候选关键帧与当前关键帧的相似度。
  //遍历共享单词的关键帧列表, 使用迭代器 lit 遍历存储在 lKFsSharingWords 中的所有关键帧。
  //这个列表包含了与当前关键帧共享至少一个视觉单词的关键帧。
    for(list<kfptr>::iterator lit=lKFsSharingWords.begin(), lend= lKFsSharingWords.end(); lit!=lend; lit++)
    {
        //pKFi 是当前迭代到的关键帧。
        kfptr pKFi = *lit;

      //检查 pKFi 的 mnLoopWords（与当前关键帧共享的单词数量）是否大于之前计算的阈值 minCommonWords。
      //这确保只有与当前关键帧高度相关的关键帧才进入得分计算和进一步的处理。
        if(pKFi->mnLoopWords>minCommonWords)
        {
            nscores++;  //增加一个计分次数的计数器，用于跟踪进行了多少次得分计算。

          //计算当前关键帧 pKF 与候选关键帧 pKFi 之间的词袋模型得分。 这个得分基于它们的 BoW向量，反映了两者视觉内容的相似度。
            float si = mpVoc->score(pKF->mBowVec,pKFi->mBowVec);
           //将计算得到的得分存储在 pKFi 的 mLoopScore 属性中。
            pKFi->mLoopScore = si;
            //如果得分 si 大于或等于预设的最小得分 minScore，则将得分和关键帧的配对作为元组 make_pair(si, pKFi) 添加到 lScoreAndMatch 列表中。
            if(si>=minScore)
                lScoreAndMatch.push_back(make_pair(si,pKFi));
        }
    }

//lScoreAndMatch是一个列表，存储了与当前关键帧相匹配的关键帧及其得分，其中得分是根据词袋模型计算得出的。
//检查 lScoreAndMatch 列表是否为空。空列表表示没有找到任何得分超过预设最小得分（minScore）的关键帧。
    if(lScoreAndMatch.empty())
        {
             return vector<kfptr>();
        }
           
//累积得分和筛选结果,  最后，计算每个候选关键帧的累积得分，考虑其共视关键帧的得分。
//最终选择得分高于75%最佳累积得分的关键帧作为闭环候选。
//这个过程优先考虑具有高共视一致性和词汇一致性的关键帧，以提高闭环检测的准确性和鲁棒性。
    list<pair<float,kfptr> > lAccScoreAndMatch;
    float bestAccScore = minScore;

    // Lets now accumulate score by covisibility
    for(list<pair<float,kfptr> >::iterator it=lScoreAndMatch.begin(), itend=lScoreAndMatch.end(); it!=itend; it++)
    {
        kfptr pKFi = it->second;
        vector<kfptr> vpNeighs = pKFi->GetBestCovisibilityKeyFrames(10);

        float bestScore = it->first;
        float accScore = it->first;
        kfptr pBestKF = pKFi;
        for(vector<kfptr>::iterator vit=vpNeighs.begin(), vend=vpNeighs.end(); vit!=vend; vit++)
        {
            kfptr pKF2 = *vit;

            if(pKF2->mMatchQuery==pKF->mId && pKF2->mnLoopWords>minCommonWords)
            {
                accScore+=pKF2->mLoopScore;
                if(pKF2->mLoopScore>bestScore)
                {
                    pBestKF=pKF2;
                    bestScore = pKF2->mLoopScore;
                }
            }
        }

        lAccScoreAndMatch.push_back(make_pair(accScore,pBestKF));
        if(accScore>bestAccScore)
            bestAccScore=accScore;
    }

    // Return all those keyframes with a score higher than 0.75*bestScore
    float minScoreToRetain = 0.75f*bestAccScore;

    set<kfptr> spAlreadyAddedKF;
    vector<kfptr> vpLoopCandidates;
    vpLoopCandidates.reserve(lAccScoreAndMatch.size());

    for(list<pair<float,kfptr> >::iterator it=lAccScoreAndMatch.begin(), itend=lAccScoreAndMatch.end(); it!=itend; it++)
    {
        if(it->first>minScoreToRetain)
        {
            kfptr pKFi = it->second;
            if(!spAlreadyAddedKF.count(pKFi))
            {
                vpLoopCandidates.push_back(pKFi);
                spAlreadyAddedKF.insert(pKFi);
            }
        }
    }

    return vpLoopCandidates;
}




vector<KeyFrameDatabase::kfptr> KeyFrameDatabase::DetectRelocalizationCandidates(Frame &F)
{
    list<kfptr> lKFsSharingWords;

    // Search all keyframes that share a word with current frame
    {
        unique_lock<mutex> lock(mMutex);

        for(DBoW2::BowVector::const_iterator vit=F.mBowVec.begin(), vend=F.mBowVec.end(); vit != vend; vit++)
        {
            list<kfptr> &lKFs =   mvInvertedFile[vit->first];

            for(list<kfptr>::iterator lit=lKFs.begin(), lend= lKFs.end(); lit!=lend; lit++)
            {
                kfptr pKFi=*lit;
                if(pKFi->mRelocQuery!=F.mId)
                {
                    pKFi->mnRelocWords=0;
                    pKFi->mRelocQuery=F.mId;
                    lKFsSharingWords.push_back(pKFi);
                }
                pKFi->mnRelocWords++;
            }
        }
    }
    if(lKFsSharingWords.empty())
        return vector<kfptr>();

    // Only compare against those keyframes that share enough words
    int maxCommonWords=0;
    for(list<kfptr>::iterator lit=lKFsSharingWords.begin(), lend= lKFsSharingWords.end(); lit!=lend; lit++)
    {
        if((*lit)->mnRelocWords>maxCommonWords)
            maxCommonWords=(*lit)->mnRelocWords;
    }

    int minCommonWords = maxCommonWords*0.8f;

    list<pair<float,kfptr> > lScoreAndMatch;

    int nscores=0;

    // Compute similarity score.
    for(list<kfptr>::iterator lit=lKFsSharingWords.begin(), lend= lKFsSharingWords.end(); lit!=lend; lit++)
    {
        kfptr pKFi = *lit;

        if(pKFi->mnRelocWords>minCommonWords)
        {
            nscores++;
            float si = mpVoc->score(F.mBowVec,pKFi->mBowVec);
            pKFi->mRelocScore=si;
            lScoreAndMatch.push_back(make_pair(si,pKFi));
        }
    }

    if(lScoreAndMatch.empty())
        return vector<kfptr>();

    list<pair<float,kfptr> > lAccScoreAndMatch;
    float bestAccScore = 0;

    // Lets now accumulate score by covisibility
    for(list<pair<float,kfptr> >::iterator it=lScoreAndMatch.begin(), itend=lScoreAndMatch.end(); it!=itend; it++)
    {
        kfptr pKFi = it->second;
        vector<kfptr> vpNeighs = pKFi->GetBestCovisibilityKeyFrames(10);

        float bestScore = it->first;
        float accScore = bestScore;
        kfptr pBestKF = pKFi;
        for(vector<kfptr>::iterator vit=vpNeighs.begin(), vend=vpNeighs.end(); vit!=vend; vit++)
        {
            kfptr pKF2 = *vit;
            if(pKF2->mRelocQuery!=F.mId)
                continue;

            accScore+=pKF2->mRelocScore;
            if(pKF2->mRelocScore>bestScore)
            {
                pBestKF=pKF2;
                bestScore = pKF2->mRelocScore;
            }

        }
        lAccScoreAndMatch.push_back(make_pair(accScore,pBestKF));
        if(accScore>bestAccScore)
            bestAccScore=accScore;
    }

    // Return all those keyframes with a score higher than 0.75*bestScore
    float minScoreToRetain = 0.75f*bestAccScore;
    set<kfptr> spAlreadyAddedKF;
    vector<kfptr> vpRelocCandidates;
    vpRelocCandidates.reserve(lAccScoreAndMatch.size());
    for(list<pair<float,kfptr> >::iterator it=lAccScoreAndMatch.begin(), itend=lAccScoreAndMatch.end(); it!=itend; it++)
    {
        const float &si = it->first;
        if(si>minScoreToRetain)
        {
            kfptr pKFi = it->second;
            if(!spAlreadyAddedKF.count(pKFi))
            {
                vpRelocCandidates.push_back(pKFi);
                spAlreadyAddedKF.insert(pKFi);
            }
        }
    }

    return vpRelocCandidates;
}

void KeyFrameDatabase::AddMP(mpptr pMP)
{
    if(!pMP)
        return;

    unique_lock<mutex> lock(mMutexMPs);

    mmpMPs[pMP->mId] = pMP;
}

void KeyFrameDatabase::AddDirectBad(size_t id, size_t cid)
{
    unique_lock<mutex> lock(mMutexMPs);

    idpair idp = make_pair(id,cid);
    mmbDirectBad[idp] = true;
}

bool KeyFrameDatabase::FindMP(size_t id, size_t cid)
{
    unique_lock<mutex> lock(mMutexMPs);

    idpair idp = make_pair(id,cid);
    std::map<idpair,mpptr>::iterator mit = mmpMPs.find(idp);
    if(mit != mmpMPs.end()) return true;
    else return false;
}

bool KeyFrameDatabase::FindDirectBad(size_t id, size_t cid)
{
    unique_lock<mutex> lock(mMutexMPs);

    idpair idp = make_pair(id,cid);
    std::map<idpair,bool>::iterator mit = mmbDirectBad.find(idp);
    if(mit != mmbDirectBad.end()) return true;
    else return false;
}

void KeyFrameDatabase::ResetMPs()
{
    unique_lock<mutex> lock(mMutexMPs);

    mmbDirectBad.clear();
    mmpMPs.clear();
}

} //end ns
