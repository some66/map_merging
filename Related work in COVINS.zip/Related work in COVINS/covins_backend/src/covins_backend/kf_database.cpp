/**
* This file is part of COVINS.
*
* Copyright (C) 2018-2021 Patrik Schmuck / Vision for Robotics Lab
* (ETH Zurich) <collaborative (dot) slam (at) gmail (dot) com>
* For more information see <https://github.com/VIS4ROB-lab/covins>
*
* COVINS is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the license, or
* (at your option) any later version.
*
* COVINS is distributed to support research and development of
* multi-agent system, but WITHOUT ANY WARRANTY; without even the
* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
* PURPOSE. In no event will the authors be held liable for any damages
* arising from the use of this software. See the GNU General Public
* License for more details.
*
* You should have received a copy of the GNU General Public License
* along with COVINS. If not, see <http://www.gnu.org/licenses/>.
*/
/**
* The KeyframeDatabase class partially re-uses code of ORB-SLAM2
*/

#include "covins_backend/kf_database.hpp"

// COVINS
#include "covins_backend/keyframe_be.hpp"

namespace covins {

KeyframeDatabase::KeyframeDatabase(const VocabularyPtr voc)
    : voc_(voc)
{
    inverted_file_index_.resize((*voc_).size());
    std::cout << "+++++ KeyFrame Database Initialized +++++" << std::endl;
}

auto KeyframeDatabase::AddKeyframe(KeyframePtr kf)->void {
    unique_lock<std::mutex> lock(mtx_);
    for(auto vit= kf->bow_vec_.begin(), vend=kf->bow_vec_.end(); vit!=vend; vit++)
        inverted_file_index_[vit->first].push_back(kf);
}



// 替换原来的 DetectCandidates(...) 实现
auto KeyframeDatabase::DetectCandidates(KeyframePtr kf, precision_t min_score) -> KeyframeVector {
    // ==== 0) 取“有限 + 强连接”的邻居，避免把几乎整张图都视作邻居 ====
    // 可按需要调两个常量：最多保留的邻居数量 & 邻接权重下限
    static constexpr int   K_TOP_NEIGHBORS   = 50;   // 最多保留 50 个“强”邻居
    static constexpr int   MIN_NEIGH_WEIGHT  = 50;   // 低于此权重的邻边不计入“邻居集合”
    static constexpr float REL_THR_FACTOR    = 0.50f; // 相对阈值比例（原 0.7）
    static constexpr float REL_THR_MIN       = 0.001f; // 相对阈值下限
    static constexpr float REL_THR_MAX       = 0.020f; // 相对阈值上限
    static constexpr float ACC_KEEP_RATIO    = 0.60f; // 二次累计分阈值（原 0.75）
    static constexpr int   TOPN_FALLBACK     = 5;     // 兜底：按累计分取前 N 个

    KeyframeVector connections_all;
    if (covins_params::placerec::type == "COVINS_G") {
        // 原实现：GetConnectedNeighborKeyframes() 可能返回“过多邻居”
        // 改成：按权重取强连接；接口如果没有权重过滤，就先拿全部再截断
        connections_all = kf->GetConnectedKeyframesByWeight(MIN_NEIGH_WEIGHT);
        if (connections_all.empty()) {
            // 兜底：没有权重过滤接口或没有达到权重门槛，就拿全部再截断
            connections_all = kf->GetConnectedNeighborKeyframes();
        }
    } else {
        connections_all = kf->GetConnectedKeyframesByWeight(MIN_NEIGH_WEIGHT);
    }
    if (connections_all.size() > K_TOP_NEIGHBORS)
        connections_all.resize(K_TOP_NEIGHBORS);

    KeyframeSet connected_kfs(connections_all.begin(), connections_all.end());

    // ==== 1) 倒排索引：收集“共享词”的候选 ====
    KeyframeList lKFsSharingWords;
    {
        std::unique_lock<std::mutex> lock(mtx_);
        for (auto vit = kf->bow_vec_.begin(), vend = kf->bow_vec_.end(); vit != vend; ++vit) {
            auto &lKFs = inverted_file_index_[vit->first];
            for (auto lit = lKFs.begin(), lend = lKFs.end(); lit != lend; ++lit) {
                KeyframePtr pKFi = *lit;
                if (pKFi->id_ == kf->id_) continue;

                // 仅跨图时才排除同图（可选）；你当前 inter_map_matches_only=0，则不过滤
                if (covins_params::placerec::inter_map_matches_only &&
                    pKFi->id_.second == kf->id_.second) continue;

                // 同图时间窗口：保留“远一点”的帧，避免近邻重复检测
                if (pKFi->id_.second == kf->id_.second &&
                    std::abs(int(kf->id_.first) - int(pKFi->id_.first)) < covins_params::placerec::min_loop_dist)
                    continue;

                // 极早期帧过滤（保留极少数）
                if (pKFi->id_.first < covins_params::placerec::exclude_kfs_with_id_less_than) continue;

                // —— 关键改动：不再把“所有邻居”都排除，只排“有限强邻居” —— //
                if (connected_kfs.count(pKFi)) continue;

                if (!(pKFi->loop_query_ == kf->id_)) {
                    pKFi->loop_words_ = 0;
                    pKFi->loop_query_ = kf->id_;
                    lKFsSharingWords.push_back(pKFi);
                }
                pKFi->loop_words_++;
            }
        }
    }

    if (lKFsSharingWords.empty()) return KeyframeVector();

    // ==== 2) 共享词门槛：自适应但更宽松 ====
    int maxCommonWords = 0;
    for (auto &p : lKFsSharingWords)
        if (p->loop_words_ > maxCommonWords) maxCommonWords = p->loop_words_;
    // 原来是 0.8*max；改为更宽松并加绝对下限
    int minCommonWords = std::max(5, int(maxCommonWords * 0.65f));

    // ==== 3) 计算 BoW 相似度，初筛阈值带上下限 ====
    listFloatKfPair lScoreAndMatch; // {score, keyframe}
    int nscores = 0;

    // 相对阈值（与邻居最低分有关）建议外部已做 clamp；这里仍用传入的 min_score 做初筛
    float thr0 = std::max(REL_THR_MIN, std::min(REL_THR_MAX, float(min_score) * REL_THR_FACTOR));

    for (auto &pKFi : lKFsSharingWords) {
        if (pKFi->loop_words_ < minCommonWords) continue;
        ++nscores;
        precision_t si = static_cast<precision_t>(voc_->score(kf->bow_vec_, pKFi->bow_vec_));
        pKFi->loop_score_ = si;
        if (si >= thr0) lScoreAndMatch.emplace_back(si, pKFi);
    }

    if (lScoreAndMatch.empty()) return KeyframeVector();

    // ==== 4) 累积分 + 邻居加成（同样不使用“过多邻居”） ====
    listFloatKfPair lAccScoreAndMatch; // {accScore, bestKF}
    precision_t bestAccScore = thr0;

    for (auto it = lScoreAndMatch.begin(); it != lScoreAndMatch.end(); ++it) {
        KeyframePtr pKFi = it->second;

        KeyframeVector all_neighs;
        if (covins_params::placerec::type == "COVINS_G") {
            all_neighs = pKFi->GetConnectedKeyframesByWeight(MIN_NEIGH_WEIGHT);
            if (all_neighs.empty()) all_neighs = pKFi->GetConnectedNeighborKeyframes();
        } else {
            all_neighs = pKFi->GetConnectedKeyframesByWeight(0);
        }

        // 只取最多 10 个邻居做加分，避免被长链条“过度放大”
        if (all_neighs.size() > 10) all_neighs.resize(10);

        float bestScore = it->first;
        float accScore  = it->first;
        KeyframePtr pBestKF = pKFi;

        for (auto &pKF2 : all_neighs) {
            if (pKF2->loop_query_ == kf->id_ && pKF2->loop_words_ >= minCommonWords) {
                accScore += pKF2->loop_score_;
                if (pKF2->loop_score_ > bestScore) {
                    pBestKF = pKF2;
                    bestScore = pKF2->loop_score_;
                }
            }
        }
        lAccScoreAndMatch.emplace_back(accScore, pBestKF);
        if (accScore > bestAccScore) bestAccScore = accScore;
    }

    // ==== 5) 二次截断：放宽比例 + Top-N 兜底 ====
    const float minScoreToRetain = ACC_KEEP_RATIO * bestAccScore;

    // 先按分数降序
    lAccScoreAndMatch.sort([](const listFloatKfPair::value_type &a,
                              const listFloatKfPair::value_type &b) {
        return a.first > b.first;
    });

    KeyframeSet    spAlreadyAddedKF;
    KeyframeVector vpLoopCandidates;
    vpLoopCandidates.reserve(lAccScoreAndMatch.size());

    int kept_by_ratio = 0;
    for (auto &pr : lAccScoreAndMatch) {
        if (pr.first >= minScoreToRetain) {
            KeyframePtr pKFi = pr.second;
            if (!spAlreadyAddedKF.count(pKFi)) {
                vpLoopCandidates.push_back(pKFi);
                spAlreadyAddedKF.insert(pKFi);
                ++kept_by_ratio;
            }
        } else {
            break; // 因为已排序，后面更低
        }
    }

    // 兜底：若通过比例门槛的很少，再补 Top-N
    if ((int)vpLoopCandidates.size() < TOPN_FALLBACK) {
        for (auto &pr : lAccScoreAndMatch) {
            if ((int)vpLoopCandidates.size() >= TOPN_FALLBACK) break;
            KeyframePtr pKFi = pr.second;
            if (!spAlreadyAddedKF.count(pKFi)) {
                vpLoopCandidates.push_back(pKFi);
                spAlreadyAddedKF.insert(pKFi);
            }
        }
    }

    return vpLoopCandidates;
}


/***
auto KeyframeDatabase::DetectCandidates(KeyframePtr kf, precision_t min_score)->KeyframeVector {
    KeyframeSet connected_kfs;
    KeyframeVector connections;
    if (covins_params::placerec::type == "COVINS_G") {
      connections = kf->GetConnectedNeighborKeyframes();
    } else {
      connections = kf->GetConnectedKeyframesByWeight(0);
    }
    

    connected_kfs.insert(connections.begin(),connections.end());
    KeyframeList lKFsSharingWords;

    // Search all keyframes that share a word with current keyframes
    // Discard keyframes that belong to KF's map
    {
        unique_lock<mutex> lock(mtx_);

        for(auto vit=kf->bow_vec_.begin(), vend=kf->bow_vec_.end(); vit != vend; vit++) {
            auto &lKFs = inverted_file_index_[vit->first];

            for(auto lit=lKFs.begin(), lend= lKFs.end(); lit!=lend; lit++)
            {
                KeyframePtr pKFi=*lit;
                if(pKFi->id_ == kf->id_) continue;
                if(covins_params::placerec::inter_map_matches_only && pKFi->id_.second == kf->id_.second) continue;
                if (pKFi->id_.second == kf->id_.second &&
                    abs(int(kf->id_.first) - int(pKFi->id_.first)) < covins_params::placerec::min_loop_dist) continue;
                if(pKFi->id_.first < covins_params::placerec::exclude_kfs_with_id_less_than) continue;
                if(!(pKFi->loop_query_==kf->id_)) {
                    pKFi->loop_words_=0;
                    if(!connected_kfs.count(pKFi)) {
                        pKFi->loop_query_=kf->id_;
                        lKFsSharingWords.push_back(pKFi);
                    }
                }
                pKFi->loop_words_++;
            }
        }
    }

    if(lKFsSharingWords.empty())
        return KeyframeVector();

    listFloatKfPair lScoreAndMatch;

    // Only compare against those keyframes that share enough words
    int maxCommonWords=0;
    for(KeyframeList::iterator lit=lKFsSharingWords.begin(), lend= lKFsSharingWords.end(); lit!=lend; lit++)
    {
        if((*lit)->loop_words_>maxCommonWords)
            maxCommonWords=(*lit)->loop_words_;
    }

    int minCommonWords = maxCommonWords*0.8f;

    int nscores=0;

    // Compute similarity score. Retain the matches whose score is higher than minScore
    for(KeyframeList::iterator lit=lKFsSharingWords.begin(), lend= lKFsSharingWords.end(); lit!=lend; lit++)
    {
        KeyframePtr pKFi = *lit;

        if(pKFi->loop_words_>minCommonWords)
        {
            nscores++;

            precision_t si = static_cast<precision_t>(voc_->score(kf->bow_vec_,pKFi->bow_vec_));

            pKFi->loop_score_ = si;
            if(si>=min_score)
                lScoreAndMatch.push_back(make_pair(si,pKFi));
        }
    }

    if(lScoreAndMatch.empty())
        return KeyframeVector();

    listFloatKfPair lAccScoreAndMatch;
    precision_t bestAccScore = min_score;

    // Lets now accumulate score by covisibility
    for(listFloatKfPair::iterator it=lScoreAndMatch.begin(), itend=lScoreAndMatch.end(); it!=itend; it++)
    {
        KeyframePtr pKFi = it->second;
        KeyframeVector vpBestNeighs;
        KeyframeVector all_neighs;
        
        if (covins_params::placerec::type == "COVINS_G") {
          all_neighs = pKFi->GetConnectedNeighborKeyframes();
        } else {
          all_neighs = pKFi->GetConnectedKeyframesByWeight(0);   
        }

        if(all_neighs.size() < 10) vpBestNeighs = all_neighs;
        else vpBestNeighs = KeyframeVector(all_neighs.begin(),all_neighs.begin()+10);

        float bestScore = it->first;
        float accScore = it->first;
        KeyframePtr pBestKF = pKFi;
        for(KeyframeVector::iterator vit=vpBestNeighs.begin(), vend=vpBestNeighs.end(); vit!=vend; vit++)
        {
            KeyframePtr pKF2 = *vit;
            if(pKF2->loop_query_==kf->id_ && pKF2->loop_words_>minCommonWords)
            {
                accScore+=pKF2->loop_score_;
                if(pKF2->loop_score_>bestScore)
                {
                    pBestKF=pKF2;
                    bestScore = pKF2->loop_score_;
                }
            }
        }

        lAccScoreAndMatch.push_back(make_pair(accScore,pBestKF));
        if(accScore>bestAccScore)
            bestAccScore=accScore;
    }

    // Return all those keyframes with a score higher than 0.75*bestScore
    float minScoreToRetain = 0.75f*bestAccScore;

    KeyframeSet spAlreadyAddedKF;
    KeyframeVector vpLoopCandidates;
    vpLoopCandidates.reserve(lAccScoreAndMatch.size());

    for(listFloatKfPair::iterator it=lAccScoreAndMatch.begin(), itend=lAccScoreAndMatch.end(); it!=itend; it++)
    {
        if(it->first>minScoreToRetain)
        {
            KeyframePtr pKFi = it->second;
            if(!spAlreadyAddedKF.count(pKFi))
            {
                vpLoopCandidates.push_back(pKFi);
                spAlreadyAddedKF.insert(pKFi);
            }
        }
    }

    return vpLoopCandidates;
}
****/



auto KeyframeDatabase::EraseKeyframe(KeyframePtr kf)->void {
    unique_lock<std::mutex> lock(mtx_);
    // Erase elements in the Inverse File for the entry
    for(auto vit=kf->bow_vec_.begin(), vend=kf->bow_vec_.end(); vit!=vend; vit++) {
        // List of keyframes that share the word
        auto &list_kfs =   inverted_file_index_[vit->first];
        for(auto lit=list_kfs.begin(), lend= list_kfs.end(); lit!=lend; lit++) {
            if(kf==*lit) {
                list_kfs.erase(lit);
                break;
            }
        }
    }
}

} // end ns
