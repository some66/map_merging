/**
* This file is part of COVINS.
*
* Copyright (C) 2018-2021 Patrik Schmuck / Vision for Robotics Lab
* (ETH Zurich) <collaborative (dot) slam (at) gmail (dot) com>
* For more information see <https://github.com/VIS4ROB-lab/covins>
*
* COVINS is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the license, or
* (at your option) any later version.
*
* COVINS is distributed to support research and development of
* multi-agent system, but WITHOUT ANY WARRANTY; without even the
* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
* PURPOSE. In no event will the authors be held liable for any damages
* arising from the use of this software. See the GNU General Public
* License for more details.
*
* You should have received a copy of the GNU General Public License
* along with COVINS. If not, see <http://www.gnu.org/licenses/>.
*/

#include "covins_backend/map_be.hpp"

// C++
#include <dirent.h>
#include <ceres/ceres.h>
#include <sophus/se3.hpp>
#include <Eigen/Dense>
#include <deque>
#include <chrono>
#include <sophus/se3.hpp>          // Sophus v1/v2 常见路径
#include <sophus/so3.hpp>

// COVINS
#include "covins_backend/keyframe_be.hpp"
#include "covins_backend/landmark_be.hpp"
#include "covins_backend/kf_database.hpp"
#include "covins_backend/optimization_be.hpp"
#include <iomanip>   // std::fixed / std::setprecision

namespace covins {

inline int KFMapId(const covins::MapManager::KeyframePtr& kf) {
    return kf ? static_cast<int>(kf->id_.second) : -1;
}



MapInstance::MapInstance(int id) {
    map.reset(new Map(id));
}

MapInstance::MapInstance(MapInstancePtr map_target, MapInstancePtr map_tofuse, TransformType T_wmatch_wtofuse)
    : usage_cnt(-1)
{
    map.reset(new Map(map_target->map,map_tofuse->map,T_wmatch_wtofuse));
}

MapInstance::MapInstance(MapPtr external_map) {
    map = external_map;
}

MapManager::MapManager(VocabularyPtr voc)
    : voc_(voc)
{
    // Other types of place recognition system could be integrated and activated using the placerec::type parameter
    if(covins_params::placerec::type == "COVINS" || covins_params::placerec::type == "COVINS_G") {
        database_.reset(new KeyframeDatabase(voc_));
    } else {
        std::cout << COUTFATAL << "Place Recognition System Type \"" << covins_params::placerec::type << "\" not valid" << std::endl;
        exit(-1);
    }

    if(!voc_) {
        std::cout << COUTFATAL << "invalid vocabulary ptr" << std::endl;
        exit(-1);
    }
}

auto MapManager::AddToDatabase(KeyframePtr kf)->void {
    std::unique_lock<std::mutex> lock(mtx_access_);
    database_->AddKeyframe(kf);
}


auto MapManager::CheckMergeBuffer()->bool {
    std::unique_lock<std::mutex> lock(mtx_access_);
    return !(buffer_merge_.empty());
}

//修改后的程序！！！！！！！！
bool MapManager::CheckMergeBuffer_modified() {
    std::unique_lock<std::mutex> lk(mtx_access_);
    if (buffer_merge_.empty()) return false;

    // 小工具：安全取 MapInstance*；kf 可能为空或 maps_ 未命中
    auto map_of_kf = [&](const KeyframePtr& kf) -> MapInstance* {
        if (!kf) return nullptr;
        auto it = maps_.find(kf->id_.second);
        return (it == maps_.end() || !it->second) ? nullptr : it->second.get();
    };

    struct PtrPairKey {
        std::uintptr_t q; std::uintptr_t m;
        bool operator==(const PtrPairKey& o) const { return q==o.q && m==o.m; }
    };
    struct PtrPairHash {
        size_t operator()(const PtrPairKey& k) const {
            return std::hash<std::uintptr_t>()(k.q) ^ (std::hash<std::uintptr_t>()(k.m)<<1);
        }
    };

    std::unordered_map<PtrPairKey, size_t, PtrPairHash> counts;

    for (const auto& mi : buffer_merge_) {
        MapInstance* qm = map_of_kf(mi.kf_query);
        MapInstance* mm = map_of_kf(mi.kf_match);
        if (!qm || !mm || qm == mm) continue;                      // 跳过同图/无效
        PtrPairKey key{ reinterpret_cast<std::uintptr_t>(qm),
                        reinterpret_cast<std::uintptr_t>(mm) };
        ++counts[key];
    }

    constexpr size_t MIN_BATCH = 15;
    PtrPairKey chosen{0,0};
    size_t best_cnt = 0;
    for (const auto& kv : counts) {
        if (kv.second >= MIN_BATCH && kv.second > best_cnt) {
            chosen   = kv.first;
            best_cnt = kv.second;
        }
    }
    if (best_cnt < MIN_BATCH) return false;

    // 代表 id：用各自地图的 associated_clients_ 的最小 client 作为代表（仍为 int）
    auto rep_client = [&](std::uintptr_t key) -> int {
        MapInstance* mp = reinterpret_cast<MapInstance*>(key);
        if (!mp || !mp->map || mp->map->associated_clients_.empty()) return -1;
        return static_cast<int>(*mp->map->associated_clients_.begin());
    };

    int q_rep = rep_client(chosen.q);
    int m_rep = rep_client(chosen.m);
    if (q_rep < 0 || m_rep < 0 || q_rep == m_rep) return false;    // 防御

    // 轻做一次“活跃确认”（race 保护）
    size_t live_cnt = 0;
    for (const auto& mi : buffer_merge_) {
        MapInstance* qm = map_of_kf(mi.kf_query);
        MapInstance* mm = map_of_kf(mi.kf_match);
        if (!qm || !mm || qm==mm) continue;
        if (reinterpret_cast<std::uintptr_t>(qm) == chosen.q &&
            reinterpret_cast<std::uintptr_t>(mm) == chosen.m) {
            ++live_cnt;
        }
    }
    if (live_cnt < MIN_BATCH) return false;

    // 写回你原来的“代表 client id”成员（兼容旧 Perform/Compute 接口）
    next_pair_query_id_ = q_rep;
    next_pair_match_id_ = m_rep;
    return true;
}



//新增的程序！！！！！！！！！！！！！！！！！！！
void MapManager::CheckinMap(int map_id, int check_num) {
    std::unique_lock<std::mutex> lock(mtx_access_);

    auto mit = maps_.find(map_id);
    if (mit == maps_.end()) return;

    MapInstancePtr inst = mit->second;
    // 独占状态下不应该走共享归还
    if (inst->usage_cnt == -1) return;

    auto it = inst->check_nums.find(check_num);
    if (it != inst->check_nums.end()) {
        inst->check_nums.erase(it);
        if (inst->usage_cnt > 0) inst->usage_cnt--;
    }
}

void MapManager::CheckinMapExclusive(int map_id, int check_num) {
    std::unique_lock<std::mutex> lock(mtx_access_);

    auto mit = maps_.find(map_id);
    if (mit == maps_.end()) return;
    MapInstancePtr inst = mit->second;

    // 只有独占时才走这里
    if (inst->usage_cnt != -1) return;

    auto it = inst->check_nums.find(check_num);
    if (it != inst->check_nums.end()) {
        inst->check_nums.erase(it);
        // 解除独占，恢复共享计数为 0，并允许共享借出
        inst->usage_cnt    = 0;
        inst->block_checkout = false;
    }
}





//////////////////////////////////////////////////////////////

auto MapManager::CheckoutMap(int map_id, int &check_num)->MapPtr {
    std::unique_lock<std::mutex> lock(mtx_access_);

    MapContainer::iterator mit = maps_.find(map_id);
    if(mit == maps_.end()){
        std::cout << COUTERROR << "no existing map with Map-ID " << map_id << std::endl;
        return nullptr;
    }

    MapInstancePtr map = mit->second;

    if(map->usage_cnt == -1){
        return nullptr;
    } else if(map->block_checkout) {
        return nullptr;
    } else {
        int check = rand();
        map->usage_cnt++;
        map->check_nums.insert(check);
        check_num = check;

        return map->map;
    }
}

auto MapManager::CheckoutMapExclusive(int map_id, int &check_num)->MapPtr {
    std::unique_lock<std::mutex> lock(mtx_access_);

    MapContainer::iterator mit = maps_.find(map_id);
    if(mit == maps_.end()){
        std::cout << COUTFATAL << "no existing map with Map-ID " << map_id << std::endl;
        return nullptr;
    }

    MapInstancePtr map = mit->second;

    if(map->usage_cnt != 0){
        return nullptr;
    } else {
        int check = rand();
        map->usage_cnt = -1;
        map->check_nums.insert(check);
        map->block_checkout = false;
        check_num = check;

        return map->map;
    }
}

auto MapManager::CheckoutMapExclusiveOrWait(int map_id, int &check_num)->MapPtr {

    {
        MapContainer::iterator mit = maps_.find(map_id);
        if(mit == maps_.end()){
            std::cout << COUTFATAL << "no existing map with Map-ID " << map_id << std::endl;
            return nullptr;
        }
    }

    MapPtr map = this->CheckoutMapExclusive(map_id,check_num);
    if(!map) {
        while(!this->SetCheckoutBlock(map_id,true))
            usleep(100);
    }

    while(!map){
        map = this->CheckoutMapExclusive(map_id,check_num);
        usleep(100);
    }

    return map;
}

auto MapManager::CheckoutMapOrWait(int map_id, int &check_num)->MapPtr {

    {
        MapContainer::iterator mit = maps_.find(map_id);
        if(mit == maps_.end()){
            std::cout << COUTFATAL << "no existing map with Map-ID " << map_id << std::endl;
            return nullptr;
        }
    }

    MapPtr map = this->CheckoutMap(map_id,check_num);
    while(!map){
        map = this->CheckoutMap(map_id,check_num);
        usleep(100);
    }
    return map;
}

auto MapManager::EraseFromDatabase(KeyframePtr kf)->void {
    std::unique_lock<std::mutex> lock(mtx_access_);
    database_->EraseKeyframe(kf);
}

auto MapManager::GetDatabase()->DatabasePtr {
    std::unique_lock<std::mutex> lock(mtx_access_);
    return database_;
}

auto MapManager::InitializeMap(int map_id)->void {
    std::unique_lock<std::mutex> lock(mtx_access_);

    MapContainer::iterator mit = maps_.find(map_id);
    if(mit != maps_.end()){
        std::cout << COUTFATAL << "Existing map with Map-ID " << map_id << std::endl;
        exit(-1);
    }

    MapInstancePtr map(new MapInstance(map_id));
    maps_[map_id] = map;
}

//// 从队首获取一条合并信息（不弹出前先拷贝/移动）
auto MapManager::PerformMerge()->void {

    std::cout << "+++ Perform Merge +++" << std::endl;

    KeyframePtr kf_query;            // 声明：参与合并的“查询侧”关键帧（query）
    KeyframePtr kf_match;                            // 声明：参与合并的“匹配侧”关键帧（match）
    TransformType T_smatch_squery;                // 声明：相对位姿 T_{s_match <- s_query}，把 query 传感器坐标系变到 match 传感器系
    TypeDefs::Matrix6Type cov_mat;                  // 声明：6×6 协方差矩阵，对上面相对位姿测量的不确定性描述

    std::cout << "--> Fetch merge data" << std::endl;
    {
        std::unique_lock<std::mutex> lock(mtx_access_);// 加互斥锁：保护共享缓冲区 buffer_merge_
        MergeInformation merge = buffer_merge_.front();   //// 从队首获取一条合并信息（不弹出前先拷贝/移动）
        buffer_merge_.pop_front();                      // 真正弹出（队列前移）
        kf_query = merge.kf_query;                    // 赋值：取出 query 关键帧指针
        kf_match = merge.kf_match;                      // 赋值：取出 match 关键帧指针
        T_smatch_squery = merge.T_smatch_squery;       // 赋值：取出其相对位姿（match <- query）
        cov_mat = merge.cov_mat;                       // 赋值：取出相对位姿的协方差
    }
    std::cout << "--> Process merge data" << std::endl;

    int check_query, check_match;                   // 标志/返回码：检查是否拿到地图的“独占访问权”

    // 阻塞/等待：为 query 所属的地图获取独占访问
    //   kf_query->id_.second, 地图/客户端ID（通常 keyframe 的 id_.second 标识所属地图/agent）
    //    check_query, 输出状态码
    this->CheckoutMapExclusiveOrWait(kf_query->id_.second,check_query);   
     // 根据 ID 从 maps_ 容器取出 query 对应的地图实例指针
    MapInstancePtr map_query = maps_[kf_query->id_.second];
    
    // 同理：为 match 所属地图获取独占访问
    this->CheckoutMapExclusiveOrWait(kf_match->id_.second,check_match);
    MapInstancePtr map_match = maps_[kf_match->id_.second];


    std::cout << "----> Merge maps" << std::endl;
    
    // 获取 query 关键帧的 Tws（world <- sensor_query）
    TransformType T_w_squery = kf_query->GetPoseTws();
     // 获取 match 关键帧的 Tws（world <- sensor_match）
    TransformType T_w_smatch = kf_match->GetPoseTws();
    // // 计算把“query 的世界系”变换到“match 的世界系”的刚体变换：
    TransformType T_wmatch_wquery = T_w_smatch * T_smatch_squery * T_w_squery.inverse();

   //  新建合并后的 MapInstance：以 match 地图为参考,把 query 地图按给定变换并入,  合并时使用的对齐变换（w_match <- w_query）
    MapInstancePtr map_merged(new MapInstance(map_match,map_query,T_wmatch_wquery));

   //   构造一条回环/跨图约束（关键帧间相对位姿约束）
    LoopConstraint lc(kf_match,kf_query,T_smatch_squery, cov_mat);
    //// 将该约束加入到合并后的图中（供后续全局/局部优化使用）
    map_merged->map->AddLoopConstraint(lc);

//    std::cout << "Map Match: Agents|KFs|LMs :" << map_match->map->associated_clients_.size() << "|" << map_match->map->GetKeyframes().size() << "|" << map_match->map->GetLandmarks().size() << std::endl;
//    std::cout << "Map Query: Agents|KFs|LMs :" << map_query->map->associated_clients_.size() << "|" << map_query->map->GetKeyframes().size() << "|" << map_query->map->GetLandmarks().size() << std::endl;
    std::cout << "Merged Map: Agents|KFs|LMs: " << map_merged->map->associated_clients_.size() << "|" << map_merged->map->GetKeyframes().size() << "|" << map_merged->map->GetLandmarks().size() << std::endl;

    for(std::set<size_t>::iterator sit = map_merged->map->associated_clients_.begin();sit != map_merged->map->associated_clients_.end();++sit) {
        maps_[*sit] = map_merged;
    }

    map_merged->usage_cnt = 0;

    std::cout << "\033[1;32m+++ MAPS MERGED +++\033[0m" << std::endl;
}


///////////////////////////////////////////////////////////////////
//========================= 工具：Eigen<->Sophus 转换 =========================
inline Sophus::SE3d ToSophus(const Eigen::Matrix4d& T) {
    Eigen::Matrix3d R = T.block<3,3>(0,0);
    Eigen::Vector3d t = T.block<3,1>(0,3);
    Eigen::JacobiSVD<Eigen::Matrix3d> svd(R, Eigen::ComputeFullU | Eigen::ComputeFullV);
    R = svd.matrixU() * svd.matrixV().transpose();
    return Sophus::SE3d(Eigen::Quaterniond(R), t);
}
inline Eigen::Matrix4d ToEigen(const Sophus::SE3d& X) { return X.matrix(); }

inline void PrintSE3(const Eigen::Matrix4d& T, const std::string& tag){
    const Eigen::Matrix3d R = T.block<3,3>(0,0);
    const Eigen::Vector3d t = T.block<3,1>(0,3);
    Eigen::Vector3d rpy = R.eulerAngles(2,1,0) * 180.0 / M_PI; // yaw,pitch,roll
    std::cout << tag << " t=[" << t.transpose() << "] |t|=" << t.norm()
              << " rpy(deg)=[" << rpy.transpose() << "]\n";
}

// Σ -> Σ^{-1/2}（白化）
inline Eigen::Matrix<double,6,6> SqrtInfoFromCov(const Eigen::Matrix<double,6,6>& cov){
    Eigen::Matrix<double,6,6> C = 0.5*(cov + cov.transpose());
    C.diagonal().array() += 1e-9;
    Eigen::LLT<Eigen::Matrix<double,6,6>> llt(C);
    if (llt.info()!=Eigen::Success) {
        C.diagonal().array() += 1e-6;
        llt.compute(C);
    }
    const Eigen::Matrix<double,6,6> L = llt.matrixL();
    return L.inverse(); // Σ^{-1/2} = L^{-1}
}

// 构建每条测量的白化矩阵 L_i（Omega = L L^T）
inline bool BuildWhiteningForBatch(
    const std::vector<RelPoseMeasurement>& meas,
    std::vector<Eigen::Matrix<double,6,6>>& Ls)
{
    const int N = (int)meas.size();
    Ls.resize(N);
    for (int i=0;i<N;++i){
        Eigen::Matrix<double,6,6> Omega;
        if (meas[i].cov.allFinite()){
            Eigen::Matrix<double,6,6> Sigma = 0.5*(meas[i].cov + meas[i].cov.transpose());
            Sigma.diagonal().array() += 1e-9;
            Eigen::LDLT<Eigen::Matrix<double,6,6>> ldlt(Sigma);
            if (ldlt.info()==Eigen::Success) {
                Omega = ldlt.solve(Eigen::Matrix<double,6,6>::Identity());
            } else {
                Omega.setIdentity();
            }
        }else{
            Omega.setIdentity();
        }
        Omega = 0.5*(Omega + Omega.transpose());
        Omega.diagonal().array() += 1e-12;

        Eigen::LLT<Eigen::Matrix<double,6,6>> llt(Omega);
        if (llt.info()!=Eigen::Success){
            Omega.diagonal().array() += 1e-8;
            llt.compute(Omega);
        }
        if (llt.info()!=Eigen::Success) return false;
        Ls[i] = llt.matrixL();
    }
    return true;
}

// ------------------ IRLS 权重（Huber，小样本用） ------------------
struct IRLSWeights {
    std::vector<double> w;
    std::vector<double> wsqrt;
};
inline IRLSWeights HuberWeights(const Eigen::VectorXd& r_norm, double delta){
    IRLSWeights out;
    const int N = (int)r_norm.size();
    out.w.resize(N); out.wsqrt.resize(N);
    for (int i=0;i<N;++i){
        const double r = r_norm[i];
        const double wi = (r <= delta) ? 1.0 : (delta / std::max(r,1e-12));
        out.w[i] = wi; out.wsqrt[i] = std::sqrt(wi);
    }
    return out;
}

// ------------------ KDE σ-consensus 权重（大样本用） ------------------
// 高斯核 PDF 权重，带宽用 Scott 规则（对 r 的标量范数）
inline IRLSWeights KDEWeightsOnNorms(const Eigen::VectorXd& r){
    IRLSWeights out;
    const int N = (int)r.size();
    out.w.resize(N); out.wsqrt.resize(N);
    if (N < 5){ // 小样本直接均匀
        for (int i=0;i<N;++i){ out.w[i]=1.0; out.wsqrt[i]=1.0; }
        return out;
    }

    const double mean = r.mean();
    double var = 0.0;
    for (int i=0;i<N;++i){ const double d=r[i]-mean; var += d*d; }
    var = std::max(var/(N-1), 1e-12);
    const double stdv = std::sqrt(var);

    // Scott 带宽 + 下限
    const double h_scott = stdv * std::pow((double)N, -1.0/5.0);
    const double h_min   = 1e-2;                // 经验下限；也可用基于 MAD 的尺度
    const double h = std::max(h_scott, h_min);

    const double inv_norm = 1.0 / (std::sqrt(2.0*M_PI) * h);

    std::vector<double> p(N, 0.0);
    for (int i=0;i<N;++i){
        double sum = 0.0;
        for (int j=0;j<N;++j){
            const double u = (r[i]-r[j])/h;
            sum += std::exp(-0.5*u*u);
        }
        p[i] = inv_norm * sum / N;
    }

    double pmax = *std::max_element(p.begin(), p.end());
    double pmin = *std::min_element(p.begin(), p.end());
    if (!(pmax > 0) || (pmax - pmin) < 1e-12) {
        for (int i=0;i<N;++i){ out.w[i]=1.0; out.wsqrt[i]=1.0; }
        return out;
    }

    // 更平滑的权重映射，避免对 pmax 过敏
    const double tau = 0.1; // 可调
    for (int i=0;i<N;++i){
        const double wi = p[i] / (p[i] + tau * pmax);
        out.w[i] = wi;
        out.wsqrt[i] = std::sqrt(wi);
    }
    return out;
}


// ------------------ Ceres 代价：放 CPP（避免头文件 Sophus 未包含报错） ------------------
struct RelPoseFactorSE3_IRLS {
    RelPoseFactorSE3_IRLS(const Sophus::SE3d& Ti,
                          const Eigen::Matrix<double,6,6>& Li,
                          double w_sqrt,
                          bool left_invariant = true)
        : Ti_(Ti), Li_(Li), wsqrt_(w_sqrt), left_(left_invariant) {}

    template <typename T>
    bool operator()(const T* const pose7, T* residuals) const {
        // 参数块顺序：[x,y,z,w, tx,ty,tz]
        Eigen::Map<const Eigen::Quaternion<T>> q_xyzw(pose7);
        Eigen::Map<const Eigen::Matrix<T,3,1>> t(pose7 + 4);
        Sophus::SE3<T> X(q_xyzw, t);

        Eigen::Matrix<T,6,1> e;
        if (left_){
            const Sophus::SE3<T> TinviX = Ti_.inverse().template cast<T>() * X;
            e = TinviX.log();
        }else{
            const Sophus::SE3<T> XinvTi = X.inverse() * Ti_.template cast<T>();
            e = XinvTi.log();
        }

        const Eigen::Matrix<T,6,1> r = T(wsqrt_) * (Li_.template cast<T>() * e);
        Eigen::Map<Eigen::Matrix<T,6,1>> res(residuals);
        res = r;
        return true;
    }

    const Sophus::SE3d Ti_;
    const Eigen::Matrix<double,6,6> Li_;
    const double wsqrt_;
    const bool left_;
};

// ------------------ 小样本：Huber-IRLS（白化 + IRLS） ------------------
static Eigen::Matrix4d EstimateRelativePoseCeres_IRLS_Huber(
    const std::vector<RelPoseMeasurement>& meas,
    const Eigen::Matrix4d& init_eigen,
    int outer_irls = 5,
    int inner_iters = 30,
    bool left_invariant = true,
    bool verbose = true)
{
    const int N = (int)meas.size();
    std::vector<Eigen::Matrix<double,6,6>> Ls;
    if (!BuildWhiteningForBatch(meas, Ls)) {
        Ls.assign(N, Eigen::Matrix<double,6,6>::Identity());
    }

    if (verbose){
        size_t n_cov=0; for (auto& m:meas) if (m.cov.allFinite()) ++n_cov;
        std::cout << "[Huber] N="<<N<<" cov_avail="<<n_cov<<"/"<<N<<"\n";
    }

    Sophus::SE3d X = ToSophus(init_eigen);

    for (int it=0; it<outer_irls; ++it){
        // 1) 计算白化残差范数
        Eigen::VectorXd r(N);
        for (int i=0;i<N;++i){
            const Sophus::SE3d Ti = ToSophus(meas[i].T_smatch_squery);
            const Eigen::Matrix<double,6,1> e = left_invariant ?
                (Ti.inverse() * X).log() : (X.inverse() * Ti).log();
            r[i] = (Ls[i]*e).norm();
        }
        // Huber 阈值：χ²(6) 95% 分位 ≈ 12.59 → sqrt ≈ 3.55；也可用 2.5~3.0
        const double delta = 2.5;
        const IRLSWeights W = HuberWeights(r, delta);

        // 2) Ceres 构建
        double pose7[7];
        const Eigen::Quaterniond q0 = X.unit_quaternion();
        const Eigen::Vector3d    t0 = X.translation();
        pose7[0]=q0.x(); pose7[1]=q0.y(); pose7[2]=q0.z(); pose7[3]=q0.w();
        pose7[4]=t0.x(); pose7[5]=t0.y(); pose7[6]=t0.z();

        ceres::Problem problem;
        auto* qp = new ceres::EigenQuaternionParameterization();
        auto* tp = new ceres::IdentityParameterization(3);
        auto* se3 = new ceres::ProductParameterization(qp, tp);
        problem.AddParameterBlock(pose7, 7, se3);

        for (int i=0;i<N;++i){
            auto* cost = new ceres::AutoDiffCostFunction<RelPoseFactorSE3_IRLS, 6, 7>(
                new RelPoseFactorSE3_IRLS(ToSophus(meas[i].T_smatch_squery), Ls[i], W.wsqrt[i], left_invariant));
            problem.AddResidualBlock(cost, /*loss*/nullptr, pose7);
        }

        ceres::Solver::Options opts; opts.linear_solver_type=ceres::DENSE_QR;
        opts.max_num_iterations=inner_iters; opts.minimizer_progress_to_stdout=false;
        ceres::Solver::Summary sum; ceres::Solve(opts, &problem, &sum);

        // 更新
        Eigen::Quaterniond q(pose7[3], pose7[0], pose7[1], pose7[2]);
        Eigen::Vector3d    t(pose7[4], pose7[5], pose7[6]);
        Sophus::SE3d X_new(q.normalized(), t);

        if (verbose){
            double w_mean=0.0; for(double wi:W.w) w_mean+=wi; w_mean/=std::max(1,N);
            const double dx = (X.inverse()*X_new).log().norm();
            std::cout << "[Huber] it="<<it<<"  cost="<<sum.final_cost
                      <<"  |dx|="<<dx<<"  w_mean="<<w_mean<<"\n";
        }
        X = X_new;
    }
    return ToEigen(X);
}



// ------------------ 大样本：KDE σ-consensus（白化 + KDE权） ------------------
// 仅保留 KDE + IRLS；不使用协方差、不做白化
static Eigen::Matrix4d EstimateRelativePoseCeres_SigmaConsensusKDE(
    const std::vector<RelPoseMeasurement>& meas,
    const Eigen::Matrix4d& init_eigen,
    int outer_iters = 5,
    int inner_iters = 30,
    bool left_invariant = true,
    bool verbose = true)
{
    const int N = (int)meas.size();
    if (N == 0) return init_eigen;

    Sophus::SE3d X = ToSophus(init_eigen);

    for (int it = 0; it < outer_iters; ++it) {
        // 1) 计算未白化的残差范数 r_i = ||e_i||
        Eigen::VectorXd r(N);
        for (int i = 0; i < N; ++i) {
            const Sophus::SE3d Ti = ToSophus(meas[i].T_smatch_squery);
            const Eigen::Matrix<double,6,1> e = left_invariant
                ? (Ti.inverse() * X).log()
                : (X.inverse() * Ti).log();
            r[i] = e.norm();                   // ★ 不再乘 L_i
        }

        // KDE 得到权重（0~1），以及其平方根
        const IRLSWeights W = KDEWeightsOnNorms(r);

        if (verbose) {
            double w_mean = 0.0, w_min = 1.0, w_max = 0.0;
            for (double wi : W.w) { w_mean += wi; w_min = std::min(w_min, wi); w_max = std::max(w_max, wi); }
            w_mean /= std::max(1, N);
            std::cout << "[sigma] it=" << it
                      << "  KDE  w_mean=" << w_mean
                      << "  w_min=" << w_min
                      << "  w_max=" << w_max << "\n";
        }

        // 2) 加权最小二乘（不再传 L_i；若你的因子构造要求 L_i，传恒等即可）
        double pose7[7];
        {
            const Eigen::Quaterniond q0 = X.unit_quaternion();
            const Eigen::Vector3d    t0 = X.translation();
            pose7[0]=q0.x(); pose7[1]=q0.y(); pose7[2]=q0.z(); pose7[3]=q0.w();
            pose7[4]=t0.x(); pose7[5]=t0.y(); pose7[6]=t0.z();
        }

        ceres::Problem problem;
        auto* qp  = new ceres::EigenQuaternionParameterization();
        auto* tp  = new ceres::IdentityParameterization(3);
        auto* se3 = new ceres::ProductParameterization(qp, tp);
        problem.AddParameterBlock(pose7, 7, se3);

        for (int i = 0; i < N; ++i) {
            // 如果你的 RelPoseFactorSE3_IRLS 之前签名是 (Ti, L_i, wsqrt, left_inv)
            // 这里把 L_i 传恒等即可；或者改造因子只接收 wsqrt。
            const Eigen::Matrix<double,6,6> I6 = Eigen::Matrix<double,6,6>::Identity();
            auto* cost = new ceres::AutoDiffCostFunction<RelPoseFactorSE3_IRLS, 6, 7>(
                new RelPoseFactorSE3_IRLS(ToSophus(meas[i].T_smatch_squery), I6, W.wsqrt[i], left_invariant));
            problem.AddResidualBlock(cost, nullptr, pose7);
        }

        ceres::Solver::Options opts;
        opts.linear_solver_type = ceres::DENSE_QR;
        opts.max_num_iterations = inner_iters;
        opts.minimizer_progress_to_stdout = false;

        ceres::Solver::Summary sum; 
        ceres::Solve(opts, &problem, &sum);

        Eigen::Quaterniond q(pose7[3], pose7[0], pose7[1], pose7[2]);
        Eigen::Vector3d    t(pose7[4], pose7[5], pose7[6]);
        Sophus::SE3d X_new(q.normalized(), t);

        if (verbose) {
            const double dx = (X.inverse() * X_new).log().norm();
            std::cout << "[sigma] inner: " << sum.BriefReport() << "  |dx|=" << dx << "\n";
        }
        X = X_new;
    }
    return ToEigen(X);
}


bool MapManager::ComputeRobustMergeForSelectedPair(
    int q_rep_id, int m_rep_id,
    MergeInformation& out_merged)   // 注意：这里用单条合成后的 MI 直接返回
{
    // 为减少锁时间，先把 batch 取出来
    std::vector<RelPoseMeasurement> batch;
    KeyframePtr kf_q_first, kf_m_first;

    // 辅助：当前代表 client id 对应的 MapInstance*
    auto map_of_client = [&](int cid) -> MapInstance* {
        auto it = maps_.find(cid);
        return (it == maps_.end() || !it->second) ? nullptr : it->second.get();
    };
    MapInstance* q_map_now = map_of_client(q_rep_id);
    MapInstance* m_map_now = map_of_client(m_rep_id);
    if (!q_map_now || !m_map_now || q_map_now == m_map_now) return false;

    // 辅助：kf -> 当前 MapInstance*
    auto map_of_kf = [&](const KeyframePtr& kf) -> MapInstance* {
        if (!kf) return nullptr;
        auto it = maps_.find(kf->id_.second);
        return (it == maps_.end() || !it->second) ? nullptr : it->second.get();
    };

    {
        std::unique_lock<std::mutex> lk(mtx_access_);
        for (const auto& mi : buffer_merge_) {
            MapInstance* qm = map_of_kf(mi.kf_query);
            MapInstance* mm = map_of_kf(mi.kf_match);
            if (!qm || !mm || qm == mm) continue;
            if (qm == q_map_now && mm == m_map_now) {
                RelPoseMeasurement m;
                m.T_smatch_squery = mi.T_smatch_squery;
                m.cov             = mi.cov_mat;
                m.kf_match        = mi.kf_match;
                m.kf_query        = mi.kf_query;
                if (!kf_q_first) kf_q_first = mi.kf_query;
                if (!kf_m_first) kf_m_first = mi.kf_match;
                batch.emplace_back(std::move(m));
            }
        }
    }

    if (batch.size() < 15 || !kf_q_first || !kf_m_first) return false;

    // 离线鲁棒估计
    const TransformType init = batch.front().T_smatch_squery;
    auto t0 = std::chrono::steady_clock::now();

    TransformType T_star =
        EstimateRelativePoseCeres_SigmaConsensusKDE(batch, init,
                                                    /*outer=*/5, /*inner=*/30,
                                                    /*left=*/true, /*verbose=*/true);

    auto t1 = std::chrono::steady_clock::now();
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    std::cout << std::fixed << std::setprecision(3)
              << "[merge] EstimateRelativePoseCeres_SigmaConsensusKDE time: "
              << ms << " ms\n";

    TypeDefs::Matrix6Type Cov_star = TypeDefs::Matrix6Type::Identity();

    // 聚合后的单条测量写回（不在这里改 buffer；交给调用处或 PerformMergeWith 处理）
    out_merged.kf_query        = kf_q_first;
    out_merged.kf_match        = kf_m_first;
    out_merged.T_smatch_squery = T_star;
    out_merged.cov_mat         = Cov_star;
    return true;
}


// 放到合适的头或本文件顶部（只需定义一次）
struct ScopeExit {
    std::function<void()> f;
    explicit ScopeExit(std::function<void()> fin) : f(std::move(fin)) {}
    ~ScopeExit() { if (f) f(); }
};

void MapManager::PerformMergeWith(const MergeInformation& merged_in) {
    std::cout << "+++ Perform Merge +++\n";
    std::cout << "--> Process merge data\n";

    // 从合入条目里拿到关键帧与测量
    KeyframePtr   kf_query  = merged_in.kf_query;
    KeyframePtr   kf_match  = merged_in.kf_match;
    TransformType T_smatch_squery = merged_in.T_smatch_squery;
    TypeDefs::Matrix6Type cov_mat = merged_in.cov_mat;

    if (!kf_query || !kf_match) {
        std::cerr << "[merge][error] null keyframe ptr\n";
        return;
    }

    // 通过 keyframe 的 client/map id 找到当前的 MapInstance（注意：maps_ 会在合并后更新路由）
    const int q_client_id = static_cast<int>(kf_query->id_.second);
    const int m_client_id = static_cast<int>(kf_match->id_.second);

    MapInstancePtr qm = (maps_.count(q_client_id) ? maps_[q_client_id] : MapInstancePtr{});
    MapInstancePtr mm = (maps_.count(m_client_id) ? maps_[m_client_id] : MapInstancePtr{});

    if (!qm || !mm) {
        std::cerr << "[merge][error] cannot find map instances for q=" << q_client_id
                  << " m=" << m_client_id << "\n";
        return;
    }
    if (qm.get() == mm.get()) {
        std::cerr << "[merge] maps already same instance, skip\n";
        return;
    }

    // 统一锁顺序，避免死锁（按指针地址排序）
    MapInstancePtr first  = (qm.get() < mm.get()) ? qm : mm;
    MapInstancePtr second = (qm.get() < mm.get()) ? mm : qm;

    auto rep_client = [](const MapInstancePtr& mp) -> int {
        if (!mp || !mp->map || mp->map->associated_clients_.empty()) return -1;
        return static_cast<int>(*mp->map->associated_clients_.begin());
    };

    const int id_first  = rep_client(first);
    const int id_second = rep_client(second);
    if (id_first < 0 || id_second < 0) {
        std::cerr << "[merge][error] invalid representative client id\n";
        return;
    }

    // 获取两把地图独占锁（注意：本函数不持有 mtx_access_，避免锁环）
    int check_first  = 0;
    int check_second = 0;
    this->CheckoutMapExclusiveOrWait(id_first,  check_first);
    this->CheckoutMapExclusiveOrWait(id_second, check_second);

    // RAII：确保任何路径都释放独占锁。注意 Checkin 需要两个参数！
    ScopeExit guard_release([&](){
        this->CheckinMapExclusive(id_second, check_second);
        this->CheckinMapExclusive(id_first,  check_first);
    });

    std::cout << "----> Merge maps\n";

    // 计算 w_match <- w_query 的对齐变换
    TransformType T_w_squery = kf_query->GetPoseTws();
    TransformType T_w_smatch = kf_match->GetPoseTws();
    TransformType T_wmatch_wquery = T_w_smatch * T_smatch_squery * T_w_squery.inverse();

    // 构建新的合并地图（保持原有 MapInstance 构造签名：MapInstance(mm, qm, T)）
    MapInstancePtr map_merged(new MapInstance(mm, qm, T_wmatch_wquery));

    // 将跨图约束写入合并后的图
    LoopConstraint lc(kf_match, kf_query, T_smatch_squery, cov_mat);
    map_merged->map->AddLoopConstraint(lc);

    // 更新 maps_ 路由，让所有相关 client 指向合并后的实例
    for (auto cid : map_merged->map->associated_clients_) {
        maps_[cid] = map_merged;
    }
    map_merged->usage_cnt = 0;

    std::cout << "Merged Map: Agents|KFs|LMs: "
              << map_merged->map->associated_clients_.size() << "|"
              << map_merged->map->GetKeyframes().size() << "|"
              << map_merged->map->GetLandmarks().size() << "\n";
    std::cout << "\033[1;32m+++ MAPS MERGED +++\033[0m\n";

    // 合并后清理 buffer_merge_ 中“已变成同图”的旧条目，防止重复融合与后续卡住
    size_t removed = 0;
    {
        std::unique_lock<std::mutex> lk(mtx_access_);
        for (auto it = buffer_merge_.begin(); it != buffer_merge_.end(); ) {
            auto qmp = maps_.count(it->kf_query->id_.second) ? maps_[it->kf_query->id_.second] : MapInstancePtr{};
            auto mmp = maps_.count(it->kf_match->id_.second) ? maps_[it->kf_match->id_.second] : MapInstancePtr{};
            if (!qmp || !mmp || qmp.get() == mmp.get()) { it = buffer_merge_.erase(it); ++removed; }
            else { ++it; }
        }
    }
    if (removed) std::cout << "[merge] cleanup removed " << removed << " obsolete entries\n";

    // guard_release 析构时自动 Checkin 两把锁
}










auto MapManager::RegisterMap(MapPtr external_map, bool enter_kfs_in_database)->bool {

    if(enter_kfs_in_database) {
        auto keyframes = external_map->GetKeyframesVec();
        for(const auto& kf : keyframes) {
            this->AddToDatabase(kf);
        }
    } else {
        // skip this because we do a PR test
        std::cout << COUTNOTICE << "!!! KFs not entered in database !!!" << std::endl;
    }

    MapInstancePtr map_inst(new MapInstance(external_map));
    for(std::set<size_t>::iterator sit = map_inst->map->associated_clients_.begin();sit != map_inst->map->associated_clients_.end();++sit) {
        std::cout << "----> Add maps_[" << *sit << "]" << std::endl;
        maps_[*sit] = map_inst;
    }
    return true;
}

auto MapManager::RegisterMerge(MergeInformation merge_data)->void {
    std::unique_lock<std::mutex> lock(mtx_access_);
    buffer_merge_.push_back(merge_data);
}


auto MapManager::ReturnMap(int map_id, int &check_num)->void {
    std::unique_lock<std::mutex> lock(mtx_access_);

    MapContainer::iterator mit = maps_.find(map_id);
    if(mit == maps_.end()){
        std::cout << COUTFATAL << "no existing map with Map-ID " << map_id << std::endl;
        exit(-1);
    }

    MapInstancePtr map = mit->second;

    if(!map->check_nums.count(check_num)){
        std::cout << COUTFATAL << "check_num error" << std::endl;
        exit(-1);
    }

    if(map->usage_cnt == -1)
        map->usage_cnt = 0;
    else
        map->usage_cnt--;

    map->check_nums.erase(check_num);
}


/****
auto MapManager::Run()->void {
    while(1) {
        //CheckMergeBuffer()：通常检查队列是否非空（可能也做加锁）；为真时调用 PerformMerge() 处理一条合并任务。
        if(this->CheckMergeBuffer()) 
        {
            this->PerformMerge();
        }
        usleep(5000);
    }
}
************************/

void MapManager::Run() {
    while (1) {
        if (this->CheckMergeBuffer_modified()) {
            MergeInformation mi_agg;
            // 注意：这里用 next_pair_*（已经在 Check 中设置）
            if (this->ComputeRobustMergeForSelectedPair(
                    next_pair_query_id_, next_pair_match_id_, mi_agg)) {

                // 关键：直接消费准备好的条目，不再依赖队列
                this->PerformMergeWith(mi_agg);
            }
        }
        usleep(5000);
    }
}









auto MapManager::SetCheckoutBlock(int map_id, bool val)->bool {
    std::unique_lock<std::mutex> lock(mtx_access_);

    MapContainer::iterator mit = maps_.find(map_id);
    if(mit == maps_.end()){
        std::cout << COUTFATAL << "no existing map with Map-ID " << map_id << std::endl;
        exit(-1);
    }

    MapInstancePtr map = mit->second;

    if(val && map->block_checkout) {
        return false;
    } else {
        map->block_checkout = val;
        return true;
    }
}

//-------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------

Map::Map(size_t id)
    : MapBase(id)
{
    associated_clients_.insert(id);
}

Map::Map(MapPtr map_target, MapPtr map_tofuse, TransformType T_wtarget_wtofuse)
    : MapBase(map_target->id_map_)
{
    // data map_target
    std::set<size_t> associated_clients_target = map_target->associated_clients_;
    KeyframeMap keyframes_target = map_target->GetKeyframes();
    LandmarkMap landmarks_target = map_target->GetLandmarks();
    size_t tmax_id_kf_target = map_target->GetMaxKfId();
    size_t max_id_lm_target = map_target->GetMaxLmId();
    LoopVector loops_target = map_target->GetLoopConstraints();

    // data map_tofuse
    std::set<size_t> associated_clients_tofuse = map_tofuse->associated_clients_;
    KeyframeMap keyframes_tofuse = map_tofuse->GetKeyframes();
    LandmarkMap landmarks_tofuse = map_tofuse->GetLandmarks();
    size_t tmax_id_kf_tofuse = map_tofuse->GetMaxKfId();
    size_t max_id_lm_tofuse = map_tofuse->GetMaxLmId();
    LoopVector loops_tofuse = map_tofuse->GetLoopConstraints();

    //fill new map
    associated_clients_.insert(associated_clients_target.begin(),associated_clients_target.end());
    associated_clients_.insert(associated_clients_tofuse.begin(),associated_clients_tofuse.end());
    keyframes_.insert(keyframes_target.begin(),keyframes_target.end());
    keyframes_.insert(keyframes_tofuse.begin(),keyframes_tofuse.end());
    landmarks_.insert(landmarks_target.begin(),landmarks_target.end());
    landmarks_.insert(landmarks_tofuse.begin(),landmarks_tofuse.end());
    max_id_kf_ = std::max(tmax_id_kf_target,tmax_id_kf_tofuse);
    max_id_lm_ = std::max(max_id_lm_target,max_id_lm_tofuse);
    loop_constraints_.insert(loop_constraints_.end(),loops_target.begin(),loops_target.end());
    loop_constraints_.insert(loop_constraints_.end(),loops_tofuse.begin(),loops_tofuse.end());

    // Transform poses of map_tofuse
    for(KeyframeMap::iterator mit = keyframes_tofuse.begin();mit != keyframes_tofuse.end();++mit) {
        KeyframePtr kf = mit->second;
        TransformType T_w_s_befcorrection = kf->GetPoseTws();
        TransformType T_w_s_corrected = T_wtarget_wtofuse * T_w_s_befcorrection;
        kf->SetPoseTws(T_w_s_corrected);
        kf->velocity_ = T_wtarget_wtofuse.block<3,3>(0,0) * kf->velocity_;
    }
    Matrix3Type R_wmatch_wtofuse = T_wtarget_wtofuse.block<3,3>(0,0);
    Vector3Type t_wmatch_wtofuse = T_wtarget_wtofuse.block<3,1>(0,3);
    for(LandmarkMap::iterator mit = landmarks_tofuse.begin();mit != landmarks_tofuse.end();++mit) {
        LandmarkPtr lm = mit->second;
        Vector3Type pos_w_befcorrection = lm->GetWorldPos();
        Vector3Type pos_w_corrected = R_wmatch_wtofuse * pos_w_befcorrection + t_wmatch_wtofuse;
        lm->SetWorldPos(pos_w_corrected);
    }
}

auto Map::AddKeyframe(KeyframePtr kf)->void {
    this->AddKeyframe(kf,false);
}

auto Map::AddKeyframe(covins::MapBase::KeyframePtr kf, bool suppress_output)->void {
    std::unique_lock<std::mutex> lock(mtx_map_);
    keyframes_[kf->id_] = kf;
    max_id_kf_ = std::max(max_id_kf_,kf->id_.first);
    if(!suppress_output && !(keyframes_.size() % 50)) {
        std::cout << "Map " << this->id_map_  << " : " << keyframes_.size() << " KFs | " << landmarks_.size() << " LMs" << std::endl;
        this->WriteKFsToFile();
        this->WriteKFsToFileAllAg();
    }
}

auto Map::AddLandmark(covins::MapBase::LandmarkPtr lm)->void {
    std::unique_lock<std::mutex> lock(mtx_map_);
    landmarks_[lm->id_] = lm;
    max_id_lm_ = std::max(max_id_lm_,lm->id_.first);
}

auto Map::AddLoopConstraint(LoopConstraint lc)->void {
    std::unique_lock<std::mutex> lock(mtx_map_);
    loop_constraints_.push_back(lc);
    lc.kf1->is_loop_kf_ = true;
    lc.kf2->is_loop_kf_ = true;
}

auto Map::ApplyLoopCorrection(KeyframePtr kf_query, KeyframePtr kf_match, TransformType T_smatch_squery)->void {
    std::unique_lock<std::mutex> lock(mtx_map_);

    TransformType T_w_squery_befcorr = kf_match->GetPoseTws();
    TransformType T_w_smatch = kf_match->GetPoseTws();

    TransformType T_w_squery_corrected = T_w_smatch * T_smatch_squery;

    kf_query->SetPoseTws(T_w_squery_corrected);
    KeyframePtr succ = kf_query->GetSuccessor();
    while(succ){
        TransformType T_w_ssucc_befcorr = succ->GetPoseTws();
        TransformType T_squery_ssucc = T_w_squery_befcorr * T_w_ssucc_befcorr.inverse();
        TransformType T_w_ssucc_corrected = T_w_squery_corrected * T_squery_ssucc;
        succ->SetPoseTws(T_w_ssucc_corrected);
        succ = succ->GetSuccessor();
    }

    LoopConstraint lc(kf_match,kf_query,T_smatch_squery);
    loop_constraints_.push_back(lc);
}

auto Map::ConvertToMsgFileExport(MsgMap &msg)->void {
    std::unique_lock<std::mutex> lock(mtx_map_);
    msg.id_map = id_map_;
    msg.keyframes1.reserve(loop_constraints_.size());
    msg.keyframes2.reserve(loop_constraints_.size());
    msg.transforms12.reserve(loop_constraints_.size());
    msg.cov.reserve(loop_constraints_.size());
    for(const auto& i : loop_constraints_) {
        msg.keyframes1.push_back(i.kf1->id_);
        msg.keyframes2.push_back(i.kf2->id_);
        msg.transforms12.push_back(i.T_s1_s2);
        msg.cov.push_back(i.cov_mat);
    }
}

auto Map::Clean()->void {
    std::unique_lock<std::mutex> lock(mtx_map_);
    std::cout << "+++ Clean Map +++" << std::endl;
    std::cout << "--> Remove Landmarks" << std::endl;
    this->RemoveLandmarkOutliers();
    std::cout << "+++ DONE +++" << std::endl;
}

auto Map::EraseKeyframe(KeyframePtr kf, bool mtx_lock)->bool {
    if(mtx_lock) mtx_map_.lock();
    bool success = false;
    KeyframeMap::iterator mit = keyframes_.find(kf->id_);
    if(mit != keyframes_.end()) {
        bool removed = kf->SetInvalid();
        if(!removed) {
            std::cout << COUTWARN << "Map " << this->id_map_ << ": could not remove " << kf << std::endl;
        } else{
            keyframes_.erase(mit);
            std::cout << "Map " << this->id_map_ << " : erased " << kf << std::endl;
            keyframes_erased_[kf->id_] = kf;
            success = true;
        }
    }
    else std::cout << COUTWARN << "Map " << this->id_map_ << ": trying to erase KF from map that does not exist" << std::endl;
    if(mtx_lock) mtx_map_.unlock();

    return success;
}

auto Map::EraseKeyframeWithDatabase(KeyframePtr kf, bool mtx_lock, MapManager::DatabasePtr database)->bool {
    bool success = this->EraseKeyframe(kf,mtx_lock);
    if(!database) std::cout << COUTNOTICE << "need to erase KF from database!" << std::endl;
    else database->EraseKeyframe(kf);

    return success;
}

auto Map::EraseLandmark(LandmarkPtr lm, bool mtx_lock)->bool {
    if(mtx_lock) mtx_map_.lock();
    bool success = false;
    LandmarkMap::iterator mit = landmarks_.find(lm->id_);
    if(mit != landmarks_.end()) {
        bool removed = lm->SetInvalid();
        if(!removed) {
            std::cout << COUTWARN << "Map " << this->id_map_ << ": could not remove " << lm << std::endl;
        } else {
            landmarks_.erase(mit);
            success = true;
        }
    }
    if(mtx_lock) mtx_map_.unlock();

    return success;
}

auto Map::GetLoopConstraints()->LoopVector {
    std::unique_lock<std::mutex> lock(mtx_map_);
    return loop_constraints_;
}

auto Map::LoadFromFile(const std::string &path_name, VocabularyPtr voc)->void {
    std::cout << "+++ Load Map from File +++" << std::endl;

    if(!voc && covins_params::placerec::type != "VINS") {
        std::cout << COUTFATAL << "invalid vocabulary ptr" << std::endl;
        exit(-1);
    }

    std::vector<std::string> filenames_kf, filenames_mp;
    KeyframeVector keyframes;
    LandmarkVector landmarks;

    // quickfix char*/string compatibility [TODO] cleaner solution
    std::string kf_tmp = "/keyframes/";
    std::string mp_tmp = "/mappoints/";
    char cstr0[path_name.size()+kf_tmp.size()+1];
    char cstr1[path_name.size()+mp_tmp.size()+1];
    strcpy(cstr0, (path_name+kf_tmp).c_str());
    strcpy(cstr1, (path_name+mp_tmp).c_str());

    // getting all filenames for the keyframes
    struct dirent *entry;
    DIR *dir = opendir(cstr0);

    if (dir == nullptr) {
        std::cout << "Directory is empty." << std::endl;
        return;
    }

    while ((entry = readdir(dir)) != nullptr) {
        if ( !strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..") ) {
            continue;
        } else {
            std::stringstream path;
            path << path_name+"/keyframes/";
            path << entry->d_name;
            filenames_kf.push_back(path.str());
        }
    }
    closedir(dir);

    // getting all filenames for the mappoints
    struct dirent *entry2;
    DIR *dir2 = opendir(cstr1);
    if (dir2 == nullptr) {
        std::cout << "Directory is empty." << std::endl;
        return;
    }

     while ((entry2 = readdir(dir2)) != nullptr) {
        if ( !strcmp(entry2->d_name, ".") || !strcmp(entry2->d_name, "..") ) {
            continue;
        } else {
            std::stringstream path;
            path << path_name+"/mappoints/";
            path << entry2->d_name;
            filenames_mp.push_back(path.str());
        }
    }
    closedir(dir);

    Eigen::Matrix4d T_ow = Eigen::Matrix4d::Identity();

    std::cout << "--> Loading Keyframes" << std::endl;
    for(unsigned long int i = 0; i < filenames_kf.size(); i++) {
        if(i % 50 == 0) std::cout << "----> Loaded " << i << " of " << filenames_kf.size() << " KFs" << std::endl;
        MsgKeyframe msg(true);
        std::stringstream buf;
        std::ifstream fs;
        fs.open(filenames_kf[i]);
        if(fs.is_open()) {
            buf << fs.rdbuf();
            cereal::BinaryInputArchive iarchive(buf);
            iarchive(msg);
            KeyframePtr kf(new Keyframe(msg,nullptr,voc));
            kf->is_loaded_ = true;
            keyframes.push_back(kf);
            if(kf->id_.first == 0) {
                T_ow.block<3,3>(0,0) = Eigen::Matrix3d::Zero();
                T_ow(0,1) = 1.0;
                T_ow(1,0) = -1.0;
                T_ow(2,2) = 1.0;
                T_ow.block<3,1>(0,3) = -1.0 * T_ow.block<3,3>(0,0) * kf->GetPoseTws().block<3,1>(0,3);
            }
            fs.close();
        } else {
            std::cout << filenames_kf[i] << std::endl;
            exit(-1);
        }
    }

    std::cout << "--> Loading Landmarks" << std::endl;
    for(unsigned long int i = 0; i < filenames_mp.size(); i++) {
        if(i % 1000 == 0) std::cout << "----> Loaded " << i << " of " << filenames_mp.size() << " LMs" << std::endl;
        MsgLandmark msg(true);
        std::stringstream buf;
        std::ifstream fs;
        fs.open(filenames_mp[i]);
        if(fs.is_open()) {
            buf << fs.rdbuf();
            cereal::BinaryInputArchive iarchive(buf);
            iarchive(msg);
            LandmarkPtr lm(new Landmark(msg,nullptr));
            lm->is_loaded_ = true;
            landmarks.push_back(lm);
            fs.close();
        } else {
            std::cout << COUTERROR << "Cannot read file: " << filenames_mp[i] << std::endl;
            exit(-1);
        }
    }

    std::cout << "--> Loading Map Data" << std::endl;
    MsgMap msg_map;
    {
        std::stringstream buf;
        std::ifstream fs;
        fs.open(path_name+"/mapdata"+".txt");
        if(fs.is_open()) {
            buf << fs.rdbuf();
            cereal::BinaryInputArchive iarchive(buf);
            iarchive(msg_map);
            fs.close();
        } else {
            std::cout << COUTFATAL << "cannot load map data" << std::endl;
            exit(-1);
        }
    }

    std::cout << "Map consists of " << keyframes.size() << " keyframes" << std::endl;
    std::cout << "Map consists of " << landmarks.size() << " landmarks" << std::endl;

    std::cout << "--> Building Connections" << std::endl;

    for(const auto& kf : keyframes) {
        this->AddKeyframe(kf,true);
        if(!this->associated_clients_.count(kf->id_.second))
            associated_clients_.insert(kf->id_.second);
    }

    std::cout << "----> Landmarks" << std::endl;
    for(const auto& lm : landmarks) {
        for(auto mit = lm->msg_.observations.begin(); mit!=lm->msg_.observations.end();++mit){
            size_t feat_id = mit->second;
            idpair kf_id = mit->first;
            KeyframePtr kf = this->GetKeyframe(kf_id);
            if(!kf){
                continue;
            }
            lm->AddObservation(kf,feat_id,true);
        }
        lm->SetReferenceKeyframe(this->GetKeyframe(lm->msg_.id_reference));
        lm->ComputeDescriptor();
        lm->UpdateNormal();
        this->AddLandmark(lm);
    }

    std::cout << "----> Keyframes" << std::endl;
    for(const auto& kf : keyframes) {
        kf->SetPredecessor(this->GetKeyframe(kf->msg_.id_predecessor));
        kf->SetSuccessor(this->GetKeyframe(kf->msg_.id_successor));
        kf->EstablishNeighbors(kf->msg_, shared_from_this());
        for(auto mit = kf->msg_.landmarks.begin(); mit!=kf->msg_.landmarks.end();++mit){
            size_t feat_id = mit->first;
            idpair lm_id = mit->second;
            LandmarkPtr lm = this->GetLandmark(lm_id);
            kf->AddLandmark(lm,feat_id);
        }
        kf->UpdateCovisibilityConnections();
    }

    std::cout << "----> Map Data" << std::endl;
    for(size_t i=0;i<msg_map.keyframes1.size();++i) {
        KeyframePtr kf1 = this->GetKeyframe(msg_map.keyframes1[i]);
        KeyframePtr kf2 = this->GetKeyframe(msg_map.keyframes2[i]);
//        std::cout << "------> Add Loop Constraint: " << std::endl;
//        std::cout << "kf1: "  << kf1 << std::endl;
//        std::cout << "kf2: "  << kf2 << std::endl;
//        std::cout << "T12: \n"  << msg_map.transforms12[i] << std::endl;
        LoopConstraint lc(kf1,kf2,msg_map.transforms12[i],msg_map.cov[i]);
        loop_constraints_.push_back(lc);
    }
    // std::cout << "+++ Perform PGO +++" << std::endl;
    // TypeDefs::PoseMap corrected_poses;

    // Optimization::PoseGraphOptimization(shared_from_this(), corrected_poses);
    // this->WriteKFsToFileAllAg();
    std::cout << "+++ DONE +++" << std::endl;
}

auto Map::RemoveLandmarkOutliers()->int {
    // assumes mtx is locked by calling method
    int removed_lms = 0;
    int removed_lms_map = 0;
    int removed_lms_kfs = 0;

    std::list<LandmarkPtr> lms_to_remove;

    for(LandmarkMap::iterator mit = landmarks_.begin(); mit!=landmarks_.end();) {
        LandmarkPtr lm = mit->second;
        if(!lm) {
            std::cout << COUTWARN << "Map " << this->id_map_ << ": nullptr LM in map" << std::endl;
            mit = landmarks_.erase(mit);
        } else {
            if(lm->GetObservations().size() < 2) {
                lms_to_remove.push_back(lm);
            }
            mit++;
        }
    }

    for(const auto& lm : lms_to_remove) {
        this->EraseLandmark(lm,false);
        removed_lms++;
        removed_lms_map++;
    }

    for(const auto& i : keyframes_) {
        KeyframePtr kf = i.second;
        auto kf_lms = kf->GetLandmarks();
        for(const auto& lm : kf_lms) {
            if(!lm) continue;
            if(lm->GetObservations().size() < 2) {
                this->EraseLandmark(lm,false);
                removed_lms++;
                removed_lms_kfs++;
            }
        }
    }

    std::cout << "----> Done: Removed " << removed_lms << " Landmarks" << std::endl;
    std::cout << "------> from map checks: " << removed_lms_map << std::endl;
    std::cout << "------> from kf checks:  " << removed_lms_kfs << std::endl;

    return removed_lms;
}

auto Map::RemoveRedundantData(ManagerPtr mapmanager, double th_red, size_t max_kfs)->size_t {

    this->Clean();

    std::unique_lock<std::mutex> lock(mtx_map_); // Clean() also needs mtx_map_
    size_t removed_kfs = 0;

    KeyframeVector kfs;
    for(const auto& p : keyframes_) {
        KeyframePtr kf = p.second;
        if(kf->id_.first == 0) continue;
        if(!kf->GetPredecessor()) continue;
        if(!kf->GetSuccessor()) continue;
        kfs.push_back(kf);
    }

    auto database = mapmanager->GetDatabase();

    if(max_kfs == std::numeric_limits<size_t>::max()) {
        // remove all KFs with red_val >= th_red
        while(!kfs.empty()) {
            this->CalRedVals(kfs);
            if(kfs.empty()) {
                std::cout << COUTWARN << "no KFs to erase" << std::endl;
                break;
            }
            if(kfs[0]->latest_red_val_ >= th_red) {
                bool can_be_removed = true;
                if(kfs[0]->GetTimeSpanPredSucc() >= covins_params::mapping::kf_culling_max_time_dist) can_be_removed = false;
                if(kfs[0]->is_loop_kf_) can_be_removed = false;
                if(can_be_removed) {
                    this->EraseKeyframeWithDatabase(kfs[0],false,database);
                    removed_kfs++;
                }
                kfs.erase(kfs.begin());
            } else {
                break;
            }
        }
    } else {
        // remove KFs until there are only max_kfs left
        while(keyframes_.size() > max_kfs) {
            this->CalRedVals(kfs);
            if(kfs.empty()) {
                std::cout << COUTWARN << "no KFs to erase" << std::endl;
                break;
            }
            bool can_be_removed = true;
            if(kfs[0]->GetTimeSpanPredSucc() >= covins_params::mapping::kf_culling_max_time_dist) can_be_removed = false;
            if(kfs[0]->is_loop_kf_) can_be_removed = false;
            if(can_be_removed) {
                this->EraseKeyframeWithDatabase(kfs[0],false,database);
                removed_kfs++;
            }
            kfs.erase(kfs.begin());
        }
    }

    return removed_kfs;
}

auto Map::CalRedVals(KeyframeVector &kfs)->void {
    for(const auto& kf : kfs) {
        kf->ComputeRedundancyValue();
    }
    std::sort(kfs.begin(),kfs.end(),Keyframe::sort_by_redval);
}

auto Map::SaveToFile(const std::string &path_name)->void {
//    std::unique_lock<std::mutex> lock(mtx_map_); -- do not lock, calls map interfaces (uses mutexes there)
    std::cout << "+++ Save Map to File +++" << std::endl;

    {
        // check folder (only checks whether a folder "keyframes/" or "mappoints/" exists
        std::string kf_tmp = "/keyframes/";
        std::string mp_tmp = "/mappoints/";
        char cstr0[path_name.size()+kf_tmp.size()+1];
        char cstr1[path_name.size()+mp_tmp.size()+1];
        strcpy(cstr0, (path_name+kf_tmp).c_str());
        strcpy(cstr1, (path_name+mp_tmp).c_str());

        std::vector<std::string> filenames_kf, filenames_mp;

        // Check for KF files
        DIR *dir = opendir(cstr0);
        if (dir != nullptr) {
            std::cout << COUTERROR << "Write directory is not empty: 'keyframes/' found." << std::endl;
            return;
        }

        // Check for LM files
        DIR *dir2 = opendir(cstr1);
        if (dir2 != nullptr) {
            std::cout << COUTERROR << "Write directory is not empty: 'mappoints/' found." << std::endl;
            return;
        };
    }

    this->Clean();

    std::string kf_tmp = "/keyframes";
    std::string mp_tmp = "/mappoints";

    char cstr0[path_name.size()+1];
    char cstr[path_name.size() + kf_tmp.size()+1];
    char cstr2[path_name.size() + mp_tmp.size()+1];
    strcpy(cstr0,path_name.c_str());
    strcpy(cstr, (path_name+kf_tmp).c_str());
    strcpy(cstr2, (path_name+mp_tmp).c_str());
    std::cout << cstr0 << std::endl;
    std::cout << mkdir(cstr0,  0777);
    std::cout << mkdir(cstr,  0777);
    std::cout << mkdir(cstr2,  0777);
    std::cout << std::endl;

    std::cout << "--> Writing Keyframes to file" << std::endl;
    auto keyframes = this->GetKeyframesVec();
    for(unsigned long int i = 0; i < keyframes.size(); i++) {
        std::ofstream fs;
        fs.open(path_name+"/keyframes/keyframes"+std::to_string(i)+".txt");
        if(fs.is_open()) {
            KeyframePtr kfi = keyframes[i];
            MsgKeyframe msg;
            kfi->ConvertToMsgFileExport(msg);

            std::stringstream kf_ss;
            cereal::BinaryOutputArchive oarchive(kf_ss);
            oarchive(msg);

            fs << kf_ss.str();
            fs.close();
        }
    }

    std::cout << "--> Writing Landmarks to file" << std::endl;
    auto landmarks = this->GetLandmarksVec();
    for(unsigned long int i = 0; i < landmarks.size(); i++) {
        LandmarkPtr lmi = landmarks[i];
        if(lmi->GetObservations().size() < 2) {
            continue;
        }
        if(!lmi->GetReferenceKeyframe()) {
            continue;
        }
        std::ofstream fs;
        fs.open(path_name+"/mappoints/mappoints"+std::to_string(i)+".txt");
        if(fs.is_open()) {
            MsgLandmark msg;
            lmi->ConvertToMsgFileExport(msg);

            std::stringstream mp_ss;
            cereal::BinaryOutputArchive oarchive(mp_ss);
            oarchive(msg);

            fs << mp_ss.str();
            fs.close();
        }
    }

    std::cout << "--> Writing Map Data to file" << std::endl;
    {
        std::ofstream fs;
        fs.open(path_name+"/mapdata"+".txt");
        if(fs.is_open()) {
            MsgMap msg;
            this->ConvertToMsgFileExport(msg);

            std::stringstream map_ss;
            cereal::BinaryOutputArchive oarchive(map_ss);
            oarchive(msg);

            fs << map_ss.str();
            fs.close();
        }
    }

    std::cout << "+++ DONE +++" << std::endl;
}

auto Map::UpdateCovisibilityConnections(idpair kf_id)->void {
    // Why this complicated access to update covisibility connections?
    // If UpdateCovisibilityConnections() is called for two neighboring KFs simultaneously, it will cause a deadlock since
    // they are accessing  1) their own connection (locking their own connection mutex)
    // and 2) the connections of the other KF, e.g. to add a connection, which requires to lock the connection mutex of the other KF
    // Therefore, we need a way to ensure that this method is only called for one KF at the same time.

    std::unique_lock<std::mutex> lock(mtx_update_connections_);
    if(kf_id != defpair) {
        KeyframePtr kf = this->GetKeyframe(kf_id);
        if(kf) kf->UpdateCovisibilityConnections();
    } else {
        std::unique_lock<std::mutex> lock(mtx_map_);
        for(const auto& mit : keyframes_) {
            KeyframePtr kf = mit.second;
            kf->UpdateCovisibilityConnections();
        }
    }
}

auto Map::WriteKFsToFile(std::string suffix)->void{
    for(std::set<size_t>::iterator sit = associated_clients_.begin();sit!=associated_clients_.end();++sit){
        int client_id = *sit;
        if(covins_params::sys::trajectory_format == "EUROC") {
            std::stringstream ss;
            ss << covins_params::sys::output_dir << "KF_" << client_id << suffix << "_feuroc" << ".csv";
            this->WriteStateToCsv(ss.str(),client_id);
        } else if(covins_params::sys::trajectory_format == "TUM") {
            std::stringstream ss;
            ss << covins_params::sys::output_dir << "KF_" << client_id << suffix << "_ftum" << ".csv";
            this->WriteStateToCsvTUM(ss.str(),client_id);
        } else {
            std::cout << COUTFATAL << "trajectory_format '" << covins_params::sys::trajectory_format << "' not in { EUROC | TUM }" << std::endl;
            exit(-1);
        }
    }
}

auto Map::WriteKFsToFileAllAg(std::string prefix) -> void {
    for(std::set<size_t>::iterator sit = associated_clients_.begin();sit!=associated_clients_.end();++sit){
        int client_id = *sit;
        std::stringstream ss;
        ss << covins_params::sys::output_dir /*<< covins_params::sys::time*/
           << "stamped_traj_estimate" << prefix << ".txt";

        if(covins_params::sys::trajectory_format == "EUROC") {
            if(sit == associated_clients_.begin())
              this->WriteStateToCsv(ss.str(), client_id);
            else
              this->WriteStateToCsv(ss.str(), client_id, false);
        } else if(covins_params::sys::trajectory_format == "TUM") {
            if(sit == associated_clients_.begin())
              this->WriteStateToCsvTUM(ss.str(), client_id);
            else
              this->WriteStateToCsvTUM(ss.str(), client_id, false);
        } else {
            std::cout << COUTFATAL << "trajectory_format '" << covins_params::sys::trajectory_format << "' not in { EUROC | TUM }" << std::endl;
            exit(-1);
        }
          
    }
}

auto Map::WriteStateToCsv(const std::string& filename, const size_t client_id, const bool trnc)->void {
    KeyframeVector found_kfs;
    found_kfs.reserve(keyframes_.size());
    // Get all frames from the required client
    for (KeyframeMap::const_iterator mit = keyframes_.begin(); mit != keyframes_.end(); ++mit) {
        KeyframePtr kf = mit->second;
        idpair curr_id = mit->first;
        if (curr_id.second == client_id) {
            found_kfs.push_back(kf);
        }
    }

    if(found_kfs.empty()) //do not overwrite files from other maps with empty files
        return;

    // Sort the keyframes by timestamp
    std::sort(found_kfs.begin(), found_kfs.end(), Keyframe::CompStamp);

    // Write out the keyframe data
    std::ofstream keyframes_file;
    if(trnc)
      keyframes_file.open(filename, std::ios::out | std::ios::trunc);
    else
      keyframes_file.open(filename, std::ios::out | std::ios::app);
    
    if (keyframes_file.is_open()) {
        for (KeyframeVector::const_iterator vit = found_kfs.begin(); vit != found_kfs.end(); ++vit) {
            KeyframePtr kf = (*vit);
            const double stamp = kf->timestamp_;
            Eigen::Vector3d bias_accel, bias_gyro;
            kf->GetStateBias(bias_accel, bias_gyro);
            Eigen::Vector3d vel = kf->GetStateVelocity();
            const Eigen::Matrix4d Tws = kf->GetPoseTws();
            const Eigen::Quaterniond q(Tws.block<3,3>(0,0));

            keyframes_file << std::setprecision(25) << stamp * 1e9f << ",";
            keyframes_file << Tws(0,3) << "," << Tws(1,3) << "," << Tws(2,3) << ",";
            keyframes_file << q.w() << "," << q.x() << "," << q.y() << "," << q.z() << ",";
            keyframes_file << vel[0] << "," << vel[1] << "," << vel[2] << ",";
            keyframes_file << bias_gyro[0] << "," << bias_gyro[1] << "," << bias_gyro[2] << ",";
            keyframes_file << bias_accel[0] << "," << bias_accel[1] << "," << bias_accel[2] << std::endl;
        }
        keyframes_file.close();
    }
    else
        std::cout << COUTERROR << ": Unable to open file: " << filename << std::endl;
}

auto Map::WriteStateToCsvTUM(const std::string& filename, const size_t client_id, const bool trnc)->void {
    KeyframeVector found_kfs;
    found_kfs.reserve(keyframes_.size());
    // Get all frames from the required client
    for (KeyframeMap::const_iterator mit = keyframes_.begin(); mit != keyframes_.end(); ++mit) {
        KeyframePtr kf = mit->second;
        idpair curr_id = mit->first;
        if (curr_id.second == client_id) {
            found_kfs.push_back(kf);
        }
    }

    if(found_kfs.empty()) //do not overwrite files from other maps with empty files
        return;

    // Sort the keyframes by timestamp
    std::sort(found_kfs.begin(), found_kfs.end(), Keyframe::CompStamp);

    // Write out the keyframe data
    std::ofstream keyframes_file;
    if(trnc)
      keyframes_file.open(filename, std::ios::out | std::ios::trunc);
    else
      keyframes_file.open(filename, std::ios::out | std::ios::app);
    
    if (keyframes_file.is_open()) {
        for (KeyframeVector::const_iterator vit = found_kfs.begin(); vit != found_kfs.end(); ++vit) {
            KeyframePtr kf = (*vit);
            const double stamp = kf->timestamp_;
            const Eigen::Matrix4d Tws = kf->GetPoseTws();
            const Eigen::Quaterniond q(Tws.block<3,3>(0,0));

            keyframes_file << std::setprecision(25) << stamp << " ";
            keyframes_file << Tws(0,3) << " " << Tws(1,3) << " " << Tws(2,3) << " ";
            keyframes_file << q.x() << " " << q.y() << " " << q.z() << " " << q.w() 
            << std::endl;
        }
        keyframes_file.close();
    }
    else
        std::cout << COUTERROR << ": Unable to open file: " << filename << std::endl;
}
} //end ns
